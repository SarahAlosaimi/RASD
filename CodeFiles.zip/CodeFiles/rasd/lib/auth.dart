import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:rasd/objects/driver.dart';

class Auth {
  final FirebaseAuth _firebaseAuth =
      FirebaseAuth.instance; // allows to interact with Firebase Auth

  User? get currentUser => _firebaseAuth.currentUser; // get the current user

  Stream<User?> get authStateChanges => _firebaseAuth
      .authStateChanges(); // Notifies about changes to the user's sign-in state (sign in or out)

  // method that Sends a password reset email to the given email address.
  Future<void> sendPasswordResetEmail({
    required String email,
  }) async {
    await _firebaseAuth.sendPasswordResetEmail(email: email);
  }

  // method that  sign in a user with the given email address and password.
  Future<void> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    await _firebaseAuth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
  }

  // method that create a new user account with the given email address and password.
  Future<void> createUserWithEmailAndPassword({
    required String email,
    required String password,
    required Driver driver,
  }) async {
    await _firebaseAuth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    final uid =
        FirebaseAuth.instance.currentUser?.uid; // get The user's unique ID.

    /// Get the driver document
    final docUser = FirebaseFirestore.instance.collection('drivers').doc(uid);
    driver.id = docUser.id;
    final json = driver.toJsonD();

    ///create document and write data to firebase
    await docUser.set(json);
  }

  // method that Signs out the current user.
  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }
}
