// This class is for the report and its' attrubite

import 'package:cloud_firestore/cloud_firestore.dart';

class report {
  String id;
  final int
      status; // variable to shows the report status  ( 0-> pending , 1->confirmed)
  final String v_type; // variable to shows Violation type/s
  final String addInfo; // Additional information entered by the driver
  final String date; // date of the violation
  final String time; // time of the violation

  report({
    required this.id,
    required this.status,
    required this.v_type,
    required this.addInfo,
    required this.date,
    required this.time,
  });

// assgin the attrubites value from snapshot
  report.fromSnapShot(QueryDocumentSnapshot<Map<String, dynamic>> snapshot)
      : id = snapshot.id,
        status = snapshot['status'],
        v_type = snapshot['v_type'],
        addInfo = snapshot['addInfo'],
        date = snapshot['date'],
        time = snapshot['time'];

  // covnter from json object to report object
  static report fromJsonD(Map<String, dynamic> json) => report(
      id: json['id'],
      status: json['status'],
      v_type: json['v_type'],
      addInfo: json['addInfo'],
      date: json['date'],
      time: json['time']);
}
