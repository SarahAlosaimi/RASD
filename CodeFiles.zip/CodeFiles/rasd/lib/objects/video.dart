import 'package:cloud_firestore/cloud_firestore.dart';
// This class is for the video and its' attrubite

class video {
  String id; // video id
  final String video_url; // video url

  video({
    this.id = '',
    required this.video_url,
  });

// assgin the attrubites value from snapshot
  video.fromSnapShot(QueryDocumentSnapshot<Map<String, dynamic>> snapshot)
      : id = snapshot.id,
        video_url = snapshot['video_url'];

  // Convert the video object to json object
  Map<String, dynamic> toJsonD() => {
        'id': id,
        'video_url': video_url,
      };

  // covnter from json object to video object

  static video fromJsonD(Map<String, dynamic> json) => video(
        id: json['id'],
        video_url: json['video_url'],
      );
}
