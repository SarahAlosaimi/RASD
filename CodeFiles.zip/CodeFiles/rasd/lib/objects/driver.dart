// This class is for the driver and its' attrubite

class Driver {
  String id;
  final String Fname; // Driver first name
  final String Lname; // Driver Last name
  final String dashcam_id; // Driver's dascam ip address
  final String dashcam_username; // dashcam username
  final String dashcam_pass; // dashcam password
  final String rtsp_url; // rtsp url for the dashcam stream
  final String email; // driver's email
  final String hash_pass; // driver's hash password
  final String phone_number; // driver's phone_number
  final bool
      phoneVerfied; // boolean value shows if the phone number is verfied or not

  Driver(
      {this.id = '',
      required this.Fname,
      required this.Lname,
      required this.dashcam_id,
      required this.dashcam_username,
      required this.dashcam_pass,
      required this.rtsp_url,
      required this.email,
      required this.hash_pass,
      required this.phone_number,
      required this.phoneVerfied});

  // Convert the driver object to json object
  Map<String, dynamic> toJsonD() => {
        'id': id,
        'Fname': Fname,
        'Lname': Lname,
        'dashcam_id': dashcam_id,
        'dashcam_username': dashcam_username,
        'dashcam_pass': dashcam_pass,
        'rtsp_url': rtsp_url,
        'email': email,
        'hash_pass': hash_pass,
        'phone_number': phone_number,
        'phoneVerfied': phoneVerfied,
      };

  // covnter from json object to driver object
  static Driver fromJsonD(Map<String, dynamic> json) => Driver(
      id: json['id'],
      Fname: json['Fname'],
      Lname: json['Lname'],
      dashcam_id: json['dashcam_id'],
      dashcam_username: json['dashcam_username'],
      dashcam_pass: json['dashcam_pass'],
      rtsp_url: json['rtsp_url'],
      email: json['email'],
      hash_pass: json['hash_pass'],
      phone_number: json['phone_number'],
      phoneVerfied: json['phoneVerfied']);
}
