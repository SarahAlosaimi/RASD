import 'package:rasd/pages/VerifyEmailPage.dart';
import 'package:rasd/auth.dart';
import 'package:rasd/pages/login_register_page.dart';
import 'package:flutter/material.dart';

class WidgetTree extends StatefulWidget {
  const WidgetTree({Key? key}) : super(key: key);

  @override
  State<WidgetTree> createState() => _WidgetTreeState();
}

// This class check the user authentication
class _WidgetTreeState extends State<WidgetTree> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Auth().authStateChanges,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return VerifyEmailPage(); // if the user sign up then it should nav to verify email page
        } else {
          return const LoginPage(); // if the user log in and has data nav to log in page
        }
      },
    );
  }
}
