import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:rasd/auth.dart';
import 'package:rasd/pages/home_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:rasd/pages/settings/settings_screen.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/pages/confirmed.dart';
import 'package:rasd/pages/pendingVideos.dart';

class RootApp extends StatefulWidget {
  int pageIndex;
  RootApp({super.key, this.pageIndex = 0});

  @override
  _RootAppState createState() => _RootAppState();
}

class _RootAppState extends State<RootApp> {
  @override
  Widget build(BuildContext context) {
    //calling for user phone verfication method

    return Scaffold(
      body: getBody(),
      bottomNavigationBar: getFooter(),
    );
  }

  // boolean for checking the phone verfication
  bool phoneVerfied = true;
  void initState() {
    //calling for user phone verfication method
    setState(() {
      getUserVerfied();
    });
  }

// method to retrive the phoneVerfied value from DB
  Future<void> getUserVerfied() async {
    final User? user = Auth().currentUser;
    // variable to the drivers collection in DB
    var collection = FirebaseFirestore.instance.collection('drivers');
    //reterive the document of the current user
    var docSnapshot = await collection.doc(user!.uid).get();
    if (docSnapshot.exists) {
      Map<String, dynamic> data =
          docSnapshot.data()!; // convert the document to Map
      setState(() {
        phoneVerfied =
            data['phoneVerfied']; // get the value of the phoneVerfied
      });
    }
  }

// getBody method which conatin list of all pages in app along with its indexes
  Widget getBody() {
    List<Widget> pages = [
      HomePage(),
      pendingVid(),
      const confirmed(),
      SettingsScreen(),
    ];
    return IndexedStack(
      index: widget.pageIndex,
      children: pages,
    );
  }

// getFooter method to show the bottom appbar
  Widget getFooter() {
    var size = MediaQuery.of(context).size;
    //list of icons not entered (not filled with green)
    List bottomItems = [
      "assets/images/home_icon.svg",
      "assets/images/pendingVideos.svg",
      "assets/images/confirmed_icon.svg",
      phoneVerfied
          ? "assets/images/settings-svgrepo-com.svg"
          : "assets/images/settings-svgrepo-com-warning.svg"
    ];
    //list of icons after entered (filled with green)
    List bottomItems2 = [
      "assets/images/home_icon2.svg",
      "assets/images/pendingVideos2.svg",
      "assets/images/confirmed_icon2.svg",
      phoneVerfied
          ? "assets/images/settings-svgrepo-com2.svg"
          : "assets/images/settings-svgrepo-com-warning2.svg"
    ];
    // list of the page names of each icon
    List textBar = ["Home".tr, "PV".tr, "CR".tr, "More".tr];
    return Row(
      children: [
        Flexible(
          child: Container(
            width: size.width,
            height: 85,
            decoration: BoxDecoration(
              color: textWhite,
              boxShadow: [
                BoxShadow(
                  color: textBlack.withOpacity(0.12),
                  blurRadius: 30.0,
                  offset: Offset(0, -10),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20.0),
                topRight: Radius.circular(20.0),
              ),
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 30, right: 30, bottom: 0, top: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(bottomItems.length, (index) {
                    return InkWell(
                        onTap: () {
                          selectedTab(index);
                        },
                        // this method shows the right icons with text based on the app state (if the icon is entered or not)
                        child: Column(
                          children: [
                            SvgPicture.asset(
                              widget.pageIndex == index
                                  ? bottomItems2[index]
                                  : bottomItems[index],
                              height: bottomItems[index] ==
                                      "assets/images/pendingVideos.svg"
                                  ? 32
                                  : 25,
                              width: 30,
                              color: widget.pageIndex == index //entered
                                  ? (phoneVerfied // if the phone verfied make all icons green
                                      ? GlobalColors.mainColorGreen
                                      :
                                      // if not verfied make all the icons green except the settings icon red
                                      (bottomItems[index] ==
                                                  "assets/images/settings-svgrepo-com-warning.svg" ||
                                              bottomItems2[index] ==
                                                  "assets/images/settings-svgrepo-com-warning2.svg")
                                          ? GlobalColors.mainColorRed
                                          : GlobalColors.mainColorGreen)
                                  :
                                  //not entered
                                  (phoneVerfied
                                      ? secondary // make all the icons grey
                                      : (bottomItems[index] ==
                                                  "assets/images/settings-svgrepo-com-warning.svg" ||
                                              bottomItems2[index] ==
                                                  "assets/images/settings-svgrepo-com-warning2.svg")
                                          ? GlobalColors.mainColorRed
                                          : secondary),
                            ),
                            bottomItems[index] ==
                                    "assets/images/pendingVideos.svg"
                                ? SizedBox(
                                    height: 5.0,
                                  )
                                : SizedBox(height: 0),
                            Text(
                              textBar[index],
                              style: TextStyle(fontSize: 9, color: Colors.grey),
                            ),
                            SizedBox(
                              height: 14.0,
                            ),
                          ],
                        ));
                  }),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

// assign the value of the index to page index
  selectedTab(index) {
    setState(() {
      widget.pageIndex = index;
    });
  }
}
