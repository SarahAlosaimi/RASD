import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:rasd/appRoot.dart';
import 'package:rasd/auth.dart';
import 'package:rasd/pages/settings/account.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/objects/driver.dart';
import 'package:rasd/shared/padding.dart';
import 'package:rasd/objects/video.dart';
import 'package:rasd/objects/report.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:rasd/shared/widgets/url_tex.dart';

import 'EditFile.dart';

class confirmed extends StatefulWidget {
  const confirmed({
    Key? key,
  }) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _confirmedWidgetState createState() => _confirmedWidgetState();
}

class _confirmedWidgetState extends State<confirmed> {
  bool arLnag = 'CVR'.tr == 'Confirmed Violation Reports'
      ? false
      : true; // to get if the current page was arabic or english

  final User? user = Auth().currentUser; // to get access to the current user
  List<report> reportListTest = []; // to list reports

  //###############################retrive all reports of the user#####################################
  Future<List<report>> retriveConfirmed() async {
    final QuerySnapshot<Map<String, dynamic>> ConfirmedReportsQuery =
        await FirebaseFirestore.instance
            .collection("drivers")
            .doc(user?.uid)
            .collection("reports")
            .where('status', whereIn: [
      1,
      2
    ]).get(); //get all documents in sub collections (get all reports)
    final List<report> allConfirmedreports = ConfirmedReportsQuery.docs
        .map((ConfirmedReportsDoc) => report.fromSnapShot(ConfirmedReportsDoc))
        .toList(); // convirt them to list in order to display them
    if (mounted) {
      setState(() {
        reportListTest = allConfirmedreports;
      });
    }
    return allConfirmedreports;
  }

  //###############################Display  a single report in pdf #####################################

  void pushReports(report report) {
    // if the driver clicks on single report
    arLnag
        ? _displayPdf(report, user!.uid)
        : _displayPdfen(
            report,
            user!
                .uid); // we have two method for displaying the report : 1- arabic , 2- english
  }

  //####################################################################################################
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // confirmed report display page
      body: Container(
        // the green background
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            GlobalColors.mainColorGreen,
            GlobalColors.secondaryColorGreen
          ], begin: const FractionalOffset(0.0, 0.4), end: Alignment.topRight),
        ),
        child: Column(
          children: [
            Container(
              //for elemnts on the top
              padding: const EdgeInsets.only(top: 18, right: 20, left: 20),
              width: MediaQuery.of(context).size.width,
              height: 180,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Container()),
                      Container(
                          padding: const EdgeInsets.only(top: 15),
                          width: spacer,
                          child: Image.asset(
                            'assets/images/logoWhite.png',
                          )),
                    ],
                  ),
                  const SizedBox(
                    height: 0.2,
                  ),
                  Text(
                    "CVR".tr,
                    style: TextStyle(
                        fontSize: 25,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Send".tr,
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
                child: Container(
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(70),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(
                        3.0,
                        8.0,
                      ), //Offset
                      blurRadius: 10.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                  ]),
              child: Column(
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  //the big white box is represented by this row
                  Row(),
                  Expanded(
                    child: _listView(), // to list the reports
                  )
                ],
              ),
            ))
          ],
        ),
      ),
    );
  }

//###################################display cards (reports) ##########################################
  _listView() {
    retriveConfirmed(); // retrives all the confirmed report in the driver document
    return reportListTest.length ==
            0 // if there was no reports in the driver document yet in the firebase then display that there is nothing in this page currently
        ? Container(
            padding: const EdgeInsets.only(
              left: 5,
            ),
            child: Column(children: [
              Column(
                children: [
                  const SizedBox(
                    height: 100,
                  ),
                  Stack(alignment: Alignment.center, children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          GlobalColors.mainColorGreen,
                          GlobalColors.secondaryColorGreen,
                        ],
                        tileMode: TileMode.clamp,
                      ).createShader(bounds),
                      child: const Icon(
                        Icons.file_copy_outlined,
                        size: 100,
                        color: Colors.white,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.only(top: 35, left: 10),
                      child: ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            GlobalColors.mainColorGreen,
                            GlobalColors.secondaryColorGreen,
                          ],
                          tileMode: TileMode.clamp,
                        ).createShader(bounds),
                        child: const Icon(
                          Icons.close_rounded,
                          size: 33,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ]),
                  const SizedBox(
                    height: 30,
                  ),
                  Column(
                    children: [
                      Text(
                        "NVR".tr,
                        style: TextStyle(
                            color: GlobalColors.secondaryColorGreen,
                            fontWeight: FontWeight.bold,
                            fontSize: 20),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 70),
                        child: Text(
                          "NVRA".tr,
                          style: TextStyle(
                              color: GlobalColors.textColor, fontSize: 15),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ]),
          )
        : ListView.builder(
            // else list the report row in the page using 'buikdCard' method
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 8),
            itemCount: reportListTest.length,
            itemBuilder: (_, int index) {
              return GestureDetector(
                child: _buildCard(index + 1),
              );
            });
  }

  //######################################this is for the single card############################################

  _buildCard(int index) {
    // recived the index of the report
    // to calculate the countdown
    var reportday = reportListTest[index - 1].date;
    var reportFullDate = reportListTest[index - 1].date;
    // creation date
    reportday = reportday.substring(0, 2);
    // the day
    var formatter = DateFormat.d().format(DateTime.now()); // current day
    var reportdayInt = int.parse(reportday); // parse creation day to integer
    var currentDay = int.parse(formatter); // parse current day to integer
    var deleteCountDown = 30 -
        (currentDay -
            reportdayInt); // substract from 30 since we will delete it after 30 days
    var days = '';
    if (deleteCountDown > 1) {
      //  if it was more than 1 day then 'days'
      days = 'days'.tr;
    } else {
      days = 'day'.tr;
    }
    return Container(
      height: 100,
      width: 200,
      child: Column(children: [
        const SizedBox(
          height: 20,
        ),
        Flexible(
          flex: 1,
          child: Container(
            child: TextButton(
              onPressed: () {
                // if the report clicked then display the pdf document
                pushReports(reportListTest[index - 1]);
                // _VerPhone();
              },
              child: Row(
                children: [
                  Container(
                    child: Icon(
                      Icons.file_copy_outlined,
                      size: 40,
                      color: GlobalColors.mainColorGreen,
                    ),
                  ),
                  const SizedBox(
                    width: 12,
                  ),
                  Flexible(
                    child: Container(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 230,
                                // alignment: Alignment.topLeft,
                                child: Text(
                                  "VR".tr + " $index",
                                  style: TextStyle(
                                      color: GlobalColors.mainColorGreen,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                                "Violationdate".tr + reportFullDate,
                                style: TextStyle(
                                  color: GlobalColors.mainColorGreen,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 11.5,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 9,
                          ),
                          Container(
                            padding: arLnag
                                ? EdgeInsets.only(left: 10)
                                : EdgeInsets.only(right: 0),
                            width: arLnag ? 280 : 400,
                            child: Align(
                              alignment: arLnag
                                  ? Alignment.bottomRight
                                  : Alignment.bottomLeft,
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        "celCountR".tr +
                                            deleteCountDown.toString() +
                                            " " +
                                            days,
                                        style: TextStyle(
                                          color: GlobalColors.mainColorRed,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 11.5,
                                        ),
                                        textAlign: TextAlign.left,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(vertical: 1),
          child: Row(
            children: [
              Flexible(
                child: Container(
                  width: 30,
                  height: 5,
                ),
              ),
              Row(
                children: [
                  for (int i = 0; i < 125; i++)
                    i.isEven
                        ? Container(
                            width: 2,
                            height: 1,
                            decoration: BoxDecoration(
                              color: GlobalColors.mainColorRed,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          )
                        : Container(
                            width: 2,
                            height: 1,
                          ),
                ],
              ),
            ],
          ),
          //  ),
        ),
      ]),
    );
  }

  //#####################################display a pdf document (arabic version) ###############################################
  void _displayPdf(report reportDoc, String userDocid) async {
    // Retrive URL
    // retrive all documents from video

    final QuerySnapshot<Map<String, dynamic>> docVideo = await FirebaseFirestore
        .instance
        .collection("drivers")
        .doc(user!.uid)
        .collection("reports")
        .doc(reportDoc.id)
        .collection("video")
        .get();
    // convert from snapshot to list of documents then get the first documnet then get the video url
    var video_url = docVideo.docs
        .map((reportVid) => video.fromSnapShot(reportVid))
        .toList()[0]
        .video_url;

    // Retrive Driver's Name
    Driver d;
    final docUser = await FirebaseFirestore.instance
        .collection("drivers")
        .doc(user!.uid)
        .get();
    String name = '';

    if (docUser.exists) {
      d = Driver.fromJsonD(docUser.data()!);
      name = d.Fname.capitalize! +
          ' ' +
          d.Lname
              .capitalize!; // save the driver full name to display it in the report
    }

    // Retrive Email
    String email = '';
    email = user!.email!;

    // Retrive PhoneNumber
    String PhoneNumber = '';
    d = Driver.fromJsonD(docUser.data()!);
    PhoneNumber = d.phone_number;

    // Retrive phone verfeification
    bool phoneVer;
    d = Driver.fromJsonD(docUser.data()!);
    phoneVer = d.phoneVerfied;

    // Retrive Violation Type
    report r;
    final docReport = await FirebaseFirestore.instance
        .collection("drivers")
        .doc(user!.uid)
        .collection("reports")
        .doc(reportDoc.id)
        .get();
    String v_type = '';
    String addInfo = '';
    String date = '';
    String time = '';
    bool thereIsAddInfo = false;
    if (docReport.exists) {
      r = report.fromJsonD(docReport.data()!);

      v_type = r.v_type;
      addInfo = r.addInfo;
      date = r.date;
      time = r.time;

      if (v_type == "") {
        // if the user did not select any violation type
        v_type = "NotSelected".tr;
      } else {
        //if the user select a violation type
        v_type = v_type.substring(0, v_type.length - 1);
      }

      if (addInfo == "") {
        thereIsAddInfo = false;
      } else {
        thereIsAddInfo = true;
      }
    }

    final rasdLogo = pw.MemoryImage(
        (await rootBundle.load('assets/images/logoWhite.png'))
            .buffer
            .asUint8List());

    var arabicFont = pw.Font.ttf(await rootBundle
        .load("assets/fonts/Tajawal-Medium.ttf")); // to load the font
    final pdf = pw.Document(); // to start a document
    pdf.addPage(
      // add page
      pw.Page(
        theme: pw.ThemeData.withFont(
          // set the font
          base: arabicFont,
        ),
        margin: pw.EdgeInsets.symmetric(
          horizontal: 1,
        ),
        pageFormat: PdfPageFormat.a4, // the format of the pdf is A4
        build: (context) {
          return pw.Column(
            children: [
              // list that holds all the element of the pdf
              /*--------------------------------------- Header of the report ---------------------------------------*/
              pw.Container(
                width: 595,
                height: 120,
                decoration: pw.BoxDecoration(
                  color: PdfColor.fromHex('#045341'),
                ),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Padding(
                      padding: pw.EdgeInsets.only(left: 10),
                      child: pw.Expanded(
                        flex: 1,
                        child: pw.SizedBox(
                          height: 100,
                          width: 150,
                          child: pw.Image(rasdLogo),
                        ),
                      ),
                    ),
                    pw.Padding(
                      padding: pw.EdgeInsets.only(right: 20),
                      child: pw.Expanded(
                        flex: 1,
                        child: pw.Directionality(
                          textDirection: pw.TextDirection.rtl,
                          child: pw.Text(
                            textAlign: pw.TextAlign.right,
                            "ViolationRep".tr,
                            style: pw.TextStyle(
                              fontSize: 26,
                              color: PdfColors.white,
                              // fontWeight: pw.FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              pw.SizedBox(
                height: 30,
              ),
              /*--------------------------------------- Description of the report ---------------------------------------*/
              pw.Container(
                padding: pw.EdgeInsets.only(right: 20),
                child: pw.Align(
                  alignment: pw.Alignment.centerRight,
                  child: pw.Directionality(
                    textDirection: pw.TextDirection.rtl,
                    child: pw.Text(
                      textAlign: pw.TextAlign.right,
                      'des'.tr,
                      style: pw.TextStyle(
                        fontSize: 24,
                      ),
                    ),
                  ),
                ),
              ),
              pw.SizedBox(
                height: 5,
              ),
              pw.Divider(
                // a line to devide between the elements
                color: PdfColors.black,
              ),
              pw.SizedBox(
                height: 60,
              ),
              /*--------------------------------------- table for the name and number ---------------------------------------*/
              pw.Container(
                margin: pw.EdgeInsets.only(left: 10, right: 10),
                child: pw.Table(
                  border: pw.TableBorder.all(
                    color: PdfColors.black,
                    style: pw.BorderStyle.solid,
                    width: 2,
                  ),
                  children: [
                    pw.TableRow(
                      children: [
                        //phoneNumber //*
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            color: PdfColor.fromHex('#045341'),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    'PhoneNum'.tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            color: PdfColor.fromHex('#045341'),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.right,
                                    "name".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      children: [
                        // //phone number
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    PhoneNumber,
                                    style: pw.TextStyle(
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        pw.Expanded(
                          child: pw.Container(
                            height: 45,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    name,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              /*--------------------------------------- table with a single row  for the email ---------------------------------------*/ // email row
              pw.Container(
                  margin: pw.EdgeInsets.only(left: 10, right: 10),
                  child: pw.Table(
                    columnWidths: {
                      0: pw.FractionColumnWidth(.6),
                      1: pw.FractionColumnWidth(.4),
                    },
                    border: pw.TableBorder.all(
                      color: PdfColors.black,
                      style: pw.BorderStyle.solid,
                      width: 2,
                    ),
                    children: [
                      //change email row place
                      pw.TableRow(
                        children: [
                          pw.Expanded(
                            child: pw.Container(
                              height: 45,
                              child: pw.Column(
                                crossAxisAlignment:
                                    pw.CrossAxisAlignment.center,
                                mainAxisAlignment: pw.MainAxisAlignment.center,
                                children: [
                                  pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    email,
                                    style: pw.TextStyle(
                                      fontSize: 20,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          pw.Expanded(
                            child: pw.Container(
                              height: 50,
                              color: PdfColor.fromHex('#045341'),
                              child: pw.Column(
                                crossAxisAlignment:
                                    pw.CrossAxisAlignment.center,
                                mainAxisAlignment: pw.MainAxisAlignment.center,
                                children: [
                                  pw.Directionality(
                                    textDirection: pw.TextDirection.rtl,
                                    child: pw.Text(
                                      textAlign: pw.TextAlign.left,
                                      'email'.tr,
                                      style: pw.TextStyle(
                                        fontSize: 22,
                                        color: PdfColors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  )),

              pw.SizedBox(height: 30),
              /*--------------------------------------- table for the violation info (time - date, violation type, violation link and any added info) ---------------------------------------*/ // email row
              pw.Container(
                margin: pw.EdgeInsets.only(left: 10, right: 10),
                child: pw.Table(
                  columnWidths: {
                    0: pw.FractionColumnWidth(.6),
                    1: pw.FractionColumnWidth(.4),
                  },
                  border: pw.TableBorder.all(
                    color: PdfColors.black,
                    style: pw.BorderStyle.solid,
                    width: 2,
                  ),
                  children: [
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    date + " | " + time,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            color: PdfColor.fromHex('#045341'),
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "VTime".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                UrlText('Violation Video Link', video_url),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            color: PdfColor.fromHex('#045341'),
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "link".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            height: 80,
                            padding: pw.EdgeInsets.only(left: 10),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    v_type,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            color: PdfColor.fromHex('#045341'),
                            height: 80,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "viotype".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    //addInfo row***********
                    thereIsAddInfo
                        ? pw.TableRow(
                            children: [
                              pw.Expanded(
                                child: pw.Container(
                                  height: 80,
                                  padding: pw.EdgeInsets.only(left: 10),
                                  child: pw.Column(
                                    crossAxisAlignment:
                                        pw.CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        pw.MainAxisAlignment.center,
                                    children: [
                                      pw.Directionality(
                                        textDirection: pw.TextDirection.rtl,
                                        child: pw.Text(
                                          textAlign: pw.TextAlign.left,
                                          addInfo,
                                          style: pw.TextStyle(
                                            fontSize: 22,
                                            color: PdfColors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              pw.Expanded(
                                child: pw.Container(
                                  color: PdfColor.fromHex('#045341'),
                                  height: 80,
                                  child: pw.Column(
                                    crossAxisAlignment:
                                        pw.CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        pw.MainAxisAlignment.center,
                                    children: [
                                      pw.Directionality(
                                        textDirection: pw.TextDirection.rtl,
                                        child: pw.Text(
                                          textAlign: pw.TextAlign.left,
                                          "addInfo".tr,
                                          style: pw.TextStyle(
                                            fontSize: 22,
                                            color: PdfColors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        : pw.TableRow(children: []),
                  ],
                ),
              ),
              pw.SizedBox(height: 45),

              // ),
            ],
          );
        },
      ),
    );

    /// open Preview Screen
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PreviewScreen(
            // **I changed here because i need reportID and userID for delete report
            doc: pdf,
            ReportdocID: reportDoc.id,
            ReportStatus: reportDoc.status,
            UserdocID: userDocid,
            phoneVer: phoneVer,
          ),
        ));
  }

  //#####################################display a pdf document (english version) ###############################################

  void _displayPdfen(report reportDoc, String userDocid) async {
    var now = DateTime.now();
    var formatter = DateFormat.yMd('en_US').add_jm();
    String formattedDate = formatter.format(now);
    //Retrive URL
    // retrive all documents from video
    final QuerySnapshot<Map<String, dynamic>> docVideo = await FirebaseFirestore
        .instance
        .collection("drivers")
        .doc(user!.uid)
        .collection("reports")
        .doc(reportDoc.id)
        .collection("video")
        .get();
    // convert from snapshot to list of documents then get the first documnet then get the video url
    var video_url = docVideo.docs
        .map((reportVid) => video.fromSnapShot(reportVid))
        .toList()[0]
        .video_url;

    //Retrive Driver's Name
    Driver d;
    final docUser = await FirebaseFirestore.instance
        .collection("drivers")
        .doc(user!.uid)
        .get();
    String name = '';
    if (docUser.exists) {
      d = Driver.fromJsonD(docUser.data()!);
      name = d.Fname.capitalize! + ' ' + d.Lname.capitalize!;
    }

    //Retrive Email
    String email = '';
    email = user!.email!;

    //Retrive PhoneNumber
    String PhoneNumber = '';
    d = Driver.fromJsonD(docUser.data()!);
    PhoneNumber = d.phone_number;

    //Retrive phone verfeification
    bool phoneVer;
    d = Driver.fromJsonD(docUser.data()!);
    phoneVer = d.phoneVerfied;

    //Retrive Violation Type and Additional information
    report r;
    final docReport = await FirebaseFirestore.instance
        .collection("drivers")
        .doc(user!.uid)
        .collection("reports")
        .doc(reportDoc.id)
        .get();
    String v_type = '';
    String addInfo = '';
    String date = '';
    String time = '';
    bool thereIsAddInfo =
        false; // to check if the driver entered addtional information

    if (docReport.exists) {
      r = report.fromJsonD(docReport.data()!);
      v_type = r.v_type;
      addInfo = r.addInfo;
      date = r.date;
      time = r.time;

      if (v_type == "") {
        // if the user did not select any violation type
        v_type = "NotSelected".tr;
      } else {
        // if the user  select any violation type
        v_type = v_type.substring(0, v_type.length - 1);
      }

      if (addInfo == "") {
        thereIsAddInfo = false;
      } else {
        thereIsAddInfo = true;
      }
    }

    final rasdLogo = pw.MemoryImage(
        (await rootBundle.load('assets/images/logoWhite.png'))
            .buffer
            .asUint8List());
    final wave = pw.MemoryImage(
        (await rootBundle.load('assets/images/wave5.png'))
            .buffer
            .asUint8List());
    var arabicFont =
        pw.Font.ttf(await rootBundle.load('assets/fonts/Tajawal-Medium.ttf'));
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        theme: pw.ThemeData.withFont(
          base: arabicFont,
        ),
        margin: pw.EdgeInsets.symmetric(
          horizontal: 1,
        ),
        pageFormat: PdfPageFormat.a4,
        build: (context) {
          return pw.Column(
            children: [
              pw.Container(
                width: 595,
                height: 120,
                decoration: pw.BoxDecoration(
                  color: PdfColor.fromHex('#045341'),
                ),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Padding(
                      padding: pw.EdgeInsets.only(left: 20),
                      child: pw.Expanded(
                        flex: 1,
                        child: pw.Directionality(
                          textDirection: pw.TextDirection.rtl,
                          child: pw.Text(
                            "ViolationRep".tr,
                            style: pw.TextStyle(
                              fontSize: 24,
                              color: PdfColors.white,
                              fontWeight: pw.FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    pw.Padding(
                      padding: pw.EdgeInsets.only(right: 10),
                      child: pw.Expanded(
                        flex: 1,
                        child: pw.SizedBox(
                          height: 100,
                          width: 150,
                          child: pw.Image(rasdLogo),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              pw.SizedBox(
                height: 30,
              ),
              pw.Align(
                alignment: pw.Alignment.centerLeft,
                child: pw.Directionality(
                  textDirection: pw.TextDirection.rtl,
                  child: pw.Text(
                    textAlign: pw.TextAlign.left,
                    'des'.tr,
                    style: pw.TextStyle(
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              pw.SizedBox(
                height: 5,
              ),
              pw.Divider(
                color: PdfColors.black,
              ),
              pw.SizedBox(
                height: thereIsAddInfo ? 60 : 50,
              ),
              pw.Container(
                margin: pw.EdgeInsets.only(left: 10, right: 10),
                child: pw.Table(
                  border: pw.TableBorder.all(
                    color: PdfColors.black,
                    style: pw.BorderStyle.solid,
                    width: 2,
                  ),
                  children: [
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            color: PdfColor.fromHex('#045341'),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "name".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        //phoneNumber //*
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            color: PdfColor.fromHex('#045341'),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    'PhoneNum'.tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    name,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  textAlign: pw.TextAlign.left,
                                  PhoneNumber,
                                  style: pw.TextStyle(
                                    fontSize: 20,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              //email row
              pw.Container(
                  margin: pw.EdgeInsets.only(left: 10, right: 10),
                  child: pw.Table(
                    columnWidths: {
                      0: pw.FractionColumnWidth(.4),
                      1: pw.FractionColumnWidth(.6),
                    },
                    border: pw.TableBorder.all(
                      color: PdfColors.black,
                      style: pw.BorderStyle.solid,
                      width: 2,
                    ),
                    children: [
                      //change email row place
                      pw.TableRow(
                        children: [
                          pw.Expanded(
                            child: pw.Container(
                              height: 50,
                              color: PdfColor.fromHex('#045341'),
                              child: pw.Column(
                                crossAxisAlignment:
                                    pw.CrossAxisAlignment.center,
                                mainAxisAlignment: pw.MainAxisAlignment.center,
                                children: [
                                  pw.Directionality(
                                    textDirection: pw.TextDirection.rtl,
                                    child: pw.Text(
                                      textAlign: pw.TextAlign.left,
                                      'email'.tr,
                                      style: pw.TextStyle(
                                        fontSize: 22,
                                        color: PdfColors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          pw.Expanded(
                            child: pw.Container(
                              height: 50,
                              child: pw.Column(
                                crossAxisAlignment:
                                    pw.CrossAxisAlignment.center,
                                mainAxisAlignment: pw.MainAxisAlignment.center,
                                children: [
                                  pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    email,
                                    style: pw.TextStyle(
                                      fontSize: 20,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  )),

              pw.SizedBox(height: 30),

              pw.Container(
                margin: pw.EdgeInsets.only(left: 10, right: 10),
                child: pw.Table(
                  columnWidths: {
                    0: pw.FractionColumnWidth(.4),
                    1: pw.FractionColumnWidth(.6),
                  },
                  border: pw.TableBorder.all(
                    color: PdfColors.black,
                    style: pw.BorderStyle.solid,
                    width: 2,
                  ),
                  children: [
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            color: PdfColor.fromHex('#045341'),
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "VTime".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    date + " | " + time,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            color: PdfColor.fromHex('#045341'),
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "link".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            height: 50,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                UrlText('Violation Video Link', video_url),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      children: [
                        pw.Expanded(
                          child: pw.Container(
                            color: PdfColor.fromHex('#045341'),
                            height: 80,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    "viotype".tr,
                                    style: pw.TextStyle(
                                      fontSize: 22,
                                      color: PdfColors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        pw.Expanded(
                          child: pw.Container(
                            height: 80,
                            padding: pw.EdgeInsets.only(left: 10),
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.center,
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Directionality(
                                  textDirection: pw.TextDirection.rtl,
                                  child: pw.Text(
                                    textAlign: pw.TextAlign.left,
                                    v_type,
                                    style: pw.TextStyle(
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    //###################more information row##################
                    thereIsAddInfo
                        ? pw.TableRow(
                            children: [
                              pw.Expanded(
                                child: pw.Container(
                                  color: PdfColor.fromHex('#045341'),
                                  height: 60,
                                  child: pw.Column(
                                    crossAxisAlignment:
                                        pw.CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        pw.MainAxisAlignment.center,
                                    children: [
                                      pw.Directionality(
                                        textDirection: pw.TextDirection.rtl,
                                        child: pw.Text(
                                          textAlign: pw.TextAlign.left,
                                          "addInfo".tr,
                                          style: pw.TextStyle(
                                            fontSize: 22,
                                            color: PdfColors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              pw.Expanded(
                                child: pw.Container(
                                  height: 60,
                                  child: pw.Column(
                                    crossAxisAlignment:
                                        pw.CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        pw.MainAxisAlignment.center,
                                    children: [
                                      pw.Directionality(
                                        textDirection: pw.TextDirection.rtl,
                                        child: pw.Text(
                                          textAlign: pw.TextAlign.left,
                                          addInfo,
                                          style: pw.TextStyle(
                                            fontSize: 22,
                                            color: PdfColors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        : pw.TableRow(children: []),
                  ],
                ),
              ),
              pw.SizedBox(height: thereIsAddInfo ? 0 : 30),
              pw.Container(
                width: 1000,
                height: 200,
                child: pw.Row(
                  children: [
                    pw.Padding(
                      padding: pw.EdgeInsets.only(
                        top: 4,
                        left: 0,
                        bottom: 0,
                      ),
                      child: pw.Image(
                        wave,
                        width: 800,
                      ),
                    )
                  ],
                ),
              ),
              // ),
            ],
          );
        },
      ),
    );

    /// open Preview Screen
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PreviewScreen(
            // **I changed here because i need reportID and userID for delete report
            doc: pdf,
            ReportdocID: reportDoc.id,
            ReportStatus: reportDoc.status,
            UserdocID: userDocid,
            phoneVer: phoneVer,
          ),
        ));
  }
}

class PreviewScreen extends StatelessWidget {
  final pw.Document doc;
  final String ReportdocID;
  final String UserdocID;
  final int ReportStatus;
  final bool phoneVer;

  const PreviewScreen({
    Key? key,
    // **I changed here because i need reportID and userID for delete report
    required this.doc,
    required this.ReportdocID,
    required this.UserdocID,
    required this.ReportStatus,
    required this.phoneVer,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool delete = false;
    bool arLnag = 'Preview'.tr == 'Preview' ? false : true;

    //############################################show sucess dialog (After deletion) #################################
    void _showSucess() {
      AwesomeDialog(
          context: context,
          btnCancelColor: Colors.grey,
          btnOkColor: GlobalColors.secondaryColorGreen,
          dialogType: DialogType.success,
          animType: AnimType.scale,
          headerAnimationLoop: false,
          dismissOnTouchOutside: false,
          title: 'success'.tr,
          desc: 'Rdelete'.tr,
          btnOkText: 'Ok'.tr,
          btnOkOnPress: () {
            // to go back to the confirmed page
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => RootApp(
                          pageIndex: 2,
                        )));
          }).show();
    }

    Future<void> _VerPhone() async {
      AwesomeDialog(
          context: context,
          btnCancelColor: Colors.grey,
          btnOkColor: GlobalColors.secondaryColorGreen,
          dialogType: DialogType.noHeader,
          animType: AnimType.scale,
          dismissOnTouchOutside: true,
          headerAnimationLoop: false,
          title: 'verfPhoneNumberDialog'.tr,
          desc: "verfPhoneNumbertoShare".tr,
          btnOkText: 'Ok'.tr,
          btnOkOnPress: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => account(
                          uid: UserdocID,
                        )));
          }).show();
    }

    //delete report with the video
    //############################################show delete dialog (before deletion) #################################

    Future<void> _showMyDialogDelete() async {
      return AwesomeDialog(
          context: context,
          btnCancelColor: Colors.grey,
          btnOkColor: GlobalColors.secondaryColorRed,
          dialogType: DialogType.noHeader,
          animType: AnimType.scale,
          headerAnimationLoop: false,
          dismissOnTouchOutside: false,

          // barrierColor: GlobalColors.mainColorGreen,
          title: 'Sure'.tr,
          desc: 'delConfreport'.tr,
          btnOkText: "yes".tr,
          btnCancelText: 'C'.tr,
          btnCancelOnPress: () {
            delete = false;
          }, // will stay in the same page
          btnOkOnPress: () async {
            //he/she wants to delete it
            delete = true;
            if (delete) {
              //############################################delete report after pressing yes #################################

              final reportDoc = FirebaseFirestore.instance
                  .collection("drivers")
                  .doc(UserdocID)
                  .collection("reports")
                  .doc(ReportdocID);

              //get video
              final QuerySnapshot<
                  Map<String,
                      dynamic>> VideoDocInReport = await FirebaseFirestore
                  .instance
                  .collection("drivers")
                  .doc(UserdocID)
                  .collection("reports")
                  .doc(ReportdocID)
                  .collection("video")
                  .get(); //get all documents in sub collections (get all videos)
              final List<video> Vid = VideoDocInReport.docs
                  .map((Videos) => video.fromSnapShot(Videos))
                  .toList();

              for (var doc in VideoDocInReport.docs) // delete sub colletcio
              {
                await doc.reference.delete();
              }

              reportDoc.delete(); // delete report

              _showSucess();
            }
          }).show();
    }

//#######################this for disabling share button

    Future<void> UpdateStatus() async {
      final docReport = await FirebaseFirestore.instance
          .collection("drivers")
          .doc(UserdocID)
          .collection("reports")
          .doc(ReportdocID)
          .update({'status': 2});
    }

    ///////////////////////////////till here///////////////////////////////////////////////
    return Scaffold(
      // pdf page headder and the bar
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios_rounded,
            size: 30,
          ),
        ),
        title: Text('Preview'.tr),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: FractionalOffset(0.0, 0.4),
                end: Alignment.topRight,
                colors: <Color>[
                  GlobalColors.mainColorGreen,
                  GlobalColors.secondaryColorGreen
                ]),
          ),
        ),
      ),

      body: PdfPreview(
        build: (format) => doc.save(),
        allowSharing: false, // disable the share button
        allowPrinting: false, // disable the printing option
        canChangeOrientation: false,
        canChangePageFormat: false,
        canDebug: false,
        initialPageFormat: PdfPageFormat.a4,
        scrollViewDecoration: BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[
              Color.fromARGB(255, 255, 255, 255),
              Color.fromARGB(255, 255, 255, 255)
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        pdfFileName: "filename".tr + ".pdf", // name of the generated report
        actions: [
          // Delete button

          Container(
            width: 50,
            padding: EdgeInsets.only(top: 8),
            child: GestureDetector(
              child: Icon(
                Icons.delete_forever,
                color: Colors.white,
                size: 30,
              ),
              onTap: () async {
                // if the driver clicks on the delete option then display a confirmation dialog
                _showMyDialogDelete();
              },
            ),
          ),
          Container(
            width: 150,
            child: phoneVer
                ? PdfShareAction(
                    // to customize the share option and the email
                    icon: arLnag
                        ? new Image.asset(
                            "assets/images/shareIconAr.png",
                          )
                        : new Image.asset(
                            "assets/images/shareIconEn.png",
                          ),
                    body: 'body'.tr,
                    emails: ['group9.gp1444@gmail.com'],
                    filename: "filename".tr + ".pdf",
                    subject: 'subject'.tr,
                    onShared: () {
                      UpdateStatus();
                    },
                  )
                : GestureDetector(
                    child: arLnag
                        ? new Image.asset(
                            "assets/images/shareIconAr.png",
                          )
                        : new Image.asset(
                            "assets/images/shareIconEn.png",
                          ),
                    onTap: () async {
                      // go to the edit page to modifiy the information if needed
                      _VerPhone();
                    },
                  ),
          ),

          //Edit button
          Container(
            width: 50,
            padding: EdgeInsets.only(top: 8),
            child: GestureDetector(
              child: Icon(
                Icons.edit,
                color: Colors.white,
                size: 30,
              ),
              onTap: () async {
                // go to the edit page to modifiy the information if needed
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => EditFile(
                              reportDocid: ReportdocID,
                              userDocid: UserdocID,
                            )));
              },
            ),
          ),
        ],
        // loading
        loadingWidget: Container(
          padding: EdgeInsets.only(bottom: 50, top: 200),
          child: Column(
            children: [
              Stack(alignment: Alignment.center, children: [
                Container(
                  height: 50,
                  child: Image.asset(
                    'assets/images/loadingLogoBlack.png', //make it pop up
                    height: 105,
                    width: 105,
                  ),
                ),
                Container(
                  height: 35,
                  width: 35,
                  padding: EdgeInsets.only(left: 3),
                  child: CircularProgressIndicator(
                    color: Colors.black,
                  ),
                ),
              ]),
              SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
