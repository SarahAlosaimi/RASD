//This class for link/edit dashcam page
import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:optimize_battery/optimize_battery.dart';
import 'package:rasd/appRoot.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/shared/widgets/textFormGlobal.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:rasd/shared/Stream/streamStatucCheck.dart';
import 'package:rasd/shared/Stream/streamVidLink.dart';

class LinkPage extends StatefulWidget {
  @override
  final String uid;
  final bool linked;

  const LinkPage({super.key, required this.uid, required this.linked});

  State<LinkPage> createState() => _LinkPageState();
}

class _LinkPageState extends State<LinkPage> {
  final GlobalKey<FormState> _formKeyLink =
      GlobalKey<FormState>(); //for ip only
  final GlobalKey<FormState> _formKeyLink2 =
      GlobalKey<FormState>(); //for ip,admin, and pass
  final TextEditingController Dashcam_id = TextEditingController();
  final TextEditingController Dashcam_username = TextEditingController();
  final TextEditingController Dashcam_pass = TextEditingController();

  String? errorMessage = '';
  bool isLogin = true; // status of the log in
  String dashcam_id_num = ""; // dashcam ip
  String dashcam_un = ""; // dashcam username
  String dashcam_ps = ""; // dashcam password
  //error messages to be displayed if encountered error
  String? errorMessageData = '';
  String? errorMessageValid = '';
  bool isDataBasEerrorMessage = true;
  bool arLnag = "IP".tr == 'Enter your dashcam IP'
      ? false
      : true; // determind which langanuage is displayed now , false -- > en , true ---> arabic

  String RTSPurl = ''; // rtsp link variable to be used later to show the stream
  var ipOnly =
      1; //0-->  no (dashcam have username , password ),  1 yes --> ip only
  bool? live; // is the stream live? yes : true , no : false
  Timer? streamUpdate; // timer to update the stream
  bool isVisibleLogin =
      true; //for the passwrod view option (the eye icon) - log In page
  bool showPassClickedLogin =
      false; //fot the password wether it is shown to the user or not  - in log In page

  // Dispose releases the memory allocated to the existing variables of the state.
  @override
  void dispose() {
    streamUpdate?.cancel();
    super.dispose();
  }

  // Check the ip , username , pass of the dashcam if it is valid or not
  // valid --> true  , unvalid --> False

  bool checkValidation(GlobalKey<FormState> _formKey) {
    bool Validity = true;
    if (_formKey.currentState!.validate()) {
      isDataBasEerrorMessage = true;
      Validity = true;
    } else {
      isDataBasEerrorMessage = false;
      Validity = false;
    }
    return Validity;
  }

// The first tool tip shows the driver how to get the information needed (the IP addreess) to connect the dashcam to the application * This tool tip for ip only dashcam
  Widget toolTip() {
    return TextButton(
        onPressed: () {
          AwesomeDialog(
                  context: context,
                  btnCancelColor: Colors.grey,
                  btnOkColor: GlobalColors.secondaryColorGreen,
                  dialogType: DialogType.noHeader,
                  body: Center(
                      child: Column(
                    children: [
                      Text(
                        'perfectView'.tr,
                        style: TextStyle(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/modelPerfectView.jpg',
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        'FindIP'.tr,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text("FirstIPInstruction".tr),
                      SizedBox(
                        height: 10,
                      ),
                      //shows the picture based on the lanaguage
                      arLnag
                          ? Container(
                              width: 250,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color.fromRGBO(224, 224, 224, 1))),
                              child: Image.asset(
                                'assets/images/CellularAR.jpeg',
                              ),
                            )
                          : Container(
                              width: 250,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color.fromRGBO(224, 224, 224, 1))),
                              child: Image.asset(
                                'assets/images/Cellular.jpeg',
                              ),
                            ),
                      Row(
                        children: [Text("\n")],
                      ),
                      Text("SecondIPInstruction".tr),
                      SizedBox(
                        height: 10,
                      ),
                      arLnag
                          ? Container(
                              width: 250,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color.fromRGBO(224, 224, 224, 1))),
                              child: Image.asset(
                                'assets/images/CamWiFiAR.jpeg',
                              ),
                            )
                          : Container(
                              width: 250,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color.fromRGBO(224, 224, 224, 1))),
                              child: Image.asset(
                                'assets/images/CamWiFi.jpeg',
                              ),
                            ),
                      Row(
                        children: [Text("\n")],
                      ),
                      Text("ThirdIPInstruction".tr),
                      SizedBox(
                        height: 10,
                      ),
                      arLnag
                          ? Container(
                              width: 250,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color.fromRGBO(224, 224, 224, 1))),
                              child: Image.asset(
                                'assets/images/routerAR.jpeg',
                              ),
                            )
                          : Container(
                              width: 250,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color.fromRGBO(224, 224, 224, 1))),
                              child: Image.asset(
                                'assets/images/router.jpeg',
                              ),
                            ),
                    ],
                  )),
                  animType: AnimType.scale,
                  btnOkText: 'Ok'.tr,
                  btnOkOnPress: () {})
              .show();
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(padding: EdgeInsets.only(left: 4)),
            Icon(
              Icons.info,
              color: GlobalColors.mainColorGreen,
              size: 20,
            ),
            SizedBox(
              width: 2,
            ),
            Text(
              ipOnly == 0 ? "How2".tr : "How".tr,
              style: TextStyle(color: Colors.grey, fontSize: 16, height: 2),
            ),
          ],
        ));
  }

// The first tool tip shows the driver how to get the information needed ( ip, the username , password ) to connect the dashcam to the application
  Widget SectoolTip() {
    return TextButton(
        onPressed: () {
          chooseInfoToGet();
        },
        child: Row(
          children: [
            Icon(
              Icons.info,
              color: GlobalColors.mainColorGreen,
              size: 20,
            ),
            SizedBox(
              width: 2,
            ),
            Text(
              ipOnly == 0 ? "How2".tr : "How".tr,
              style: TextStyle(color: Colors.grey, fontSize: 16, height: 2),
            ),
          ],
        ));
  } //Tool tip for RTSP link

// Shows a dialog to choose which information the driver wants to get ( IP or Username/password)
  void chooseInfoToGet() {
    AwesomeDialog(
      context: context,
      btnCancelColor: GlobalColors.secondaryColorGreen,
      btnOkColor: GlobalColors.secondaryColorGreen,
      dialogType: DialogType.noHeader,
      body: Center(
          child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Text(
            'whatInfo'.tr,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 5,
          )
        ],
      )),
      animType: AnimType.scale,
      btnOkText: 'U/P'.tr,
      btnOkOnPress: () {
        showIP_UsernamePass_Info(false);
      },
      btnCancelText: 'IPadd'.tr,
      btnCancelOnPress: () {
        showIP_UsernamePass_Info(true);
      },
    ).show();
  }

  //Show a dialog how to get the ip, username ,password with pictures
  void showIP_UsernamePass_Info(bool findIP) {
    findIP
        ? AwesomeDialog(
            context: context,
            btnCancelColor: GlobalColors.secondaryColorGreen,
            btnOkColor: Colors.grey,
            dialogType: DialogType.noHeader,
            body: Center(
                child: Column(
              children: [
                Text(
                  'perfectView'.tr,
                  style: TextStyle(fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  width: 250,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: Color.fromRGBO(224, 224, 224, 1))),
                  child: Image.asset(
                    'assets/images/modelPerfectView.jpg',
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'FindIP'.tr,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text("firstInst".tr),
                SizedBox(
                  height: 10,
                ),
                arLnag
                    ? Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/profileAr.jpeg',
                        ),
                      )
                    : Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/profile.jpg',
                        ),
                      ),
                SizedBox(
                  height: 10,
                ),
                arLnag
                    ? Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/settingsAr.jpeg',
                        ),
                      )
                    : Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/settings.jpg',
                        ),
                      ),
                SizedBox(
                  height: 10,
                ),
                arLnag
                    ? Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/LanLiveViewAr.jpeg',
                        ),
                      )
                    : Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/LanLiveView.jpg',
                        ),
                      ),
                Row(
                  children: [Text("\n")],
                ),
                Text("secInst".tr),
                SizedBox(
                  height: 10,
                ),
                arLnag
                    ? Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/ScanAr.jpeg',
                        ),
                      )
                    : Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/Scan.jpg',
                        ),
                      ),
                Row(
                  children: [Text("\n")],
                ),
                Text("thirdInst".tr),
                SizedBox(
                  height: 10,
                ),
                arLnag
                    ? Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/IPAr.jpeg',
                        ),
                      )
                    : Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/IP.jpeg',
                        ),
                      ),
              ],
            )),
            animType: AnimType.scale,
            btnOkText: 'Exit'.tr,
            btnOkOnPress: () {},
            btnCancelText: 'Return'.tr,
            btnCancelOnPress: () {
              chooseInfoToGet();
            },
          ).show()
        : AwesomeDialog(
            context: context,
            btnCancelColor: GlobalColors.secondaryColorGreen,
            btnOkColor: Colors.grey,
            dialogType: DialogType.noHeader,
            body: Center(
                child: Column(
              children: [
                Text(
                  'findU/P'.tr,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  width: 300,
                  child: Text(
                    "DCusername".tr,
                    textAlign: TextAlign.start,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Text("DCpass".tr),
                SizedBox(
                  height: 10,
                ),
                arLnag
                    ? Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/password.jpeg',
                        ),
                      )
                    : Container(
                        width: 250,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Color.fromRGBO(224, 224, 224, 1))),
                        child: Image.asset(
                          'assets/images/password.jpeg',
                        ),
                      ),
              ],
            )),
            animType: AnimType.scale,
            btnOkText: 'Exit'.tr,
            btnOkOnPress: () {},
            btnCancelText: 'Return'.tr,
            btnCancelOnPress: () {
              chooseInfoToGet();
            },
          ).show();
  }

  //################## link/edit  button ##################
  Widget submitButton(String str) {
    return widget.linked // check if it is already link ,
        // if linked --> show edit page (allow the driver to edit the dashcam info) , if not linked --> show link page (allows the driver to link the dashcam)
        ?
        // ** show the edit button
        Container(
            alignment: Alignment.center,
            height: 47,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [
                      GlobalColors.mainColorGreen,
                      GlobalColors.secondaryColorGreen
                    ]),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color:
                        const Color.fromARGB(225, 4, 99, 65).withOpacity(0.27),
                    blurRadius: 10,
                  ),
                ]),
            child: TextButton(
              //clicking on link
              onPressed: () {
                bool validate =
                    checkValidation(ipOnly == 1 ? _formKeyLink : _formKeyLink2);
                if (validate) {
                  // after clicking on link the user must confirm --> call confirmation dialog
                  _showMyDialog('editMess'.tr);
                }
              },
              style: TextButton.styleFrom(
                primary: Colors.transparent,
              ),
              child: Container(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(top: 3.0),
                  child: Text(
                    str,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          )
        :
        // ** show the link button
        Container(
            alignment: Alignment.center,
            height: 47,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [
                      GlobalColors.mainColorGreen,
                      GlobalColors.secondaryColorGreen
                    ]),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color:
                        const Color.fromARGB(225, 4, 99, 65).withOpacity(0.27),
                    blurRadius: 10,
                  ),
                ]),
            // L
            child: TextButton(
              onPressed: () {
                bool validate =
                    checkValidation(ipOnly == 1 ? _formKeyLink : _formKeyLink2);
                if (validate) {
                  _showMyDialog('linkMess'.tr);
                }
              },
              style: TextButton.styleFrom(
                primary: Colors.transparent,
              ),
              child: Container(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(top: 3.0),
                  child: Text(
                    str,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          );
  } //submitButton

  //################## confirmation dialog ##################
  Future<void> _showMyDialog(String desctr) async {
    var ip = Dashcam_id.text; // dashcam ip
    var username = Dashcam_username.text; // dashcam username
    var pass = Dashcam_pass.text; // dashcam password (plain)
    var data = utf8.encode(pass); // data being hashed (dashcam password)
    var hashvalue = sha1.convert(data);
    if (ipOnly == 1) {
      // mean it is ip only dashcam
      RTSPurl =
          'rtsp://$ip:554/livestream/12'; //RTSP link being initialized to show to stream later
    } else {
      // mean it is ip,username,pass dashcam
      RTSPurl =
          'rtsp://$username:$pass@$ip:554/live'; //RTSP link being initialized to show to stream later
    }

    //update the stream every second
    streamUpdate = Timer.periodic(Duration(seconds: 1), (_) {
      live = streamCheck.statCheckLink.value;
    });
    // check the battery optimization of the device  , true ---> ignoring BatteryOptimization , false -->  not ignoring BatteryOptimization
    final isOptimizationIgnored =
        await OptimizeBattery.isIgnoringBatteryOptimizations();

    // this dialog shows the confirmation of the entered information along with the stream of the dashcam (to show it is linked successfully )
    return AwesomeDialog(
      context: context,
      body: Builder(builder: (context) {
        return Center(
            child: Column(children: [
          Center(
              child: Text(
            'StreamShowingConf'.tr,
            style: TextStyle(
              fontSize: 15,
            ),
          )),
          SizedBox(
            height: 5,
          ),
          Container(
              decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
              height: 90,
              width: 163,
              child: LiveStreamScreenLink(
                url: RTSPurl,
                uid: widget.uid,
                recordStream: false,
              )),
          SizedBox(
            height: 8,
          ),
          isOptimizationIgnored
              ? Center()
              :
              //  not ignoring BatteryOptimization then ask the driver to allow the app to run in the background
              Center(
                  child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    'allowbackground'.tr,
                    style: TextStyle(
                      fontSize: 15,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )),
        ]));
      }),
      btnCancelColor: Colors.grey,
      btnOkColor: GlobalColors.secondaryColorGreen,
      dialogType: DialogType.noHeader,
      animType: AnimType.scale,

      btnOkText: 'yes'.tr,
      btnCancelText: 'no'.tr,
      btnCancelOnPress: () {}, // will stay in the same page
      btnOkOnPress: () async {
        final isIgnored =
            await OptimizeBattery.isIgnoringBatteryOptimizations();

        if (!live!) {
          // //if stream is not avialable show a dialog indicates there is an error  ///*
          AwesomeDialog(
                  context: context,
                  btnCancelColor: Colors.grey,
                  btnOkColor: GlobalColors.secondaryColorGreen,
                  dialogType: DialogType.error,
                  animType: AnimType.scale,
                  dismissOnTouchOutside: false,
                  title: 'E'.tr,
                  desc: 'linkError'.tr,
                  btnOkText: 'Ok'.tr,
                  btnOkOnPress: () {})
              .show();
          streamUpdate!.cancel();
        } else {
          OptimizeBattery.isIgnoringBatteryOptimizations().then((onValue) {
            // if onValue true then it is not optimized
            setState(() {
              if (onValue) {
                // if it is not optimized then the app is runining in background
                //Already not optimized best case
              } else {
                // if in else then the app is not runing in the background
                // optimized
                // it will show a dialog asking the driver to allow the app to run in the background

                OptimizeBattery.stopOptimizingBatteryUsage();
              }
            });
          });

          //if the stream is availabe
          //################## check  dashcam IP is in the right form ##################
          bool validate =
              checkValidation(ipOnly == 1 ? _formKeyLink : _formKeyLink2);
          if (validate) {
            dashcam_id_num = Dashcam_id.text;
            if (ipOnly == 0) {
              dashcam_un = Dashcam_username.text;
              dashcam_ps = hashvalue.toString();
            }
            final docUser = FirebaseFirestore.instance
                .collection('drivers')
                .doc(widget.uid);
            //################## now add dashcam IP after validation ##################
            //update specfic fields
            docUser.update({
              'dashcam_id': dashcam_id_num,
              'rtsp_url': RTSPurl,
            });
            if (ipOnly == 0) {
              docUser.update({
                'dashcam_username': dashcam_un,
                'dashcam_pass': dashcam_ps,
              });
            }

            streamUpdate!.cancel();
            //################## now naviagte the user to the home page (after linking successfully ) ##################
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => RootApp(
                          pageIndex: 0,
                        )));
          } else {
            setState(() {
              errorMessageValid = 'errorLink'.tr;
              streamUpdate!.cancel();
            });
          }
        }
      },
    ).show();
  }

// build method
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
            title: Container(
              child: Text(
                  //  widget.linked = true --> the dashcam already link ( show edit ) ,  widget.linked = false --> the dashcam not linked yet( show link )
                  widget.linked ? 'editDashCam'.tr : 'linkDashCamTitle'.tr,
                  style: TextStyle(color: GlobalColors.mainColorGreen)),
            ),
            backgroundColor: Colors.white,
            //Back button to the home page
            leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_rounded,
                size: 30,
              ),
              color: GlobalColors.mainColorGreen,
              onPressed: () {
                Navigator.pop(context);
              },
            )),
        body: SingleChildScrollView(
          reverse: true,
          child: ValueListenableBuilder(
            valueListenable: streamCheck.statCheckLink,
            builder: (context, value, child) {
              return widget.linked ? edit() : Link();
            },
          ),
        ),
      ),
    );
  }

// return the link dashcam page
  Widget Link() {
    return SingleChildScrollView(
      child: SafeArea(
        child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: ipOnly == 1 ? 80 : 40),
                Container(
                    alignment: Alignment.center,
                    child: Image.asset('assets/images/logo.png',
                        height: 130, width: 130)),
                const SizedBox(height: 40),
                Text(
                  'RTSPques'.tr,
                  style: TextStyle(
                    color: GlobalColors.textColor,
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Container(
                  child: Row(children: [
                    Expanded(
                        flex: 2,
                        child: Row(children: [
                          Expanded(
                            flex: 1,
                            child: Radio(
                              activeColor: GlobalColors.mainColorGreen,
                              value: 1, //IP only
                              groupValue: ipOnly,
                              onChanged: ((value) {
                                setState(() {
                                  ipOnly = value!;
                                  Dashcam_id.clear();
                                });
                              }),
                            ),
                          ),
                          //ip only dashcam
                          Container(
                              padding: EdgeInsets.only(top: 5),
                              child: Text(
                                'IPonly'.tr,
                                style: TextStyle(
                                  color: GlobalColors.textColor,
                                  fontSize: 15,
                                ),
                              ))
                        ])),
                    Expanded(
                        flex: 4,
                        child: Row(children: [
                          Expanded(
                            flex: 1,
                            child: Radio(
                              activeColor: GlobalColors.mainColorGreen,
                              value: 0, //IP, Admin, Pass
                              groupValue: ipOnly,
                              onChanged: ((value) {
                                setState(() {
                                  ipOnly = value!;
                                  Dashcam_id.clear();
                                });
                              }),
                            ),
                          ),
                          Container(
                              padding: EdgeInsets.only(top: 5),
                              child: Text(
                                'UPIPReq'.tr,
                                style: TextStyle(
                                  color: GlobalColors.textColor,
                                  fontSize: 15,
                                ),
                              ))
                        ])),
                  ]),
                ),
                const SizedBox(
                  height: 20,
                ),
                Center(
                  child: Row(
                    children: [
                      ipOnly == 0 ? SectoolTip() : toolTip(),
                      // Text(
                      //   ipOnly == 0 ? "How2".tr : "How".tr,
                      //   style: TextStyle(
                      //       color: Colors.grey, fontSize: 16, height: 3),
                      // ),
                    ],
                  ),
                ),
                ipOnly ==
                        1 // true --> show the form of ip only dashcam , false --> show the form of username,password dashcam
                    ? Form(
                        key: _formKeyLink,
                        child: Column(
                          children: [
                            TextFormGlobal(
                              controller: Dashcam_id,
                              text: 'IP'.tr,
                              obsecure: false,
                              textInputType: TextInputType.text,
                              isLogin: true,
                            ),
                          ],
                        ))
                    : Form(
                        key: _formKeyLink2,
                        child: Column(
                          children: [
                            TextFormGlobal(
                              controller: Dashcam_id,
                              text: 'IP'.tr,
                              obsecure: false,
                              textInputType: TextInputType.text,
                              isLogin: true,
                              linkFontText: 15,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            TextFormGlobal(
                              controller: Dashcam_username,
                              text: 'UserNameDCEntrence'.tr,
                              obsecure: false,
                              textInputType: TextInputType.text,
                              isLogin: true,
                              linkFontText: 15,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Stack(alignment: Alignment.center, children: [
                              showPassClickedLogin
                                  ? TextFormGlobal(
                                      controller:
                                          Dashcam_pass, //the controller which holds the pssword will be used to pass whatever it saved to the controller of form gllobal
                                      text: 'pass'.tr,
                                      obsecure:
                                          false, //obecure is false since the show password icon was clicke and we want the password to be visiable to the user
                                      textInputType: TextInputType.text,
                                      isLogin: true,
                                    )
                                  : TextFormGlobal(
                                      controller: Dashcam_pass,
                                      text: 'PassDCEntrence'.tr,
                                      obsecure:
                                          true, //obecure is true since the show password icon wasn't cciked  and we don't want the password to be visiable to the user
                                      textInputType: TextInputType.text,
                                      isLogin: true,
                                    ),
                              isVisibleLogin //for the eye(visiability icon) same settings as the one in the sign up page
                                  ? Positioned(
                                      top: 2,
                                      child: Container(
                                        //color: Colors.amber,
                                        height: 47,
                                        width: 300,
                                        child: arLnag
                                            ? Padding(
                                                //arLnag true?
                                                padding: EdgeInsets.only(
                                                  right: 240,
                                                ),
                                                child: TextButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      showPassClickedLogin =
                                                          true;
                                                      isVisibleLogin = false;
                                                    });
                                                  },
                                                  child: Icon(
                                                    Icons.visibility_off,
                                                    size: 20,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                  ),
                                                ),
                                              )
                                            : Padding(
                                                //arLnag false?
                                                padding: EdgeInsets.only(
                                                  left: 220,
                                                ),
                                                child: TextButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      showPassClickedLogin =
                                                          true;
                                                      isVisibleLogin = false;
                                                    });
                                                  },
                                                  child: Icon(
                                                    Icons.visibility_off,
                                                    size: 20,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                  ),
                                                ),
                                              ),
                                      ),
                                    )
                                  : Positioned(
                                      top: 2,
                                      child: Container(
                                        height: 47,
                                        width: 300,
                                        child: arLnag
                                            ? Padding(
                                                padding:
                                                    EdgeInsets.only(right: 240),
                                                child: TextButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      showPassClickedLogin =
                                                          false;
                                                      isVisibleLogin = true;
                                                    });
                                                  },
                                                  child: Icon(
                                                    Icons.visibility,
                                                    size: 20,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                  ),
                                                ),
                                              )
                                            : Padding(
                                                padding:
                                                    EdgeInsets.only(left: 220),
                                                child: TextButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      showPassClickedLogin =
                                                          false;
                                                      isVisibleLogin = true;
                                                    });
                                                  },
                                                  child: Icon(
                                                    Icons.visibility,
                                                    size: 20,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                  ),
                                                ),
                                              ),
                                      ),
                                    ),
                            ]),
                          ],
                        )),

                const SizedBox(height: 10),
                // submitbutton
                submitButton("Link".tr),
              ],
            )),
      ),
    );
  }

// show the edit page ()
  Widget edit() {
    return SingleChildScrollView(
      child: SafeArea(
        child: Container(
          //color: Colors.brown,
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 50),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: ipOnly == 1 ? 80 : 40),
              Container(
                  alignment: Alignment.center,
                  child: Image.asset('assets/images/logo.png',
                      height: 130, width: 130)),
              const SizedBox(height: 40),
              Text(
                'RTSPques'.tr,
                style: TextStyle(
                  color: GlobalColors.textColor,
                  fontSize: 17,
                  fontWeight: FontWeight.w500,
                ),
              ),

              // SizedBox(
              //   height: 30,
              // ),
              Container(
                child: Row(children: [
                  Expanded(
                      flex: 2,
                      child: Row(children: [
                        Expanded(
                          flex: 1,
                          child: Radio(
                            activeColor: GlobalColors.mainColorGreen,
                            value: 1, //IP only
                            groupValue: ipOnly,
                            onChanged: ((value) {
                              setState(() {
                                ipOnly = value!;
                                Dashcam_id.clear();
                              });
                            }),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.only(top: 5),
                            child: Text(
                              'IPonly'.tr,
                              style: TextStyle(
                                color: GlobalColors.textColor,
                                fontSize: 15,
                              ),
                            ))
                      ])),
                  Expanded(
                      flex: 4,
                      child: Row(children: [
                        Expanded(
                          flex: 1,
                          child: Radio(
                            activeColor: GlobalColors.mainColorGreen,
                            value: 0, //IP, Admin, Pass
                            groupValue: ipOnly,
                            onChanged: ((value) {
                              setState(() {
                                ipOnly = value!;
                                Dashcam_id.clear();
                              });
                            }),
                          ),
                        ),
                        Container(
                            padding: EdgeInsets.only(top: 5),
                            child: Text(
                              'UPIPReq'.tr,
                              style: TextStyle(
                                color: GlobalColors.textColor,
                                fontSize: 15,
                              ),
                            ))
                      ])),
                ]),
              ),
              const SizedBox(
                height: 20,
              ),
              Center(
                child: Row(
                  children: [
                    ipOnly == 0 ? SectoolTip() : toolTip(),
                  ],
                ),
              ),

              ipOnly == 1
                  ? Form(
                      key: _formKeyLink,
                      child: Column(
                        children: [
                          TextFormGlobal(
                            controller: Dashcam_id,
                            text: 'IP'.tr,
                            obsecure: false,
                            textInputType: TextInputType.text,
                            isLogin: true,
                          ),
                        ],
                      ))
                  : Form(
                      key: _formKeyLink2,
                      child: Column(
                        children: [
                          TextFormGlobal(
                            controller: Dashcam_id,
                            text: 'IP'.tr,
                            obsecure: false,
                            textInputType: TextInputType.text,
                            isLogin: true,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextFormGlobal(
                            controller: Dashcam_username,
                            text: 'UserNameDCEntrence'.tr,
                            obsecure: false,
                            textInputType: TextInputType.text,
                            isLogin: true,
                            linkFontText: 15,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Stack(alignment: Alignment.center, children: [
                            showPassClickedLogin
                                ? TextFormGlobal(
                                    controller:
                                        Dashcam_pass, //the controller which holds the pssword will be used to pass whatever it saved to the controller of form gllobal
                                    text: 'PassDCEntrence'.tr,
                                    obsecure:
                                        false, //obecure is false since the show password icon was clicke and we want the password to be visiable to the user
                                    textInputType: TextInputType.text,
                                    isLogin: true,
                                  )
                                : TextFormGlobal(
                                    controller: Dashcam_pass,
                                    text: 'PassDCEntrence'.tr,
                                    obsecure:
                                        true, //obecure is true since the show password icon wasn't cciked  and we don't want the password to be visiable to the user
                                    textInputType: TextInputType.text,
                                    isLogin: true,
                                  ),
                            isVisibleLogin //for the eye(visiability icon) same settings as the one in the sign up page
                                ? Positioned(
                                    top: 2,
                                    child: Container(
                                      //color: Colors.amber,
                                      height: 47,
                                      width: 300,
                                      child: arLnag
                                          ? Padding(
                                              //arLnag true?
                                              padding: EdgeInsets.only(
                                                right: 240,
                                              ),
                                              child: TextButton(
                                                onPressed: () {
                                                  setState(() {
                                                    showPassClickedLogin = true;
                                                    isVisibleLogin = false;
                                                  });
                                                },
                                                child: Icon(
                                                  Icons.visibility_off,
                                                  size: 20,
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                ),
                                              ),
                                            )
                                          : Padding(
                                              //arLnag false?
                                              padding: EdgeInsets.only(
                                                left: 220,
                                              ),
                                              child: TextButton(
                                                onPressed: () {
                                                  setState(() {
                                                    showPassClickedLogin = true;
                                                    isVisibleLogin = false;
                                                  });
                                                },
                                                child: Icon(
                                                  Icons.visibility_off,
                                                  size: 20,
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                ),
                                              ),
                                            ),
                                    ),
                                  )
                                : Positioned(
                                    top: 2,
                                    child: Container(
                                      height: 47,
                                      width: 300,
                                      child: arLnag
                                          ? Padding(
                                              padding:
                                                  EdgeInsets.only(right: 240),
                                              child: TextButton(
                                                onPressed: () {
                                                  setState(() {
                                                    showPassClickedLogin =
                                                        false;
                                                    isVisibleLogin = true;
                                                  });
                                                },
                                                child: Icon(
                                                  Icons.visibility,
                                                  size: 20,
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                ),
                                              ),
                                            )
                                          : Padding(
                                              padding:
                                                  EdgeInsets.only(left: 220),
                                              child: TextButton(
                                                onPressed: () {
                                                  setState(() {
                                                    showPassClickedLogin =
                                                        false;
                                                    isVisibleLogin = true;
                                                  });
                                                },
                                                child: Icon(
                                                  Icons.visibility,
                                                  size: 20,
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                ),
                                              ),
                                            ),
                                    ),
                                  ),
                          ]),
                        ],
                      )),
              const SizedBox(height: 0),

              const SizedBox(height: 20), //*
              submitButton("editLink".tr),
            ],
          ),
        ),
      ),
    );
  }
} //build
