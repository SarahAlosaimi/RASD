//This class is for the verify phone number
import 'dart:async';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rasd/shared/GlobalColors.dart';
import '../../appRoot.dart';
import '../../auth.dart';
import '../../widget_tree.dart';

class VerifyPhonePage extends StatefulWidget {
  final String uid; // Driver's id
  final String phoneNum; // Driver's phone number

  const VerifyPhonePage({Key? key, required this.uid, required this.phoneNum})
      : super(key: key);
  @override
  _VerifyPhonePage createState() => _VerifyPhonePage();
}

class _VerifyPhonePage extends State<VerifyPhonePage> {
  final auth = FirebaseAuth.instance;
  bool isPhoneVerfied =
      false; // a boolean indicates if a phone number  is verfiied or not
  String? otp; // one time password
  bool otpCompleted = false; // is the otp compeleted
  String? verificationID;
  bool timeout = false;
  bool done = false;
  bool arLnag = "acc".tr == 'My Account'
      ? false
      : true; // to know if the cuurent page in arabic or english

  int seconds = 30;
  Timer? timer;

  void startTimer() {
    timer = Timer.periodic(Duration(seconds: 1), (_) {
      setState(() {
        if (seconds > 0) {
          seconds--;
        } else {
          timer?.cancel();
        }
      });
    });
  }

  void resetTimer() {
    setState(() {
      seconds = 30;
      startTimer();
    });
  }

  @override
  void initState() {
    startTimer();
    super.initState();
    auth.verifyPhoneNumber(
        phoneNumber: widget.phoneNum,
        verificationCompleted: (_) {
          setState(() {
            isPhoneVerfied = true;
          });
        },
        verificationFailed: (e) {},
        codeSent: (String verificationId, int? forceResendingToken) {
          setState(() {
            verificationID = verificationId;
          });
        },
        codeAutoRetrievalTimeout: (e) {
          // print("in time out");
          setState(() {
            timeout = true;
          });
        });
  }

  void _showSucess() {
    AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.success,
        animType: AnimType.scale,
        dismissOnTouchOutside: false,
        headerAnimationLoop: false,
        title: 'S'.tr,
        desc: "VerfiedeMess".tr,
        btnOkText: "Ok".tr,
        btnOkOnPress: () {
          // return to the home page to show the changes
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => RootApp(
                        pageIndex: 0,
                      )));
        }).show();
  }

  // a method that accept an error message and display it iin dialog
  void _errorMessage(String msg) {
    AwesomeDialog(
            context: context,
            btnCancelColor: Colors.grey,
            btnOkColor: GlobalColors.secondaryColorGreen,
            dialogType: DialogType.error,
            animType: AnimType.scale,
            dismissOnTouchOutside: true,
            headerAnimationLoop: false,
            title: 'E'.tr,
            desc: msg,
            btnOkOnPress: () {})
        .show();
  }

//-----------------------------Verfiy button allows the driver to verify his phone number -----------------------------
  Widget verfiyButton() {
    return Row(
      children: [
        Flexible(
          flex: 1,
          child: Container(
            alignment: Alignment.center,
            height: 50,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: otpCompleted
                        ? [
                            GlobalColors.mainColorGreen,
                            GlobalColors.secondaryColorGreen
                          ]
                        : [
                            Color.fromARGB(225, 4, 99, 65).withOpacity(0.4),
                            Color.fromARGB(225, 4, 99, 65).withOpacity(0.4),
                          ]),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color: otpCompleted
                        ? Color.fromARGB(225, 4, 99, 65).withOpacity(0.27)
                        : Color.fromARGB(225, 4, 99, 65).withOpacity(0.1),
                    blurRadius: 10,
                  ),
                ]),
            child: TextButton(
              onPressed: otpCompleted
                  ? () async {
                      PhoneAuthCredential credential;
                      try {
                        credential = PhoneAuthProvider.credential(
                            verificationId: verificationID!, smsCode: otp!);
                      } catch (e) {
                        // Show Error usually wrong _smsVerfication code entered
                        // _errorMessage('OTPInccorent'.tr);
                      }

                      User currentUser = await Auth().currentUser!;
                      try {
                        // This try catch helps if you want to update an existing verified phone number and you want to verify the new one.
                        // We unlink the old phone number so a new one can be linked
                        // This is not relevant if you're just going to verify and link a phone number without updating it later.
                        currentUser = await currentUser.unlink("phone");
                      } catch (e) {
                        currentUser = await Auth().currentUser!;
                      }

                      try {
                        credential = await PhoneAuthProvider.credential(
                            verificationId: verificationID!, smsCode: otp!);
                        await currentUser
                            .linkWithCredential(credential)
                            .then((value) {
                          done = true;
                        });
                      } catch (e) {
                        if (e.toString().contains(
                            'firebase_auth/credential-already-in-use')) {
                          _errorMessage('credential-already-in-use'.tr);
                        } else {
                          _errorMessage('OTPInccorent'.tr);
                        }
                      }
                      if (done) {
                        try {
                          final docUser = FirebaseFirestore.instance
                              .collection('drivers')
                              .doc(widget.uid);
                          //update phone number in the DB
                          docUser.update({
                            'phoneVerfied': true,
                          });
                          //Navigator.pop(context);
                          _showSucess();
                        } catch (e) {
                          // in case of error
                        }
                      } else {
                        // _errorMessage('OTPInccorent'.tr);
                      }
                    }
                  : null,
              style: TextButton.styleFrom(
                primary: Colors.transparent,
              ),
              child: Container(
                padding: EdgeInsets.only(top: 1),
                width: 350,
                child: Text(
                  'VerifyButtom'.tr,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

//---------------------------------Resend OTP button which allows the driver to resend otp in case he/she did not receives ------------------------------
  Widget ResendOTP() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Flexible(
          flex: 1,
          child: GestureDetector(
            onTap: timeout
                ? () {
                    resetTimer();
                    setState(() {
                      timeout = false;
                    });
                    auth.verifyPhoneNumber(
                        phoneNumber: widget.phoneNum,
                        verificationCompleted: (_) {
                          setState(() {
                            isPhoneVerfied = true;
                          });
                        },
                        verificationFailed: (e) {},
                        codeSent:
                            (String verificationId, int? forceResendingToken) {
                          setState(() {
                            verificationID = verificationId;
                          });
                        },
                        codeAutoRetrievalTimeout: (e) {
                          setState(() {
                            timeout = true;
                          });
                        });
                  }
                : null,
            child: Text(
              seconds == 0
                  ? 'ResendOTP'.tr
                  : arLnag
                      ? 'ResendOTP'.tr + 'ResendSec'.tr + "$seconds" + " ث "
                      : 'ResendOTP'.tr + 'ResendSec'.tr + "$seconds" + "s ",
              style: TextStyle(
                color: timeout
                    ? GlobalColors.secondaryColorGreen
                    : Colors.grey[300],
                fontSize: 20,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ------------------------- The build of the verfiy phone number page ----------------------
  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      padding: EdgeInsets.only(top: 5),
      width: 45,
      height: 45,
      textStyle: TextStyle(
        fontSize: 25,
        color: GlobalColors.textColor,
        fontWeight: FontWeight.w600,
      ),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context); // changed
            },
            icon: Icon(Icons.arrow_back_ios_rounded,
                size: 25, color: GlobalColors.mainColorGreen),
          ),
          elevation: 0,
        ),
        body: SingleChildScrollView(
          reverse: true,
          child: Container(
            padding: const EdgeInsets.all(30.0),
            alignment: Alignment.center,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 50),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Container(
                            alignment: Alignment.center,
                            child: Image.asset('assets/images/logo.png',
                                height: 150, width: 150)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 35),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Text(
                          'PhoneVerification'.tr,
                          style: TextStyle(
                            color: GlobalColors.textColor,
                            fontSize: 25,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  arLnag
                      ? Row()
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Flexible(
                              flex: 1,
                              child: Text(
                                "EnterOTP".tr,
                                style: TextStyle(
                                  color: GlobalColors.textColor,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 1,
                              child: Text(
                                widget.phoneNum,
                                style: TextStyle(
                                  color: GlobalColors.textColor,
                                  fontSize: 19,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                  arLnag
                      ? Text(
                          "EnterOTP".tr,
                          style: TextStyle(
                            color: GlobalColors.textColor,
                            fontSize: 18,
                          ),
                        )
                      : Text(""),
                  arLnag
                      ? Text(
                          widget.phoneNum,
                          style: TextStyle(
                            color: GlobalColors.textColor,
                            fontSize: 19,
                            fontWeight: FontWeight.w500,
                          ),
                        )
                      : Text(""),
                  const SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Pinput(
                          length: 6,
                          defaultPinTheme: defaultPinTheme,
                          showCursor: true,
                          onCompleted: (pin) => {
                            setState(() {
                              otpCompleted = true;
                              otp = pin;
                            }),
                          },
                          onChanged: (pin) => {
                            setState(() {
                              otpCompleted = false;
                            }),
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  verfiyButton(),
                  const SizedBox(
                    height: 40,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Text(
                          'noOTP?'.tr,
                          style: TextStyle(
                            color: GlobalColors.textColor,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),

                      //   bulidTime(),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ResendOTP(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
