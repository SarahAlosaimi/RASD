// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rasd/shared/GlobalColors.dart';

class privacy extends StatefulWidget {
  const privacy({Key? key}) : super(key: key);

  @override
  _privacyState createState() => _privacyState();
}

class _privacyState extends State<privacy> {
  bool arLnag = 'RASDPP'.tr == 'RASD Privacy Policy' ? false : true; // to know if the currnet page was in arrabic or english to redifine the sizes
  @override
  // this widget build the privacy policy page
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title:  Text('RASDPP'.tr,
                  style: TextStyle(color: GlobalColors.mainColorGreen)),
            
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_rounded,
                size: 30,
              ),
              color: GlobalColors.mainColorGreen,
              onPressed: () {
                Navigator.pop(context);// to back to the privious page
              },
            )),
        body: SingleChildScrollView(// Creates a box in which a single widget can be scrolled.
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [ // a list of containers to hold all the privacy policy items
              const SizedBox( // an empty space between the elements
                width: double.infinity, // occupy the whole width 
                height: 30,
              ),
              /*------------------------------------------------ Item one Privacy policy ------------------------------------------------*/
              Container( // a container is a widget that combines common painting, positioning, and sizing widgets.
                alignment: arLnag ? Alignment.topRight : Alignment.topLeft, // if the page was in arabic then the alignment must be from the right and vise versa
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it1".tr,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: GlobalColors.mainColorGreen),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 10,
              ),
              Container( 
                // introduction text
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it1text".tr,
                    style:
                        TextStyle(fontSize: 16, color: GlobalColors.textColor),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 25,
              ),
              /*------------------------------------------------ Item two Privacy policy ------------------------------------------------*/
              Container(
                // item two policy text
                alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it2".tr,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: GlobalColors.mainColorGreen),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 10,
              ),
              Container(
                // item three policy text
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it2text".tr,
                    style:
                        TextStyle(fontSize: 16, color: GlobalColors.textColor),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 25,
              ),
              /*------------------------------------------------ Item three Privacy policy ------------------------------------------------*/
              Container(
                alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it3".tr,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: GlobalColors.mainColorGreen),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 10,
              ),
              Container(
                // item three policy text
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it3text".tr,
                    style:
                        TextStyle(fontSize: 16, color: GlobalColors.textColor),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 25,
              ),
              /*------------------------------------------------ Item four Privacy policy ------------------------------------------------*/
              Container(
                alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it4".tr,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: GlobalColors.mainColorGreen),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 10,
              ),
              Container(
                // item four policy text
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it4text".tr,
                    style:
                        TextStyle(fontSize: 16, color: GlobalColors.textColor),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 25,
              ),
              /*------------------------------------------------ Item five Privacy policy ------------------------------------------------*/
              Container(
                alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it5".tr,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: GlobalColors.mainColorGreen),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 10,
              ),
              Container(
                // item five policy text
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it5text".tr,
                    style:
                        TextStyle(fontSize: 16, color: GlobalColors.textColor),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 20,
              ),
                            const SizedBox( // an empty space between the elements
                height: 25,
              ),
              /*------------------------------------------------ Item six Privacy policy ------------------------------------------------*/             
              Container(
                alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it6".tr,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: GlobalColors.mainColorGreen),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 10,
              ),
              Container(
                // item six policy text
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    "it6text".tr,
                    style:
                        TextStyle(fontSize: 16, color: GlobalColors.textColor),
                  ),
                ),
              ),
              const SizedBox( // an empty space between the elements
                height: 20,
              ),
            ],
          ),
        ));
  }
}
