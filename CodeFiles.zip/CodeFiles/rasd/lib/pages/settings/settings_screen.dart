import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ionicons/ionicons.dart';
import 'package:rasd/Splash.dart';
import 'package:rasd/auth.dart';
import 'package:rasd/pages/settings/privacy.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/shared/widgets/settings_tile.dart';
import 'package:rasd/pages/settings/account.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final List locale = [ // a list to hold the two languages
    {'name': 'English', 'locale': const Locale('en', 'US')},
    {'name': 'العربية', 'locale': const Locale('ar', 'AE')},
  ];

  bool arLnag = "Plang".tr == 'Preferred Language' ? false : true;

  updateLanguage(Locale local) { // this method to update the app to the selected language
    Get.back();
    Get.updateLocale(local);
  }
  // this dialog allow the driver to choose between arabic or english language
  buildDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (builder) {
          return AlertDialog(
            title: Text("choosePr".tr),
            content: Container(
              width: 10,
              child: ListView.separated(
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: GestureDetector(
                          onTap: () {
                            updateLanguage(locale[index]['locale']);
                            if (locale[index]['name'] == 'Arabic') {
                              arLnag = true;
                              Navigator.push( // splash to refresh the page and display the app in arabic language
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Splash()));
                            } else { // splash to refresh the page and display the app in english language
                              arLnag = false;
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Splash()));
                            }
                          },
                          child: Text(locale[index]['name'])),
                    );
                  },
                  separatorBuilder: (context, index) {
                    return Divider(
                      color: GlobalColors.mainColorGreen,
                    );
                  },
                  itemCount: locale.length),
            ),
          );
        });
  }


  User? user = Auth().currentUser;
  // for signing out
  Future<void> signOut() async {
    try {
      await Auth().signOut();
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => Splash()));
    } on FirebaseAuthException catch (e) {
   
    }
  }

  // show confirmation dialog before signout
  Future<void> _showMyDialog() async {
    return AwesomeDialog(
      context: context,
      btnCancelColor: Colors.grey,
      btnOkColor: GlobalColors.secondaryColorGreen,
      dialogType: DialogType.noHeader,
      headerAnimationLoop: false,

      title: 'Sure'.tr,
      desc: 'AreUSure'.tr,
      btnOkText: 'yes'.tr,
      btnCancelText: 'C'.tr,

      btnCancelOnPress: () {}, // will stay in the same page
      btnOkOnPress: () {// if the driver confirm then sign out
        signOut(); 
      },
    ).show();
  }

  // boolean for checking the phone verfication
  bool phoneVerfied = false;

  // method to retrive the phoneVerfied value from DB in order to display alert if not verified
  Future<void> getUserVerfied() async {
   
    final User? user = Auth().currentUser;  
    var collection = FirebaseFirestore.instance.collection('drivers');
    var docSnapshot = await collection.doc(user!.uid).get();
    if (docSnapshot.exists) { // if the driver exist
      Map<String, dynamic> data = docSnapshot.data()!;
      phoneVerfied = data['phoneVerfied']; // to get the value in the driver document
    }
  }

  @override
  Widget build(BuildContext context) {
    getUserVerfied();
    return Scaffold(
      body: SingleChildScrollView( // a box in which a single widget can be scrolled.
          child: Row(
        children: [ // list to hold multible structured boxes in the settings page
          Flexible( // to make it responsive
            flex: 1,
            child: Container(
              child: SafeArea(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 35),
                        //----------------------------Setting title-------------------------
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            "sitt".tr,
                            style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                                color: GlobalColors.textColor),
                          ),
                        ),
                        const SizedBox(height: 30),

                        //--------------------------- { My account / Privacy Policy / Contact Us } BOX ------------------
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          width: 380,
                          height: 199,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ]),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              //---------------------------My account button----------------------
                              Flexible(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () { // to go to the account page along with the driver document id
                                    Navigator.of(context)
                                        .push(MaterialPageRoute(builder: (v) {
                                      return account(uid: user!.uid);
                                    }));
                                  },
                                  child: SettingsTile(
                                    color: GlobalColors.mainColorGreen,
                                    icon: Ionicons.person_circle_outline,
                                    title: "acc".tr,
                                    phoneVerfied: phoneVerfied,
                                  ),
                                  style: TextButton.styleFrom(
                                      primary: Colors.transparent),
                                ),
                              ),
                              //---------------------Privacy policy button----------------------------------
                              Flexible(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () { // to view the privacy policy page
                                    Navigator.of(context)
                                        .push(MaterialPageRoute(builder: (v) {
                                      return privacy();
                                    }));
                                  },
                                  child: SettingsTile(
                                    color: GlobalColors.mainColorGreen,
                                    icon: Ionicons.document_lock_outline,
                                    title: "PP".tr,
                                    phoneVerfied: phoneVerfied,
                                  ),
                                  style: TextButton.styleFrom(
                                      primary: Colors.transparent),
                                ),
                              ),
                              //---------------------------Contact Us button-------------------------
                              Flexible(
                                flex: 1,
                                child: TextButton(
                                  onPressed: () async { // if the driver clicc on contact us the app will navigate to RASD twitter account
                                    const url =
                                        'https://twitter.com/rasdgp?s=21&t=wSUpQhdTJfIKRsMi9yXcAQ';
                                    if (await launch(url)) {
                                      await canLaunch(url);
                                    } else {
                                      throw 'Could not launch $url';
                                    }
                                  },
                                  child: SettingsTile(
                                    color: GlobalColors.mainColorGreen,
                                    icon: Ionicons.logo_twitter,
                                    title: "contact".tr,
                                    phoneVerfied: phoneVerfied,
                                  ),
                                  style: TextButton.styleFrom(
                                      primary: Colors.transparent),
                                ),
                              ),
                            ],
                          ),
                        ),
                       const  SizedBox(
                          height: 30,
                        ),
                        //---------------------------Choose perfferd language part-----------------------------
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          width: 380,
                          height: 60,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ]),
                          child: TextButton(
                              onPressed: () {
                                buildDialog(context);
                              },
                              style: TextButton.styleFrom(
                                  primary: Colors.transparent),
                              child: Row(
                                children: [
                                  Flexible(
                                    flex: 1,
                                    child: Container(
                                      child: Icon(
                                        Icons.translate_outlined,
                                        size: 25,
                                        color: GlobalColors.mainColorGreen,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Container(
                                    child: Text(
                                      "Plang".tr,
                                      style: TextStyle(
                                          color: GlobalColors.mainColorGreen,
                                          fontSize: 17),
                                    ),
                                  ),
                                  arLnag
                                      ? SizedBox(
                                          width: 100,
                                        )
                                      : SizedBox(
                                          width: 60,
                                        ),
                                  Container(
                                    child: Text(
                                      "lang".tr,
                                      style: TextStyle(
                                          color: GlobalColors.mainColorGreen,
                                          fontSize: 17),
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        //---------------------------Version part----------------------------------------
                        const Align(
                          alignment: Alignment.center,
                          child: Text(
                            'v 2.0.0',
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        //--------------------------Sign Out part ---------------------------------------
                        Row(
                          children: [
                            Flexible(
                              flex: 1,
                              child: Container(
                                alignment: Alignment.center,
                                height: 47,
                                decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                        colors: [
                                          GlobalColors.mainColorRed,
                                          GlobalColors.secondaryColorRed
                                        ]),
                                    borderRadius: BorderRadius.circular(6),
                                    boxShadow: [
                                      BoxShadow(
                                        color: GlobalColors.mainColorRed
                                            .withOpacity(0.27),
                                        blurRadius: 10,
                                      ),
                                    ]),
                                child: TextButton(
                                  onPressed: () { // to display the confirmation dialog
                                    _showMyDialog();
                                  },
                                  style: TextButton.styleFrom(
                                    primary: Colors.transparent,
                                  ),
                                  child: Container(
                                    alignment: Alignment.center,
                                    child: Text(
                                      'signout'.tr,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 19,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                      ]),
                ),
              ),
            ),
          ),
        ],
      )),
    );
  }
}
