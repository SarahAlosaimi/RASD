import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:rasd/Splash.dart';
import 'package:rasd/appRoot.dart';
import 'package:rasd/pages/settings/VerifyPhonePage.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/objects/driver.dart';

class account extends StatefulWidget {
  final String uid;

  account({Key? key, required this.uid}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _accountState createState() => _accountState();
}

class _accountState extends State<account> {
  double screenHeight = 0;
  double screenWidth = 0;
  final GlobalKey<FormState> _formKeySave = GlobalKey<
      FormState>(); // key to save first name and last name form input to validate it
  final GlobalKey<FormState> _formKeySave2 =
      GlobalKey<FormState>(); // key to save number form input to validate it
  final GlobalKey<FormState> _resetEmailFormKey = GlobalKey<
      FormState>(); // key to save reset email form input to validate it
  String? errorMessageData = '';
  String oldEmailFromDB = '';
  var done = false;
  bool isFormEmpty =
      true; // boolean to define if the form is null(no updates have been initiated)
  bool isFormSame =
      true; // boolean to define if the form has not changed(no updates have been initiated)
  bool arLnag = "acc".tr == 'My Account'
      ? false
      : true; // to know if the cuurent page in arabic or english
  bool isPhoneChanged = false;
  //to hold the entered information i the account pages
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController PhoneNumberController = TextEditingController();
  TextEditingController userNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  TextEditingController oldEmailController = TextEditingController();
  TextEditingController passController = TextEditingController();
  final auth = FirebaseAuth.instance; // to connect to the firebase
  bool isPhoneVerfied =
      false; // boolean to know if the phone has been veified or not to alert the driver later
  String? phone_Num; // to hold the phone number value
  String oldPhoneNum = '';
  String oldFname = '';
  String oldLname = '';
  String oldEmail = '';

  // a method to validate the email in the following format (example@example.com)
  bool validateEmail(value) {
    bool emailValid = RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$")
        .hasMatch(value); // regex to validate the email (contain @, and .)
    if (emailValid == true) {
      return true;
    } else {
      return false;
    }
  }

  // a method that accept an error message and display it iin dialog
  void _errorMessage(String msg) {
    AwesomeDialog(
            context: context,
            btnCancelColor: Colors.grey,
            btnOkColor: GlobalColors.secondaryColorGreen,
            dialogType: DialogType.error,
            animType: AnimType.scale,
            dismissOnTouchOutside: true,
            headerAnimationLoop: false,
            title: 'E'.tr,
            desc: msg,
            btnOkOnPress: () {})
        .show();
  }

  // clear the input fields
  void _clearControllers() {
    oldEmailController.clear();
    passController.clear();
  }

  // clear the input fields
  void _clearControllers2() {
    firstNameController.clear();
    lastNameController.clear();
    emailController.clear();
    PhoneNumberController.clear();
  }

  // to get the phone number of the user in order to set it as hint text
  Future<Driver?> readUser(uid) async {
    final docUser = FirebaseFirestore.instance.collection('drivers').doc(uid);
    final snapshot = await docUser.get();
    if (snapshot.exists) {
      setState(() {
        oldPhoneNum = Driver.fromJsonD(snapshot.data()!).phone_number;
        oldEmailFromDB = Driver.fromJsonD(snapshot.data()!).email;
      });

      return Driver.fromJsonD(snapshot.data()!);
    }
  }

  //loading page
  Widget _loading() {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      width: double.infinity,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Image.asset(
              'assets/images/loadingLogoBlack.png',
              height: 105,
              width: 105,
            ),
            Container(
              padding: const EdgeInsets.only(left: 3),
              child: const SizedBox(
                height: 43,
                width: 43,
                child: CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.only(top: 140, right: 6),
              child: Image.asset(
                'assets/images/rasdTextBlack.png', //make it pop up
                height: 105,
                width: 105,
              ),
            )
          ],
        ),
        const SizedBox(
          height: 10,
        ),
      ]),
    );
  }

  // amethod to verify the email after update in my account age accept the new email and the old one along with the passowrd and the document of the driver
  Future resetEmail(
      String newEmail, String oldEmail, String pass, docUser) async {
    var message;
    final _firebaseAuth = FirebaseAuth.instance;
    bool notupdated = true;
    try {
      // if (oldEmailFromDB == oldEmail) {
      notupdated = false;
      // try and catch to hold any error occured
      UserCredential result = await _firebaseAuth.signInWithEmailAndPassword(
          email: oldEmail, password: pass);
      final User? user = result.user!;
      user!.updateEmail(newEmail).then((value) async {
        // to update the email in the driver document in firebase
        docUser.update({
          'email': newEmail,
        });
        _showSucess(true);
      }).catchError((onError) {
        // if the error indicate that the email is already used
        if (onError.toString().contains(
            'The email address is already in use by another account.')) {
          setState(() {
            errorMessageData = 'AccountExist'.tr; // set the error message
          });
          _errorMessage(errorMessageData!); // show the error message
        }
      });
    } on FirebaseAuthException catch (e) {
      setState(() {
        //  match the errors for the inputs
        String passIsNotCorrect =
            'The password is invalid or the user does not have a password.';
        String emailIsNotCorrect =
            'There is no user record corresponding to this identifier. The user may have been deleted.';
        String networkError =
            'A network error (such as timeout, interrupted connection or unreachable host) has occurred.';
        if (e.message == passIsNotCorrect) {
          // if the error catched match the passowrd error
          errorMessageData = 'EmailPassError'.tr; // set our customized error
        } else if (e.message == emailIsNotCorrect) {
          // if the error catched match the email error
          errorMessageData = 'EmailPassError'.tr; // set our customized error
        } else if (e.message == networkError) {
          // if the error catched match the network error
          errorMessageData = 'networkError'.tr; // set our customized error
        } else {
          errorMessageData = e.message; // set the error
        }
        _errorMessage(errorMessageData!); // display the error
      });
    }
  }

  // this method to sign out after changing the email (security)
  Future<void> signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => Splash()));
    } on FirebaseAuthException catch (e) {}
  }

  // sucess dialog of any update made and if it was an email then driver need to signout from the account
  void _showSucess(bool isEmail) {
    AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.success,
        animType: AnimType.scale,
        dismissOnTouchOutside: false,
        headerAnimationLoop: false,
        title: 'S'.tr,
        desc: "updateMess".tr,
        btnOkText: "Ok".tr,
        btnOkOnPress: () {
          if (isEmail) {
            // to check if the email was updated
            signOut();
          } else {
            // return to the home page to show the changes
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => RootApp(
                          pageIndex: 0,
                        )));
          }
        }).show();
  }

  // dialog for updating the email
  Future<void> _emailUpdateDialog(String newEmail, docUser) {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'changeE'.tr,
            style: TextStyle(color: GlobalColors.mainColorGreen),
          ),
          content: SingleChildScrollView(
            child: ListBody(children: <Widget>[
              Form(
                  key: _resetEmailFormKey,
                  child: Column(
                    children: [
                      textField("oldE".tr, 'em'.tr, oldEmailController),
                      const SizedBox(
                        height: 5,
                      ),
                      textField("pass".tr, 'pass'.tr, passController),
                    ],
                  ))
            ]),
          ),
          actions: <Widget>[
            TextButton(
              child: Text(
                'update'.tr,
                style: TextStyle(color: GlobalColors.mainColorGreen),
              ),
              onPressed: () {
                // _clearControllers2();

                //change Email
                if (_resetEmailFormKey.currentState!.validate()) {
                  // oldEmailFromDB = oldEmailFromDB.toLowerCase();
                  String oldEmailtmp = oldEmailController.text.toLowerCase();

                  if (oldEmailtmp == oldEmailFromDB) {
                    resetEmail(newEmail, oldEmailController.text,
                        passController.text, docUser);
                    _clearControllers();
                    Navigator.of(context).pop();
                  } else {
                    _clearControllers();
                    Navigator.of(context).pop();
                    setState(() {
                      errorMessageData =
                          'EmailPassError'.tr; // set the error message
                      _errorMessage(
                          errorMessageData!); // show the error message
                    });
                  }
                }
              },
            ),
            TextButton(
              //go back
              child: Text(
                'C'.tr,
                style: TextStyle(color: GlobalColors.mainColorGreen),
              ),
              onPressed: () {
                // clear the input fields
                // _clearControllers2();
                _clearControllers();
                Navigator.of(context).pop(); // go back to the setting page
              },
            )
          ],
        );
      },
    );
  }

// confirm dialog to confirm changes
  Future<void> _showMyDialog() async {
    return AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.noHeader,
        dismissOnTouchOutside: true,
        headerAnimationLoop: false,
        title: 'Sure'.tr,
        desc: 'AreUSureToSave'.tr,
        btnOkText: "yes".tr,
        btnCancelText: 'C'.tr,
        btnCancelOnPress: () {
          // _clearControllers2();
        }, // will stay in the same page
        btnOkOnPress: () async {
          done = true;

          if (done) {
            // to update them in the firebase
            String firstname = firstNameController
                .text; // hold the firstname value in the form
            String lastName =
                lastNameController.text; // hold the last value in the form
            String email =
                emailController.text; // hold the email value in the form

            final docUser =
                FirebaseFirestore.instance // access the driver document
                    .collection('drivers')
                    .doc(widget.uid);

            if (oldFname != firstname && firstname.isNotEmpty) {
              // if the firstname has been changed then update it in the database
              docUser.update({
                'Fname': firstname,
              });
            }

            if (oldLname != lastName && lastName.isNotEmpty) {
              // if the last has been changed then update it in the database
              docUser.update({
                'Lname': lastName,
              });
            }

            if (oldEmail != emailController.text && email.isNotEmpty) {
              // if the emal has been changed then go to the update method in order to verify it
              _emailUpdateDialog(email, docUser);
            }

            // update phone number
            if (phone_Num != oldPhoneNum &&
                phone_Num != null &&
                phone_Num != '') {
              // if it is not the same as the previus email and not empty and null then update it
              docUser.update({
                'phone_number': phone_Num,
                'phoneVerfied':
                    false, // this mean the phone need to be verified
              });
            }

            if (((firstname != oldFname && firstname.isNotEmpty) ||
                    (lastName != oldLname && lastName.isNotEmpty) ||
                    (phone_Num != oldPhoneNum &&
                        phone_Num != '' &&
                        phone_Num != null)) &&
                (oldEmail == emailController.text ||
                    emailController.text.isEmpty)) {
              _showSucess(false);
            }
          }
        }).show();
  }

  @override
  Widget build(BuildContext context) {
    firstNameController.selection = TextSelection.fromPosition(
        TextPosition(offset: firstNameController.text.length));

    lastNameController.selection = TextSelection.fromPosition(
        TextPosition(offset: lastNameController.text.length));

    emailController.selection = TextSelection.fromPosition(
        TextPosition(offset: emailController.text.length));

    PhoneNumberController.selection = TextSelection.fromPosition(
        TextPosition(offset: PhoneNumberController.text.length));

    screenHeight = MediaQuery.of(context).size.height;
    screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
          title: Container(
            child: Text('acc'.tr,
                style: TextStyle(color: GlobalColors.mainColorGreen)),
          ),
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded, size: 30),
            color: GlobalColors.mainColorGreen,
            onPressed: () {
              Navigator.pop(context); // to go to the setting page
            },
          )),
      body: FutureBuilder<Driver?>(
          future: readUser(widget.uid),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final user = snapshot.data;

              return user == null
                  ? Center(child: Text('on user'))
                  : buildUser(user);
            } else {
              return _loading();
            }
          }),
    );
  }

  @override
  void initState() {
    retriveUserFname();
    retriveUserLname();
    retriveUseremail();
    retriveUserPhoneNumber();
    // Start listening to changes.
    firstNameController.addListener(_getLatestValue);
    lastNameController.addListener(_getLatestValue);
    emailController.addListener(_getLatestValue);

    firstNameController.text = oldFname;
    lastNameController.text = oldLname;
    emailController.text = oldEmail;

    PhoneNumberController.text = oldPhoneNum;
    super.initState();
  }

  // to get the first name of the user in order to set it as hint text
  Future<void> retriveUserFname() async {
    Driver d;
    final docUser = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(widget.uid)
        .get()
        .then((docUser) {
      d = Driver.fromJsonD(docUser.data()!);
      oldFname = d.Fname;

      return oldFname;
    });

    firstNameController.text = oldFname;
  }

  // to get the phone number of the user in order to set it as hint text
  Future<void> retriveUserLname() async {
    Driver d;
    final docUser = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(widget.uid)
        .get()
        .then((docUser) {
      d = Driver.fromJsonD(docUser.data()!);
      oldLname = d.Lname;

      return oldLname;
    });

    lastNameController.text = oldLname;
  }

  // to get the phone number of the user in order to set it as hint text
  Future<void> retriveUseremail() async {
    Driver d;
    final docUser = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(widget.uid)
        .get()
        .then((docUser) {
      d = Driver.fromJsonD(docUser.data()!);

      oldEmail = d.email;

      return oldEmail;
    });

    emailController.text = oldEmail;
  }

  // // to get the phone number of the user in order to set it as hint text
  Future<void> retriveUserPhoneNumber() async {
    Driver d;
    final docUser = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(widget.uid)
        .get()
        .then((docUser) {
      d = Driver.fromJsonD(docUser.data()!);

      if (!d.phone_number.isEmpty) {
        oldPhoneNum = d.phone_number.substring(4);
      }

      return oldPhoneNum;
    });

    PhoneNumberController.text = oldPhoneNum;
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the widget tree.
    // This also removes the _printLatestValue listener.
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    PhoneNumberController.dispose();
    super.dispose();
  }

  // if all field entered are empty then no need to validate
  void _getLatestValue() {
    if (firstNameController.text == '' ||
        lastNameController.text == '' ||
        emailController.text == '' ||
        PhoneNumberController.text == '') {
      isFormEmpty = true;
    } else {
      isFormEmpty = false;
    }
    if (oldPhoneNum.isNotEmpty) {
      if (firstNameController.text == oldFname &&
          lastNameController.text == oldLname &&
          emailController.text == oldEmail &&
          PhoneNumberController.text == oldPhoneNum.substring(4)) {
        isFormSame = true;
      } else {
        isFormSame = false;
      }
    }
  }

  Widget buildUser(Driver driver) => getBody(driver);

  Widget getBody(Driver driver) {
    _getLatestValue();
    screenHeight = MediaQuery.of(context)
        .size
        .height; // to let the display screen responsive
    screenWidth = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      // Creates a box in which a single widget can be scrolled.
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 5),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: const Text(
              "",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 0),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 39),
            width: 380,
            height: 550,

            ///*********** edit ****************/
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                  ),
                ]),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20,
                ),
                Form(
                    // a form that hold the first name, last name, email input and phone form
                    key: _formKeySave,
                    child: Column(children: [
                      // list to display list of text fields
                      textField("fname".tr, driver.Fname, firstNameController),
                      const SizedBox(
                        height: 20,
                      ),
                      textField("lname".tr, driver.Lname, lastNameController),
                      const SizedBox(
                        height: 20,
                      ),
                      textField("em".tr, driver.email, emailController),
                      const SizedBox(
                        height: 20, // edit
                      ),
                    ])),
                //***********Phone number ****************/
                Form(
                    // phone number form
                    key: _formKeySave2,
                    child: Column(
                      children: [
                        Align(
                          alignment: arLnag
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: 4,
                            ),
                            child: Text(
                              'PhoneNum'.tr,
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Stack(
                          children: [
                            Container(
                              child: Stack(
                                children: [
                                  Stack(
                                    children: [
                                      Container(
                                          margin: EdgeInsets.only(
                                              right: arLnag ? 100 : 70),
                                          height: 50,
                                          width: ((MediaQuery.of(context)
                                                      .size
                                                      .width) /
                                                  4) +
                                              ((MediaQuery.of(context)
                                                      .size
                                                      .width) /
                                                  3),
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.1),
                                                  blurRadius: 10,
                                                ),
                                              ])),
                                      Positioned(
                                        left: arLnag ? 100 : 99,
                                        top: 8,
                                        bottom: 8,
                                        child: Container(
                                          height: 40,
                                          width: 1,
                                          color: Colors.black.withOpacity(0.13),
                                        ),
                                      )
                                    ],
                                  ),
                                  Container(
                                    //container of the number field
                                    margin:
                                        EdgeInsets.only(right: arLnag ? 30 : 0),
                                    width: 300,
                                    padding: EdgeInsets.only(left: 10, top: 0),
                                    child: Directionality(
                                      textDirection: TextDirection.ltr,
                                      child: InternationalPhoneNumberInput(
                                        // to display the flag
                                        spaceBetweenSelectorAndTextField: 12,
                                        selectorButtonOnErrorPadding: 40,
                                        countries: ['SA'],
                                        locale: arLnag ? 'ar' : 'en',
                                        onInputChanged: (PhoneNumber number) {
                                          setState(() {
                                            isPhoneChanged = true;
                                          });
                                        },
                                        onInputValidated: (bool value) {},
                                        ignoreBlank: false,
                                        autoValidateMode: AutovalidateMode
                                            .onUserInteraction, // daynamic validation
                                        selectorTextStyle: TextStyle(
                                            color: GlobalColors.textColor),
                                        textFieldController:
                                            PhoneNumberController,
                                        formatInput: false,
                                        maxLength: 9,
                                        keyboardType: const TextInputType
                                                .numberWithOptions(
                                            signed: true, decimal: true),
                                        cursorColor:
                                            GlobalColors.mainColorGreen,
                                        inputDecoration: InputDecoration(
                                          errorStyle: TextStyle(
                                              color: GlobalColors.mainColorRed,
                                              fontSize: 15.0),
                                          contentPadding: EdgeInsets.only(
                                            bottom: 13,
                                            left: 0,
                                          ),
                                          border: InputBorder.none,
                                        ),
                                        onSaved: (PhoneNumber number) {
                                          setState(() {
                                            phone_Num = number.phoneNumber;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            arLnag
                                ? Padding(
                                    //padding of the verfiy button
                                    padding: EdgeInsets.only(
                                      left:
                                          ((MediaQuery.of(context).size.width) /
                                              1.6),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                          width: ((MediaQuery.of(context)
                                                  .size
                                                  .width) /
                                              5),
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.1),
                                                  blurRadius: 10,
                                                ),
                                              ]),
                                          child: Column(children: [
                                            driver.phoneVerfied
                                                ? TextButton(
                                                    onPressed: null,
                                                    child: Row(
                                                      children: [
                                                        Icon(
                                                          Icons
                                                              .verified_rounded,
                                                          color: GlobalColors
                                                              .secondaryColorGreen,
                                                          size: 13,
                                                        ),
                                                        Container(
                                                            padding:
                                                                EdgeInsets.only(
                                                                    top: 5,
                                                                    left: 3,
                                                                    right: 4),
                                                            child: Text(
                                                              'Ver'.tr,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                fontSize: 15,
                                                                color: GlobalColors
                                                                    .secondaryColorGreen,
                                                              ),
                                                            ))
                                                      ],
                                                    ))
                                                : TextButton(
                                                    onPressed: () {
                                                      Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                              builder: (context) =>
                                                                  VerifyPhonePage(
                                                                      phoneNum:
                                                                          driver
                                                                              .phone_number,
                                                                      uid: widget
                                                                          .uid)));
                                                    },
                                                    child: Row(
                                                      children: [
                                                        Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                                    left: 4,
                                                                    right: 0)),
                                                        Icon(
                                                          Icons.warning_rounded,
                                                          color: GlobalColors
                                                              .secondaryColorRed,
                                                          size: 15,
                                                        ),
                                                        Container(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  top: 5,
                                                                  left: 3),
                                                          child: Text(
                                                            'NotVer'.tr,
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                              fontSize: 13,
                                                              color: GlobalColors
                                                                  .secondaryColorRed,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                          ]),
                                        ),
                                      ],
                                    ),
                                  )
                                :

                                // Eng verifiy button
                                Padding(
                                    //padding of the verfiy button
                                    padding: EdgeInsets.only(
                                      left:
                                          ((MediaQuery.of(context).size.width) /
                                              1.6),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                            height: 50,
                                            width: ((MediaQuery.of(context)
                                                    .size
                                                    .width) /
                                                5),
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black
                                                        .withOpacity(0.1),
                                                    blurRadius: 10,
                                                  ),
                                                ]),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                driver.phoneVerfied
                                                    ? TextButton(
                                                        onPressed: null,
                                                        child: Row(
                                                          children: [
                                                            Flexible(
                                                              flex: 1,
                                                              child: Icon(
                                                                Icons
                                                                    .verified_rounded,
                                                                color: GlobalColors
                                                                    .secondaryColorGreen,
                                                                size: 10,
                                                              ),
                                                            ),
                                                            Container(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        top: 5,
                                                                        left: 3,
                                                                        right:
                                                                            3),
                                                                child: Text(
                                                                  'Ver'.tr,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style:
                                                                      TextStyle(
                                                                    fontSize:
                                                                        12,
                                                                    color: GlobalColors
                                                                        .secondaryColorGreen,
                                                                  ),
                                                                ))
                                                          ],
                                                        ))
                                                    : TextButton(
                                                        onPressed: () {
                                                          Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                  builder: (context) => VerifyPhonePage(
                                                                      phoneNum:
                                                                          driver
                                                                              .phone_number,
                                                                      uid: widget
                                                                          .uid)));
                                                        },
                                                        child: Row(
                                                          children: [
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 4,
                                                                        right:
                                                                            0)),
                                                            Flexible(
                                                              flex: 1,
                                                              child: Icon(
                                                                Icons
                                                                    .warning_rounded,
                                                                color: GlobalColors
                                                                    .secondaryColorRed,
                                                                size: 11,
                                                              ),
                                                            ),
                                                            Container(
                                                              padding:
                                                                  EdgeInsets
                                                                      .only(
                                                                top: 5,
                                                                left: 3,
                                                                right: 5,
                                                              ),
                                                              child: Text(
                                                                'NotVer'.tr,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style:
                                                                    TextStyle(
                                                                  fontSize: 12,
                                                                  color: GlobalColors
                                                                      .secondaryColorRed,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                              ],
                                            )),
                                      ],
                                    )),
                          ],
                        ),
                      ],
                    )),
              ],
            ),
          ),
          const SizedBox(height: 23),
          Container(
            alignment: Alignment.center,
            height: 47,
            decoration: BoxDecoration(
                color: !(isFormSame == false && isFormEmpty == false)
                    ? const Color.fromARGB(255, 4, 99, 65).withOpacity(0.4)
                    : const Color.fromARGB(255, 4, 99, 65),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color: !(isFormSame == false && isFormEmpty == false)
                        ? const Color.fromARGB(255, 4, 99, 65).withOpacity(0.1)
                        : const Color.fromARGB(255, 4, 99, 65)
                            .withOpacity(0.27),
                    blurRadius: 10,
                  ),
                ]),
            child: TextButton(
              onPressed: !(isFormSame == false && isFormEmpty == false)
                  ? null
                  : () async {
                      // if the phone number have been changed
                      if (isPhoneChanged) {
                        if (_formKeySave.currentState!.validate() &&
                            _formKeySave2.currentState!.validate()) {
                          //phone number changed but it is still the same
                          if (PhoneNumberController.text ==
                              oldPhoneNum.substring(4)) {
                            // if the driver modifies the first form only (either first name,last name, or email)
                            _formKeySave.currentState
                                ?.save(); // save the first form only
                            //phone number changed but it is not the same
                          } else {
                            // if the driver modifies the first and the second form  (first name,last name, email, and passowrd)
                            _formKeySave.currentState
                                ?.save(); // save the first form
                            _formKeySave2.currentState
                                ?.save(); // save the second form
                          }
                          _showMyDialog();
                          setState(() {
                            errorMessageData = '';
                          });
                        }
                      } else {
                        if (_formKeySave.currentState!.validate()) {
                          //phone number changed but it is still the same
                          if (PhoneNumberController.text ==
                              oldPhoneNum.substring(4)) {
                            // if the driver modifies the first form only (either first name,last name, or email)
                            _formKeySave.currentState
                                ?.save(); // save the first form only
                            //phone number changed but it is not the same
                          } else {
                            // if the driver modifies the first and the second form  (first name,last name, email, and passowrd)
                            _formKeySave.currentState
                                ?.save(); // save the first form
                            _formKeySave2.currentState
                                ?.save(); // save the second form
                          }
                          _showMyDialog();
                          setState(() {
                            errorMessageData = '';
                          });
                        }
                      }
                    }, // this button must be clicked if changed made
              style: TextButton.styleFrom(
                primary: Colors.transparent,
              ),
              child: Container(
                alignment: Alignment.center,
                child: Text(
                  'save'.tr,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget textField(
      String title, String hint, TextEditingController controller) {
    return Column(
      children: [
        Align(
          alignment: arLnag ? Alignment.centerRight : Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.only(
              left: 4,
            ),
            child: Text(
              title,
              style: TextStyle(
                fontSize: 15,
                color: Colors.black87,
              ),
            ),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Stack(
          children: [
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(6),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                    )
                  ]),
            ),
            Container(
              padding: const EdgeInsets.only(
                top: 3,
                left: 15,
              ),
              child: TextFormField(
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (val) {
                  // a method to validate the error on user interaction (dynamic)
                  if (title == 'fname'.tr) {
                    // if the user cursor was on the first name input field
                    if (val!.isEmpty) {
                      return 'enterFN'.tr;
                    } else {
                      // if the first name contain numbers or symbols
                      if (!RegExp(r"^[\u0621-\u064A ]+$").hasMatch(val) &&
                          (!RegExp(r"^[a-zA-Z ]+$").hasMatch(val))) {
                        if (arLnag == true) {
                          return 'FLValidation1'.tr + "";
                        } else {
                          return 'FLValidation1'.tr;
                        }
                      }
                    }
                  } else if (title == 'em'.tr) {
                    // if the user cursor was on the email input field
                    if (val!.isEmpty) {
                      return 'enterE'.tr;
                    } else if (arLnag == true) {
                      if (!validateEmail(val)) {
                        // validate the email through 'validateEmail' method
                        return 'invalidE2'.tr;
                      }
                    } else if (!validateEmail(val)) {
                      return 'invalidE'.tr;
                    }
                  } else if (title == 'lname'.tr) {
                    // if the user cursor was on the email input field
                    if (val!.isEmpty) {
                      return 'enterLN'.tr;
                    } else {
                      // if the last name contain a number or symbols
                      if (!RegExp(r"^[\u0621-\u064A ]+$").hasMatch(val) &&
                          (!RegExp(r"^[a-zA-Z ]+$").hasMatch(val))) {
                        if (arLnag == true) {
                          return 'FLValidation1'.tr;
                        } else {
                          return 'FLValidation1'.tr;
                        }
                      }
                    }
                  } else if (title == 'oldE'.tr) {
                    // if the pop up validation email input field was empty
                    if (val!.isEmpty) {
                      return 'enterE'.tr;
                    } else if (arLnag == true) {
                      if (!validateEmail(val)) {
                        return 'invalidE2'.tr;
                      }
                    } else if (!validateEmail(val)) {
                      return 'invalidE3'.tr;
                    }
                  } else if (title == 'pass'.tr) {
                    // if the pop up validation email passowrd input field was empty
                    if (val!.isEmpty) {
                      return 'enterPass'.tr;
                    }
                  }
                },
                controller: controller,
                cursorColor: Colors.black54,
                obscureText:
                    (title == 'pass'.tr) ? true : false, // represent dots
                decoration: InputDecoration(
                  errorStyle: TextStyle(
                      color: GlobalColors.mainColorRed, fontSize: 15.0),
                  hintText: hint,
                  hintStyle: const TextStyle(
                    color: Color.fromARGB(35, 0, 0, 0),
                    height: 0,
                  ),
                  contentPadding:
                      EdgeInsets.only(bottom: 4, right: arLnag ? 10 : 0),
                  border: InputBorder.none,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
