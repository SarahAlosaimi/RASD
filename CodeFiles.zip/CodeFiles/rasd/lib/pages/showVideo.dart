import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:rasd/appRoot.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/objects/video.dart';
import 'package:video_player/video_player.dart';
import 'dart:math' as math; // import this

final _AdditionalInfo =
    TextEditingController(); //controller for the input that will be written in the additional information field

class showVideo extends StatefulWidget {
  const showVideo(
      {super.key, required this.reportDocid, required this.userDocid});
  final String reportDocid; //the retrived report id from the database
  final String userDocid; //the retrived user id from the database
  @override
  State<showVideo> createState() => _showVideoState();
}

class _showVideoState extends State<showVideo> {
  //########################################################Variables Defention########################################
  //A collection of key/value pairs, from which you retrieve a value using its associated key.
  //we have to Maps for the provided violation types with the check boxes
  Map<String, bool> values1 = {
    'viloation1'.tr: false,
    // 'viloation4'.tr: false,
    'viloation2'.tr: false,

    // 'IDK'.tr: false,
  };
  Map<String, bool> values2 = {
    'viloation3'.tr: false,
    // 'viloation2'.tr: false,
    'Other'.tr: false,
  };

  //A value of the radio buttons, 1 means selected 0 means not selected
  var _value = 1; //0 no, 1 yes

  //a string that will hold all the checked violations from the check boxes specilized for Map1(values1) (first 3 check boxes)
  var selectedV1 = "";

  //a string that will hold all the checked violations from the check boxes specilized for Map2(values2) (the left 2 check boxes)
  var selectedV2 = "";

  //a string that will hold the slected violation types from both Selcted values1 and 2
  var selectedAll = "";

  VideoPlayerController?
      _controller; //controller for the video that will be showing
  String video_url =
      ""; //a string that will hold the video url from the databse

//Play back rates for the video
  static const List<double> _examplePlaybackRates = <double>[
    0.25,
    0.5,
    1.0,
    1.5,
    2.0,
    4.0,
  ];

  //for Disposing the video after leaving the page and not keeping it runining
  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  //########################################################Firbase Retrival########################################
  @override
  void initState() {
    super.initState();

    //will get the video url from the database for each specifiec user
    FirebaseFirestore.instance
        .collection("drivers")
        .doc(widget.userDocid)
        .collection("reports")
        .doc(widget.reportDocid)
        .collection("video")
        .get()
        .then((QuerySnapshot querySnapshot) => {
              querySnapshot.docs.forEach((doc) {
                video_url = doc["video_url"];
                final controller = VideoPlayerController.network(
                    video_url); //Controls a platform video player, and provides updates when the state is changing.

                _controller = controller;
                setState(() {});
                controller.initialize().then((_) {
                  controller.play();
                  setState(() {});
                });
              })
            });
  }

  //########################################################Methods for the slected violation types########################################
  //a method to collect all violations types in (values1) and save it in (selectedV1) Comma-delimited
  void typesV1(String vtitle) {
    selectedV1 += vtitle + ",";
  }

  //a method to collect all violations types in (values2) and save it in (selectedV2) Comma-delimited
  void typesV2(String vtitle) {
    selectedV2 += vtitle + ",";
  }

  // a method to combine all the selected violation types from values1 and values2 in one variable
  void selectedAllGetter() {
    selectedAll = selectedV1 + "" + selectedV2;
  }

  // a boolean that will be used to check what does the user choses from the confirmation dialog and track his actions
  bool done = false;

  // a boolean that will be used to check what does the user choses from the delete dialog and track his actions
  bool delete = false;

  // a boolean to check wither the user is using the Ar version of the app or the En and present the interface according to it
  bool arLnag = "showVideoHead".tr == 'Violation Video' ? false : true;

  //########################################################PopUp Dialogs(Sucess,Confirm,Delete)########################################
  //a dialog to show sucessfull actions of the user in the page, if confirming or deleting the violation video
  void _showSucess(String descr, int index) {
    _AdditionalInfo.text =
        ""; // will clear the additional information field whenever the success dialog appears
    AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.success,
        animType: AnimType.scale,
        headerAnimationLoop: false,
        dismissOnTouchOutside: false,
        title: 'success'.tr,
        desc: descr,
        btnOkText: 'Ok'.tr,
        btnOkOnPress: () {
          //when clicking ok, the user will be redircted to the confirmed violation reports page
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => RootApp(
                        pageIndex: index,
                      )));
        }).show();
  }

  //a dialog to show error message for the user if tries to confirm without selcting the type
  void _showSelectType() {
    AwesomeDialog(
            context: context,
            // btnCancelColor: Colors.grey,
            btnOkColor: GlobalColors.secondaryColorGreen,
            dialogType: DialogType.error,
            animType: AnimType.scale,
            headerAnimationLoop: false,
            dismissOnTouchOutside: false,
            title: 'SelecVTypeTitle'.tr,
            desc: "SelectVTypeDis".tr,
            btnOkText: 'Ok'.tr,
            btnOkOnPress: () {})
        .show();
  }

  //a dialog that will appeaar when the user clickes in the confirm button to ensure the user's action of confirming the video
  Future<void> _showMyDialog() async {
    return AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.noHeader,
        animType: AnimType.scale,
        dismissOnTouchOutside: false,
        title: 'Sure'.tr,
        desc: 'confViolation'.tr,
        btnOkText: "yes".tr,
        btnCancelText: 'C'.tr,
        //if the user clicks "cancel" the boolean "done" will be false meaning that the user is not sure about the confirmation and will stay in the same page
        btnCancelOnPress: () {
          done = false;
        },
        //if the user clicks "confirm" the boolean "done" will be true meaning that the user sure about the confirmation
        //The video will be updated in the databse as violation video and the selected types will be saved also the additional info if any
        btnOkOnPress: () {
          done = true;
          if (done) {
            final reportDoc = FirebaseFirestore.instance
                .collection("drivers")
                .doc(widget.userDocid)
                .collection("reports")
                .doc(widget.reportDocid);

            //update specfic fields
            reportDoc.update({
              'v_type': selectedAll,
              'status': 1,
              'addInfo': _AdditionalInfo.text,
            });
            _showSucess('conf'.tr, 2);

            //will show sucessful dialog then the user will be redircted to the confirmed reports page
          }
        }).show();
  }

  //a dialog that will appeaar when the user clickes in the confirm button to ensure the user's action of deleting the video
  Future<void> _showMyDialogDelete(_misclassifidied) async {
    return AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorRed,
        dialogType: DialogType.noHeader,
        animType: AnimType.scale,
        headerAnimationLoop: false,
        dismissOnTouchOutside: false,
        title: 'Sure'.tr,
        desc: 'delViolation'.tr,
        btnOkText: "yes".tr,
        btnCancelText: 'C'.tr,
        //if the user clicks "cancel" the boolean "done" will be false meaning that the user is not sure about the confirmation and will stay in the same page
        btnCancelOnPress: () {
          delete = false;
        },

        //if the user clicks "confirm" the boolean "done" will be true meaning that the user sure about the deletiong action
        //The video will be retrived and the url will be saved in another collection to enhance the model later (misclasssified videos)
        //after saving the video in the other collection the video will be deleted and the user will be redircted to the pedning violation videos page
        btnOkOnPress: () async {
          //confirme it
          delete = true;
          if (delete) {
            final reportDoc = FirebaseFirestore.instance
                .collection("drivers")
                .doc(widget.userDocid)
                .collection("reports")
                .doc(widget.reportDocid);

            //get video
            final QuerySnapshot<
                Map<String,
                    dynamic>> VideoDocInReport = await FirebaseFirestore
                .instance
                .collection("drivers")
                .doc(widget.userDocid)
                .collection("reports")
                .doc(widget.reportDocid)
                .collection("video")
                .get(); //get all documents in sub collections (get all reports)
            final List<video> Vid = VideoDocInReport.docs
                .map((Videos) => video.fromSnapShot(Videos))
                .toList();

            String video_url = (Vid[0].video_url); // to save the url
            for (var doc in VideoDocInReport.docs) // delete sub colletcio
            {
              await doc.reference.delete();
            }

            reportDoc.delete(); // delete report
            if (_misclassifidied) {
              //here we want to save the video in another collection for enha model
              final missClassVideo = video(video_url: video_url);
              final docMisV = FirebaseFirestore.instance
                  .collection('missClassifiedVideos')
                  .doc();
              missClassVideo.id = docMisV.id;
              final json = missClassVideo.toJsonD();

              ///create document and write data to firebase
              await docMisV.set(json);
            }
            _showSucess("delConfirmation".tr, 1);
          }
        }).show();
  }

  //########################################################Method for violation video controllers########################################
  Widget videoControllers(bool IsExpanded) {
    return Row(
      children: [
        Transform(
          alignment: Alignment.center,
          transform: Matrix4.rotationY(arLnag ? math.pi : 0),
          child: IconButton(
            padding: EdgeInsets.only(
                top: 4.0,
                bottom: 4.0,
                right: arLnag ? 0.0 : 4.0,
                left: arLnag ? 10.0 : 4.0),
            alignment: Alignment.centerLeft,
            onPressed: () {
              setState(() {
                _controller!.value
                        .isPlaying //check the statues of the controller (video) if playing then:
                    ? _controller!
                        .pause() //if the video is playing the ction to preform will be pause
                    : _controller!
                        .play(); //if it was pauseed the action will be playing
              });
            },
            icon: Icon(
              _controller!.value.isPlaying //if the video is playing
                  ? Icons.pause //show pause icon
                  : Icons.play_arrow, //else, show play icon
              color: IsExpanded ? Color.fromARGB(255, 0, 0, 0) : Colors.black,
              size: 35,
            ),
          ),
        ),
        Expanded(
          child: SizedBox(
            height: 15,
            child: VideoProgressIndicator(
                colors: VideoProgressColors(
                  playedColor: GlobalColors.secondaryColorRed,
                  bufferedColor: Color.fromARGB(51, 157, 149, 149),
                  backgroundColor: const Color.fromRGBO(200, 200, 200, 0.5),
                ),
                //will show a line to indicate the progress of the video
                padding:
                    EdgeInsets.only(top: 0, left: arLnag ? 13 : 0, right: 13),
                _controller!,
                allowScrubbing: true, //for seeking hte video
                arabicInterFace: arLnag),
          ),
        ),
        Align(
            // alignment: Alignment.topRight,
            child: PopupMenuButton<double>(
          initialValue: _controller!.value.playbackSpeed,
          tooltip: 'Playback speed',
          onSelected: (double speed) {
            _controller!.setPlaybackSpeed(speed);
          },
          itemBuilder: (BuildContext context) {
            return <PopupMenuItem<double>>[
              for (final double speed in _examplePlaybackRates)
                PopupMenuItem<double>(
                  value: speed,
                  child: Text(
                    '${speed}x',
                    style: TextStyle(
                        fontSize: 20,
                        color: IsExpanded ? Colors.black : Colors.black),
                  ),
                )
            ];
          },
          child: Padding(
            padding: EdgeInsets.only(
                top: 4.0,
                bottom: 0.0,
                right: arLnag ? 0.0 : 0.0,
                left: arLnag ? 10.0 : 0.0),
            child: Text(
              '${_controller!.value.playbackSpeed}x   ',
              style: TextStyle(
                  fontSize: 20,
                  color: IsExpanded ? Colors.white : Colors.black),
            ),
          ),
        )),
      ],
    );
  }

  //########################################################Method for expanding the violation video########################################
  void pushFullScreenVideo() {
    //This will help to hide the status bar and bottom bar of Mobile
    //also helps you to set preferred device orientations like landscape
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
        overlays: [SystemUiOverlay.bottom]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    SystemChrome.setPreferredOrientations(
      [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ],
    );
    //This will help you to push fullscreen view of video player on top of current page
    Navigator.of(context)
        .push(
      PageRouteBuilder(
        opaque: false,
        settings: const RouteSettings(),
        pageBuilder: (
          BuildContext context,
          Animation<double> animation,
          Animation<double> secondaryAnimation,
        ) {
          return Scaffold(
              backgroundColor: Colors.white, //ask about this
              body: Center(
                child: Stack(
                  //This will help to expand video in Horizontal mode till last pixel of screen
                  fit: StackFit.expand,
                  children: [
                    Stack(alignment: Alignment.bottomCenter, children: [
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          VideoPlayer(_controller!),
                          Container(
                            padding: EdgeInsets.all(20),
                            child: IconButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                icon: const Icon(
                                  Icons.fullscreen_exit,
                                  color: Colors.white,
                                  size: 45,
                                )),
                          ),
                        ],
                      ),
                      Container(
                          height: 50,
                          color: Colors.black,
                          child: videoControllers(true)),
                    ]),
                    Container(
                      padding: EdgeInsets.only(
                          right: 50, left: 50, bottom: 50, top: 20),
                      child: TextButton(
                        style: ButtonStyle(
                            overlayColor: MaterialStateProperty.all(
                                Color.fromARGB(29, 105, 105, 105))),
                        onPressed: () {
                          setState(() {
                            _controller!.value
                                    .isPlaying //check the statues of the controller (video) if playing then:
                                ? _controller!
                                    .pause() //if the video is playing the ction to preform will be pause
                                : _controller!
                                    .play(); //if it was pauseed the action will be playing
                          });
                        },
                        child: Container(
                          color: Colors.transparent,
                          alignment: Alignment.topCenter,
                          child: Text(
                            textAlign: TextAlign.center,
                            'pause/play'.tr,
                            style: const TextStyle(
                              color: Color.fromARGB(229, 255, 255, 255),
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ));
        },
      ),
    )
        .then(
      (value) {
        //This will help you to set previous Device orientations of screen so App will continue for portrait mode
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
            overlays: SystemUiOverlay.values);
        SystemChrome.setPreferredOrientations(
          [
            DeviceOrientation.portraitUp,
            DeviceOrientation.portraitDown,
          ],
        );
      },
    );
  }

  //########################################################Build########################################
  @override
  Widget build(BuildContext context) {
    // This controller will hold the vidoe
    final controller = _controller;
    return GestureDetector(
      //to allow the user to press in any part of the screen and remove the keyboard when it appears
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(
              Icons
                  .arrow_back_ios_rounded, //arrow in the appbar of the page to take the user back to the pending violation videos page
              size: 30,
            ),
            color: Colors.white,
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: Text('showVideoHead'.tr),
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: FractionalOffset(0.0, 0.4),
                  end: Alignment.topRight,
                  colors: <Color>[
                    GlobalColors.mainColorGreen,
                    GlobalColors.secondaryColorGreen
                  ]),
            ),
          ),
        ),
        body:
            //first container after the body
            Container(
          child: Column(
            children: [
              SizedBox(
                height: 40,
              ),

              //big white space
              Expanded(
                child: Container(
                  child: Container(
                    child: Column(
                      children: [
                        Flexible(
                          flex: 1,
                          child: Container(
                            child: Row(
                              children: [
                                //Calling the method that will genrtae the retrived video and show it in the interface
                                videoContet(),
                              ],
                            ),
                          ),
                        ),

                        //########################################################The Video Container########################################
                        //the controller is responsible for the video
                        if (controller != null &&
                            controller.value
                                .isInitialized) // if controller is not empty (null) and the value is intilized then go inside the container
                          videoControllers(false),

                        //########################################################The Radio Buttons and check Boxes and AdditionalInfo########################################
                        Expanded(
                          child: Container(
                            child: Scrollbar(
                              thickness: 10,
                              isAlwaysShown: true,
                              child: ListView(children: [
                                Container(
                                  height: 120,
                                  padding: EdgeInsets.symmetric(horizontal: 45),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                          'isViolation'
                                              .tr, //Ask the user if the video is a violation (Text)
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color:
                                                  GlobalColors.mainColorGreen,
                                              fontSize: 18,
                                              fontWeight: FontWeight.w500)),
                                      Container(
                                        child: Row(children: [
                                          //###RadioButtons to make the user selects (yes/no) according to the shown video and decide if it's violation or no  ###
                                          Expanded(
                                              flex: 1,
                                              child: Row(children: [
                                                Radio(
                                                  //Radio button of yes(1)
                                                  activeColor: GlobalColors
                                                      .mainColorGreen,
                                                  value:
                                                      1, //The value of the radio button yes
                                                  groupValue:
                                                      _value, //to determine wither the radio button is selcted or not
                                                  onChanged: ((value) {
                                                    setState(() {
                                                      _value = value!;
                                                    });
                                                  }),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                Container(
                                                    padding:
                                                        EdgeInsets.only(top: 5),
                                                    child: Text(
                                                      'yes'.tr,
                                                      style: TextStyle(
                                                        color: GlobalColors
                                                            .textColor,
                                                        fontSize: 15,
                                                      ),
                                                    ))
                                              ])),
                                          Expanded(
                                              flex: 1,
                                              child: Row(children: [
                                                Radio(
                                                  //Radio button of no(0)
                                                  activeColor: GlobalColors
                                                      .mainColorGreen,
                                                  value:
                                                      0, //The value of the radio button no
                                                  groupValue: _value,
                                                  onChanged: ((value) {
                                                    setState(() {
                                                      _value = value!;
                                                    });
                                                  }),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                Container(
                                                    padding:
                                                        EdgeInsets.only(top: 5),
                                                    child: Text(
                                                      'no'.tr,
                                                      style: TextStyle(
                                                        color: GlobalColors
                                                            .textColor,
                                                        fontSize: 15,
                                                      ),
                                                    ))
                                              ])),
                                        ]),
                                      ),
                                    ],
                                  ),
                                ),

                                //############################### Will Show the rest of the page according to the selected radio button, if yes selcted then show, if no then only show the delete###############################
                                SizedBox(
                                  height: 10,
                                ),
                                _value ==
                                        1 //If the value of the radio button was 1(yes, there is violation in the video wil have access on the rest of the page which is checkBoxes+AdditionalInfo)
                                    ? Column(
                                        children: [
                                          Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 20),
                                            child: Column(children: [
                                              Stack(
                                                children: [
                                                  Container(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              28, 0, 28, 0),
                                                      child: Column(
                                                        children: [
                                                          Material(
                                                            elevation: 7.0,
                                                            shadowColor: Colors
                                                                .black
                                                                .withOpacity(
                                                                    0.4),
                                                            child:
                                                                TextFormField(
                                                              maxLines: 6,
                                                              style: TextStyle(
                                                                  color: GlobalColors
                                                                      .mainColorGreen),
                                                              readOnly: true,
                                                              cursorColor:
                                                                  GlobalColors
                                                                      .mainColorGreen,
                                                              expands: false,
                                                              decoration:
                                                                  InputDecoration(
                                                                floatingLabelBehavior:
                                                                    FloatingLabelBehavior
                                                                        .always,
                                                                labelText:
                                                                    'violationType'
                                                                            .tr +
                                                                        " * ",
                                                                labelStyle:
                                                                    TextStyle(
                                                                  fontSize: 20,
                                                                  color: GlobalColors
                                                                      .mainColorGreen,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                                floatingLabelStyle:
                                                                    TextStyle(
                                                                  fontSize: 20,
                                                                  color: GlobalColors
                                                                      .mainColorGreen,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                                enabledBorder:
                                                                    OutlineInputBorder(
                                                                  borderSide: BorderSide(
                                                                      style: BorderStyle
                                                                          .solid,
                                                                      color: GlobalColors
                                                                          .mainColorGreen),
                                                                ),
                                                                focusedBorder:
                                                                    OutlineInputBorder(
                                                                  borderSide: BorderSide(
                                                                      style: BorderStyle
                                                                          .solid,
                                                                      color: GlobalColors
                                                                          .mainColorGreen),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      )),

                                                  //###################Container of Checkbocxes#######################
                                                  Container(
                                                    child: Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .only(
                                                            right: 15,
                                                          )),
                                                          Expanded(
                                                              flex: arLnag
                                                                  ? 9
                                                                  : 10,
                                                              child: Column(
                                                                //This coulmn will have the values of Map1(values1) of the violation types
                                                                children: values1
                                                                    .keys
                                                                    .map((String
                                                                        key) {
                                                                  return Transform
                                                                      .scale(
                                                                    scale: 0.8,
                                                                    child:
                                                                        Container(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .only(
                                                                        top: arLnag
                                                                            ? 8
                                                                            : 7,
                                                                        right:
                                                                            0,
                                                                      ),

                                                                      //########################################################CheckBoxes Starts Here########################################
                                                                      child: CheckboxListTile(
                                                                          contentPadding: EdgeInsets.only(
                                                                            right:
                                                                                0,
                                                                          ),
                                                                          controlAffinity: ListTileControlAffinity.leading,
                                                                          activeColor: GlobalColors.mainColorGreen,
                                                                          title: arLnag
                                                                              ? Transform.translate(
                                                                                  offset: const Offset(15, 2),
                                                                                  child: Text(
                                                                                    key,
                                                                                    style: TextStyle(
                                                                                      fontSize: 18.5,
                                                                                      height: 1.5,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                              : Transform.translate(
                                                                                  offset: const Offset(-20, 2.5),
                                                                                  child: Text(
                                                                                    key,
                                                                                    style: TextStyle(
                                                                                      fontSize: 18.5,
                                                                                      height: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                          value: values1[key], //Values of the chike boxes will hold the first list's violation types
                                                                          onChanged: (bool? value) {
                                                                            //when one of the check boxes selcted
                                                                            setState(() {
                                                                              values1[key] = value!;
                                                                              selectedV1 = "";
                                                                              values1.forEach((key, value) {
                                                                                //for each one of the violation types in the list check if that violation type ws slected if so, call the method which will save it in string
                                                                                if (value) {
                                                                                  typesV1(key); //if one of the checkboxes selcted take the value of that key and add it to the string that svaes the selcted values by calling the mthod typesV1
                                                                                }
                                                                              });
                                                                            });
                                                                          }),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                              )),
                                                          Expanded(
                                                              flex: 8,
                                                              child: Column(
                                                                //This coulmn will have the values of Map2(values2) of the violation types
                                                                children: values2
                                                                    .keys
                                                                    .map((String
                                                                        key) {
                                                                  return Transform
                                                                      .scale(
                                                                    scale: 0.8,
                                                                    child:
                                                                        Container(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .only(
                                                                        top: 8,
                                                                        right:
                                                                            0,
                                                                      ),
                                                                      child: CheckboxListTile(
                                                                          contentPadding: EdgeInsets.only(
                                                                            right:
                                                                                0,
                                                                          ),
                                                                          controlAffinity: ListTileControlAffinity.leading,
                                                                          activeColor: GlobalColors.mainColorGreen,
                                                                          title: arLnag
                                                                              ? Transform.translate(
                                                                                  offset: const Offset(15, 0),
                                                                                  child: Text(
                                                                                    key,
                                                                                    style: TextStyle(
                                                                                      fontSize: 18.5,
                                                                                      height: 2,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                              : Transform.translate(
                                                                                  offset: const Offset(-20, 2.5),
                                                                                  child: Text(
                                                                                    key,
                                                                                    style: TextStyle(
                                                                                      fontSize: 18.5,
                                                                                      height: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                          value: values2[key], //Values of the chike boxes will hold the second list's violation types
                                                                          onChanged: (bool? value) {
                                                                            setState(() {
                                                                              values2[key] = value!;
                                                                              selectedV2 = "";
                                                                              values2.forEach((key, value) {
                                                                                //for each one of the violation types in the list check if that violation type ws slected if so, call the method which will save it in string
                                                                                if (value) {
                                                                                  typesV2(key); //if one of the checkboxes selcted take the value of that key and add it to the string that svaes the selcted values by calling the mthod typesV2
                                                                                }
                                                                              });
                                                                            });
                                                                          }),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                              )),
                                                        ]),
                                                  ),
                                                ],
                                              ),

                                              SizedBox(
                                                height: 18,
                                              ),

                                              //########################################################The additional Information text field########################################
                                              Container(
                                                  padding: EdgeInsets.fromLTRB(
                                                      28, 0, 28, 0),
                                                  child: Column(
                                                    children: [
                                                      Material(
                                                        elevation: 7.0,
                                                        shadowColor: Colors
                                                            .black
                                                            .withOpacity(0.4),
                                                        child: TextFormField(
                                                          style: TextStyle(
                                                              color: GlobalColors
                                                                  .mainColorGreen),
                                                          showCursor: true,
                                                          cursorColor:
                                                              GlobalColors
                                                                  .mainColorGreen,
                                                          expands: false,
                                                          maxLines: null,
                                                          decoration:
                                                              InputDecoration(
                                                            floatingLabelBehavior:
                                                                FloatingLabelBehavior
                                                                    .always,
                                                            hintText:
                                                                'optinalAddInfo'
                                                                    .tr,
                                                            hintStyle:
                                                                TextStyle(
                                                              fontSize: 14,
                                                              color: Colors
                                                                  .grey[500],
                                                            ),
                                                            labelText:
                                                                'addInfo'.tr,
                                                            labelStyle:
                                                                TextStyle(
                                                              fontSize: 20,
                                                              color: GlobalColors
                                                                  .mainColorGreen,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            ),
                                                            floatingLabelStyle:
                                                                TextStyle(
                                                              fontSize: 20,
                                                              color: GlobalColors
                                                                  .mainColorGreen,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            ),
                                                            enabledBorder:
                                                                OutlineInputBorder(
                                                              borderSide: BorderSide(
                                                                  style:
                                                                      BorderStyle
                                                                          .solid,
                                                                  color: GlobalColors
                                                                      .mainColorGreen),
                                                            ),
                                                            focusedBorder:
                                                                OutlineInputBorder(
                                                              borderSide: BorderSide(
                                                                  style:
                                                                      BorderStyle
                                                                          .solid,
                                                                  color: GlobalColors
                                                                      .mainColorGreen),
                                                            ),
                                                          ),
                                                          controller:
                                                              _AdditionalInfo, //here will take whatever written in the text field (additional information) and save it in the variable that will deal with the database
                                                        ),
                                                      ),
                                                    ],
                                                  )), //end of additional info textfield
                                            ]),
                                          ),
                                        ],
                                      )
                                    : Container(),
                              ]),
                            ), //listview
                          ),
                        ),

                        //########################################################Confirmation/Deletion of the violation video Buttons########################################
                        Container(
                          width: MediaQuery.of(context).size.width,
                          padding: EdgeInsets.only(
                              top: 20,
                              right: arLnag ? 40 : 30,
                              left: arLnag ? 30 : 40),
                          height: 75,
                          child: Row(
                            mainAxisAlignment: arLnag
                                ? MainAxisAlignment.center
                                : MainAxisAlignment.start,
                            children: [
                              Flexible(
                                flex: 1,
                                child: Container(
                                  padding: EdgeInsets.only(
                                      left: (_value == 0 && arLnag)
                                          ? 50
                                          : (_value == 0)
                                              ? 100
                                              : 10,
                                      right: 10,
                                      bottom: (_value == 0) ? 0 : 0),
                                  child: Container(
                                    height: 40,
                                    width: MediaQuery.of(context).size.width *
                                        0.35,
                                    decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                            begin: Alignment.centerLeft,
                                            end: Alignment.centerRight,
                                            colors: [
                                              GlobalColors.mainColorRed,
                                              GlobalColors.secondaryColorRed
                                            ]),
                                        borderRadius: BorderRadius.circular(18),
                                        boxShadow: [
                                          BoxShadow(
                                            color: GlobalColors.mainColorRed
                                                .withOpacity(0.27),
                                            blurRadius: 10,
                                          ),
                                        ]),
                                    child: TextButton(
                                      style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll<Color>(
                                                Colors.transparent),
                                        foregroundColor:
                                            MaterialStatePropertyAll<Color>(
                                                GlobalColors
                                                    .secondaryColorGreen),
                                        shape: MaterialStateProperty.all<
                                                RoundedRectangleBorder>(
                                            RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(18.0),
                                        )),
                                      ),
                                      onPressed: () {
                                        _value ==
                                                1 //if the value of the radio button was 1 (yes) then the delete dialog will not be shown
                                            ? _showMyDialogDelete(false)
                                            : _showMyDialogDelete(
                                                true); //otherwise if the selcted radio button was 0 (no) then show the dialog of deleting the video
                                      },
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Center(
                                            child: Row(
                                              children: [
                                                Icon(
                                                  Icons
                                                      .playlist_remove_outlined,
                                                  color: Colors.white,
                                                ),
                                                arLnag
                                                    ? SizedBox(
                                                        width: 5,
                                                      )
                                                    : SizedBox(
                                                        width: 0,
                                                      ),
                                                Text(
                                                  '  delButton  '.tr,
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 15,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              _value ==
                                      1 //if the value of the radio button was 1(yes) shwo the confirmation button also along with the delete button
                                  ? Flexible(
                                      flex: 1,
                                      fit: FlexFit.tight,
                                      child: Container(
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Container(
                                          height: 40,
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.35,
                                          decoration: BoxDecoration(
                                              gradient: LinearGradient(
                                                  begin: Alignment.centerLeft,
                                                  end: Alignment.centerRight,
                                                  colors: [
                                                    GlobalColors.mainColorGreen,
                                                    GlobalColors
                                                        .secondaryColorGreen
                                                  ]),
                                              borderRadius:
                                                  BorderRadius.circular(18),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: GlobalColors
                                                      .mainColorGreen
                                                      .withOpacity(0.27),
                                                  blurRadius: 10,
                                                ),
                                              ]),
                                          child: TextButton(
                                            style: ButtonStyle(
                                              backgroundColor:
                                                  MaterialStatePropertyAll<
                                                          Color>(
                                                      Colors.transparent),
                                              foregroundColor:
                                                  MaterialStatePropertyAll<
                                                          Color>(
                                                      GlobalColors
                                                          .secondaryColorGreen),
                                              shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                  RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(18.0),
                                              )),
                                            ),
                                            onPressed: () {
                                              selectedAllGetter();
                                              if (selectedAll.isEmpty) {
                                                _showSelectType();
                                              } else {
                                                _showMyDialog();
                                              }
                                              //will call the method which will get all the selcted violation types
                                            },
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Center(
                                                  child: Row(
                                                    children: [
                                                      Icon(
                                                        Icons.checklist_rtl,
                                                        color: Colors.white,
                                                        // size: 15,
                                                      ),
                                                      SizedBox(
                                                        width: 3,
                                                      ),
                                                      Text(
                                                        '  confButton  '.tr,
                                                        style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 15,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 10,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  : Container(),
                            ],
                          ),
                        ), // The end of containers of the buttons
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  //########################################################The method of intilizing the Violation Video########################################
  Widget videoContet() {
    final controller = _controller;
    if (controller != null && controller.value.isInitialized) {
      //intilizing the video
      return Stack(alignment: Alignment.topRight, children: [
        Center(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            padding: EdgeInsets.only(left: 10, right: 10),
            child: controller.value.isInitialized
                ? VideoPlayer(controller)
                : Container(),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 0.0, right: 15),
          child: IconButton(
            icon: Icon(
              Icons.fullscreen_rounded, //show pause icon
              color: Colors.white,
              size: 35,
            ),
            onPressed: () {
              pushFullScreenVideo();
            },
          ),
        ),
      ]);
    } else {
      //if the video is not yet intilized then show a loading seen for the user
      return Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(alignment: Alignment.center, children: [
              Container(
                height: 50,
                child: Image.asset(
                  'assets/images/loadingLogoBlack.png', //Will show loading in the video area until the video is loaded
                  height: 105,
                  width: 105,
                ),
              ),
              Container(
                height: 35,
                width: 35,
                padding: EdgeInsets.only(left: 3),
                child: CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
            ]),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      );
    }
  }
}
