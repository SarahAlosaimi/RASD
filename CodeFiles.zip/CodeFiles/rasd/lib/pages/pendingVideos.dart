//This class for pending reports page
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:rasd/auth.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/pages/showVideo.dart';
import 'package:video_player/video_player.dart';
import 'package:rasd/shared/padding.dart';
import 'package:rasd/objects/report.dart';

class pendingVid extends StatefulWidget {
  const pendingVid({Key? key}) : super(key: key);

  @override
  _pendingVidState createState() => _pendingVidState();
}

class _pendingVidState extends State<pendingVid> {
  bool _playArea = false;
  final User? user = Auth().currentUser; //get the current user
  List<report> vidListtest = []; // list to store all the pending reports

  bool arLang = "PVV".tr == 'Pending Violation Videos'
      ? false
      : true; // determind which langanuage is displayed now , false -- > en , true ---> arabic

  //retrive all pending reports videos of the driver, and delete the reports that completed 30 days
  Future<List<report>> retrivePending() async {
    final QuerySnapshot<Map<String, dynamic>> PendingReportsQuery =
        await FirebaseFirestore.instance
            .collection("drivers")
            .doc(user?.uid)
            .collection("reports")
            .where('status', isEqualTo: 0) //status =  0 ---> pending report
            .get(); //get all documents in sub collections (get all reports)
    final List<report> allPendingreports = PendingReportsQuery.docs
        .map((PendingReportsDoc) => report.fromSnapShot(PendingReportsDoc))
        .toList();

    //############### delete reports after 30 days  ##########
    DateTime now = new DateTime.now(); // get the date of today
    DateTime date = new DateTime(now.year, now.month, now.day);
    var prevMonth = new DateTime(date.year, date.month - 1,
        date.day); // get the date of previous month from  the current date

    var dateToCompare =
        prevMonth.toString().substring(0, 10); // substring the date
    // get the report the have been complete 30 days
    final deleteSnap = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(user?.uid)
        .collection('reports')
        .where("date", isEqualTo: dateToCompare)
        .get();
    // delete the retrived documents
    for (var doc in deleteSnap.docs) {
      await doc.reference.delete();
    }

    if (mounted) {
      setState(() {
        vidListtest = allPendingreports;
      });
    }
    return allPendingreports;
  }

// method to navigate to the show video page
  void pushVid(report ReporttoPass) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => showVideo(
                  reportDocid: ReporttoPass.id,
                  userDocid: user!.uid,
                )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          decoration: _playArea == false
              ? BoxDecoration(
                  gradient: LinearGradient(
                      colors: [
                        GlobalColors.mainColorGreen,
                        GlobalColors.secondaryColorGreen
                      ],
                      begin: const FractionalOffset(0.0, 0.4),
                      end: Alignment.topRight),
                )
              : BoxDecoration(
                  gradient: LinearGradient(
                      colors: [
                        GlobalColors.mainColorGreen,
                        GlobalColors.secondaryColorGreen
                      ],
                      begin: const FractionalOffset(0.0, 0.4),
                      end: Alignment.topRight),
                ),
          child: Column(children: [
            Row(
              children: [
                //Pending videos header ( the green )
                Flexible(
                  child: Container(
                    padding:
                        const EdgeInsets.only(top: 18, right: 20, left: 20),
                    width: MediaQuery.of(context).size.width,
                    height: 180,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Container()),
                            Container(
                                padding: EdgeInsets.only(top: 15),
                                width: spacer,
                                child: Image.asset(
                                  'assets/images/logoWhite.png',
                                )),
                          ],
                        ),
                        SizedBox(
                          height: 0.2,
                        ),
                        Text(
                          'PVV'.tr,
                          style: TextStyle(
                              fontSize: 25,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          "Watch".tr + "Select".tr,
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            //The white section of the page
            Expanded(
                child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(70),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      offset: const Offset(
                        3.0,
                        8.0,
                      ), //Offset
                      blurRadius: 10.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                  ]),
              child: Column(
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  //the big white box is represented by this box
                  Row(),
                  //part of listed videos should start here
                  Expanded(
                    child: _listView(),
                  )
                ],
              ),
            ))
          ])),
    );
  }

  _listView() {
    //calling retrivePending() to check how many  pending reports the driver has.
    retrivePending();
    return vidListtest.length ==
            0 // if the numPending = 0  --> the user have no pending reports
        ?
        //if ture , show a page with a message indicates there is no pending reports
        Container(
            padding: EdgeInsets.only(left: 5),
            child: Column(children: [
              Column(
                children: [
                  SizedBox(
                    height: 100,
                  ),
                  Stack(alignment: Alignment.center, children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          GlobalColors.mainColorGreen,
                          GlobalColors.secondaryColorGreen,
                        ],
                        tileMode: TileMode.clamp,
                      ).createShader(bounds),
                      child: Icon(
                        Icons.videocam_off_rounded,
                        size: 100,
                        color: Colors.white,
                      ),
                    ),
                  ]),
                  SizedBox(
                    height: 10,
                  ),
                  Column(
                    children: [
                      Text(
                        "NPV".tr,
                        style: TextStyle(
                            color: GlobalColors.secondaryColorGreen,
                            fontWeight: FontWeight.bold,
                            fontSize: 20),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 70),
                        child: Text(
                          "NPVA".tr,
                          style: TextStyle(
                              color: GlobalColors.textColor, fontSize: 15),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ]),
          )
        :
        //if false then show a list of pending reports
        ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 8),
            itemCount: vidListtest.length,
            itemBuilder: (_, int index) {
              return GestureDetector(
                child: _buildCard(index + 1),
              );
            });
  }

  _buildCard(int index) {
    // ############### to calculate the countdown before delete the reports ##############
    var reportday = vidListtest[index - 1].date; // creation date
    var vidFullDate = vidListtest[index - 1].date;

    reportday = reportday.substring(0, 2); // the day
    var formatter = DateFormat.d().format(DateTime.now()); // current day
    var reportdayInt = int.parse(reportday); // parse creation day to integer
    var currentDay = int.parse(formatter); // parse current day to integer
    var deleteCountDown = 30 -
        (currentDay -
            reportdayInt); // substract from 30 since we will delete it after 30 days
    var days = '';
    if (deleteCountDown > 1) {
      //  if it was more than 1 day then 'days'
      days = 'days'.tr;
    } else {
      days = 'day'.tr;
    }

    // The single pending report which shows the violation video number , how many days left before deleted
    return Container(
      height: 100,
      width: 200,
      child: Column(children: [
        SizedBox(
          height: 15,
        ),
        Flexible(
          flex: 1,
          child: Container(
            child: TextButton(
              // on pressed it will navigate to show video page to view the violation video
              onPressed: () {
                pushVid(vidListtest[index - 1]); // changed
              },
              child: Row(
                children: [
                  Flexible(
                    flex: 1,
                    child: Container(
                      child: Stack(alignment: Alignment.center, children: [
                        ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              GlobalColors.mainColorGreen,
                              GlobalColors.secondaryColorGreen,
                            ],
                            tileMode: TileMode.clamp,
                          ).createShader(bounds),
                          child: Icon(
                            Icons.videocam_rounded,
                            size: 45,
                            color: Colors.white,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.only(right: 7),
                          child: Icon(
                            Icons.watch_later_rounded,
                            size: 10,
                            color: Colors.white,
                          ),
                        ),
                      ]),
                      //),
                    ),
                  ),
                  SizedBox(
                    width: 12,
                  ),
                  Container(
                    //color: Colors.purpleAccent,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 230,
                              child: Text(
                                "VV".tr + " $index",
                                style: TextStyle(
                                    color: GlobalColors.mainColorGreen,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: arLang
                              ? EdgeInsets.only(left: 90)
                              : EdgeInsets.only(right: 90),
                          child: Row(
                            children: [
                              Text(
                                "Violationdate".tr + vidFullDate,
                                style: TextStyle(
                                  color: GlobalColors.mainColorGreen,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 11.5,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 9,
                        ),
                        Container(
                          padding: arLang
                              ? EdgeInsets.only(left: 10)
                              : EdgeInsets.only(left: 0),
                          width: arLang ? 230 : 230,
                          child: Align(
                            alignment: arLang
                                ? Alignment.bottomRight
                                : Alignment.bottomLeft,
                            child: Row(
                              children: [
                                Text(
                                  "celCountV".tr +
                                      deleteCountDown.toString() +
                                      " " +
                                      days,
                                  style: TextStyle(
                                    color: GlobalColors.mainColorRed,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 11.5,
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(vertical: 1),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 10,
              ),
              Row(
                children: [
                  for (int i = 0; i < 125; i++)
                    i.isEven
                        ? Container(
                            width: 2,
                            height: 1,
                            decoration: BoxDecoration(
                              color: GlobalColors.mainColorRed,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          )
                        : Container(
                            width: 2,
                            height: 1,
                          ),
                ],
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
