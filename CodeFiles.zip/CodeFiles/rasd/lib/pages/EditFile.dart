import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:rasd/appRoot.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:video_player/video_player.dart';
import '../objects/report.dart';
import 'dart:math' as math; // import this

class EditFile extends StatefulWidget {
  const EditFile(
      {super.key, required this.reportDocid, required this.userDocid});
  final String reportDocid; //the retrived report id from the database
  final String userDocid; //the retrived user id from the database
  @override
  State<EditFile> createState() => _showVideoState();
}

class _showVideoState extends State<EditFile> {
  VideoPlayerController?
      _controller; //controller for the video that will be showing
  String video_url =
      ""; //a string that will hold the video url from the databse

  //for Disposing the video after leaving the page and not keeping it runining
  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  //Acontroller for the editied text of the additional information
  final TextEditingController _EditAddInfoController = TextEditingController();

  String editAddInfoText = "";
  //Play back rates for the video
  static const List<double> _examplePlaybackRates = <double>[
    0.25,
    0.5,
    1.0,
    1.5,
    2.0,
    4.0,
  ];

  //########################################################Firebase Retrival########################################
  @override
  void initState() {
    retriveInfo(); //Method to retrive the additional information
    retriveTypes(); //Method to retrive the previously selcted violation types
    _EditAddInfoController.text = editAddInfoText;
    super.initState();

    //will get the video url from the database for each specifiec user
    FirebaseFirestore.instance
        .collection("drivers")
        .doc(widget.userDocid)
        .collection("reports")
        .doc(widget.reportDocid)
        .collection("video")
        .get()
        .then((QuerySnapshot querySnapshot) => {
              querySnapshot.docs.forEach((doc) {
                video_url = doc["video_url"];
                final controller = VideoPlayerController.network(
                    video_url); //Controls a platform video player, and provides updates when the state is changing.

                _controller = controller;
                setState(() {});
                controller
                  ..initialize().then((_) {
                    controller.play();
                    setState(() {});
                  });
              })
            });
  }

  //########################################################Variables Defention########################################
  //A collection of key/value pairs, from which you retrieve a value using its associated key.
  //we have to Maps for the provided violation types with the check boxes
  Map<String, bool> values1 = {
    'viloation1'.tr: false,
    // 'viloation4'.tr: false,
    'viloation2'.tr: false,

    // 'IDK'.tr: false,
  };
  Map<String, bool> values2 = {
    'viloation3'.tr: false,
    // 'viloation2'.tr: false,
    'Other'.tr: false,
  };

  //A value of the radio buttons, 1 means selected 0 means not selected
  var _value = 1; //0 no, 1 yes

  //a string that will hold all the checked violations from the check boxes specilized for Map1(values1) (first 3 check boxes)
  var selectedV1 = "";
  //a string that will hold all the checked violations from the check boxes specilized for Map2(values2) (the left 2 check boxes)
  var selectedV2 = "";

  //a string that will hold the slected violation types from both Selcted values1 and 2
  var selectedAll = "";

  //########################################################Methods for the slected violation types########################################
  //a method to collect all violations types in (values1) and save it in (selectedV1) Comma-delimited
  void typesV1(String vtitle) {
    selectedV1 += vtitle + ",";
  }

  //a method to collect all violations types in (values2) and save it in (selectedV2) Comma-delimited
  void typesV2(String vtitle) {
    selectedV2 += vtitle + ",";
  }

  // a method to combine all the selected violation types from values1 and values2 in one variable
  void selectedAllGetter() {
    selectedAll = selectedV1 + "" + selectedV2;
  }

  // a boolean that will be used to check what does the user choses from the confirmation dialog and track his actions
  bool done = false;

  // a boolean that will be used to check what does the user choses from the delete dialog and track his actions
  bool delete = false;

  // a boolean to check wither the user is using the Ar version of the app or the En and present the interface according to it
  bool arLnag = "showVideoHead".tr == 'Violation Video' ? false : true;

  //List of the violation types selected by the driver (Before editing)
  List<String> VolationTypesBeforeEditing = [];

  //String of the additional information entered previously
  String AddInfoBefore = "";

//########################################################PopUp Dialogs(Sucess,Confirm,Delete)########################################
  //a dialog to show sucessfull actions of the user in the page, if confirming or deleting the violation video
  void _showSucess(String descr, int index) {
    AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.success,
        animType: AnimType.scale,
        headerAnimationLoop: false,
        dismissOnTouchOutside: false,
        title: 'success'.tr,
        desc: 'successEditing'.tr,
        btnOkText: 'Ok'.tr,
        btnOkOnPress: () {
          //when clicking ok, the user will be redircted to the confirmed violation reports page
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => RootApp(
                        pageIndex: index,
                      )));
        }).show();
  }

  //a dialog to show error message for the user if tries to confirm without selcting the type
  void _showSelectType() {
    AwesomeDialog(
            context: context,
            // btnCancelColor: Colors.grey,
            btnOkColor: GlobalColors.secondaryColorGreen,
            dialogType: DialogType.error,
            animType: AnimType.scale,
            headerAnimationLoop: false,
            dismissOnTouchOutside: false,
            title: 'SelecVTypeTitle'.tr,
            desc: "SelectVTypeDis".tr,
            btnOkText: 'Ok'.tr,
            btnOkOnPress: () {})
        .show();
  }

  //a dialog that will appeaar when the user clickes in the edit button to ensure the user's action of editing the video
  Future<void> _showMyDialog() async {
    return AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        dismissOnTouchOutside: false,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.noHeader,
        animType: AnimType.scale,
        title: 'Sure'.tr,
        desc: 'confEdit'.tr,
        btnOkText: "yes".tr,
        btnCancelText: 'C'.tr,
        //if the user clicks "cancel" the boolean "done" will be false meaning that the user is not sure about the confirmation and will stay in the same page
        btnCancelOnPress: () {
          done = false;
        },

        //if the user clicks "confirm" the boolean "done" will be true meaning that the user sure about the confirmation
        //The video will be updated in the databse as violation video and the selected types will be saved also the additional info if any
        btnOkOnPress: () {
          done = true;
          if (done) {
            final reportDoc = FirebaseFirestore.instance
                .collection("drivers")
                .doc(widget.userDocid)
                .collection("reports")
                .doc(widget.reportDocid);

            //update specfic fields
            reportDoc.update({
              'v_type': selectedAll,
              'status': 1,
              'addInfo':
                  editAddInfoText, //update database with new addtional information
            });

            //will show sucessful dialog then the user will be redircted to the confirmed reports page
            _showSucess('conf'.tr, 2); //*** Edit here to go pdf********/
          }
        }).show();
  }

  //########################################################Method for violation video controllers########################################
  Widget videoControllers(bool IsExpanded) {
    return Row(
      children: [
        Transform(
          alignment: Alignment.center,
          transform: Matrix4.rotationY(arLnag ? math.pi : 0),
          child: IconButton(
            padding: EdgeInsets.only(
                top: 4.0,
                bottom: 4.0,
                right: arLnag ? 0.0 : 4.0,
                left: arLnag ? 10.0 : 4.0),
            alignment: Alignment.centerLeft,
            onPressed: () {
              setState(() {
                _controller!.value
                        .isPlaying //check the statues of the controller (video) if playing then:
                    ? _controller!
                        .pause() //if the video is playing the ction to preform will be pause
                    : _controller!
                        .play(); //if it was pauseed the action will be playing
              });
            },
            icon: Icon(
              _controller!.value.isPlaying //if the video is playing
                  ? Icons.pause //show pause icon
                  : Icons.play_arrow, //else, show play icon
              color: IsExpanded ? Color.fromARGB(255, 0, 0, 0) : Colors.black,
              size: 35,
            ),
          ),
        ),
        Expanded(
          child: SizedBox(
            height: 15,
            child: VideoProgressIndicator(
                colors: VideoProgressColors(
                  playedColor: GlobalColors.secondaryColorRed,
                  bufferedColor: Color.fromARGB(51, 157, 149, 149),
                  backgroundColor: const Color.fromRGBO(200, 200, 200, 0.5),
                ),
                //will show a line to indicate the progress of the video
                padding:
                    EdgeInsets.only(top: 0, left: arLnag ? 13 : 0, right: 13),
                _controller!,
                allowScrubbing: true, //for seeking hte video
                arabicInterFace: arLnag),
          ),
        ),
        Align(
            // alignment: Alignment.topRight,
            child: PopupMenuButton<double>(
          initialValue: _controller!.value.playbackSpeed,
          tooltip: 'Playback speed',
          onSelected: (double speed) {
            _controller!.setPlaybackSpeed(speed);
          },
          itemBuilder: (BuildContext context) {
            return <PopupMenuItem<double>>[
              for (final double speed in _examplePlaybackRates)
                PopupMenuItem<double>(
                  value: speed,
                  child: Text(
                    '${speed}x',
                    style: TextStyle(
                        fontSize: 20,
                        color: IsExpanded ? Colors.black : Colors.black),
                  ),
                )
            ];
          },
          child: Padding(
            padding: EdgeInsets.only(
                top: 4.0,
                bottom: 0.0,
                right: arLnag ? 0.0 : 0.0,
                left: arLnag ? 10.0 : 0.0),
            child: Text(
              '${_controller!.value.playbackSpeed}x   ',
              style: TextStyle(
                  fontSize: 20,
                  color: IsExpanded ? Colors.white : Colors.black),
            ),
          ),
        )),
      ],
    );
  }

  //########################################################Method for expanding the violation video########################################
  void pushFullScreenVideo() {
    //This will help to hide the status bar and bottom bar of Mobile
    //also helps you to set preferred device orientations like landscape
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
        overlays: [SystemUiOverlay.bottom]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    SystemChrome.setPreferredOrientations(
      [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ],
    );
    //This will help you to push fullscreen view of video player on top of current page
    Navigator.of(context)
        .push(
      PageRouteBuilder(
        opaque: false,
        settings: const RouteSettings(),
        pageBuilder: (
          BuildContext context,
          Animation<double> animation,
          Animation<double> secondaryAnimation,
        ) {
          return Scaffold(
              backgroundColor: Colors.white, //ask about this
              body: Center(
                child: Stack(
                  //This will help to expand video in Horizontal mode till last pixel of screen
                  fit: StackFit.expand,
                  children: [
                    Stack(alignment: Alignment.bottomCenter, children: [
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          VideoPlayer(_controller!),
                          Container(
                            padding: EdgeInsets.all(20),
                            child: IconButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                icon: const Icon(
                                  Icons.fullscreen_exit,
                                  color: Colors.white,
                                  size: 45,
                                )),
                          ),
                        ],
                      ),
                      Container(
                          height: 50,
                          color: Colors.black,
                          child: videoControllers(true)),
                    ]),
                    Container(
                      padding: EdgeInsets.only(
                          right: 50, left: 50, bottom: 50, top: 20),
                      child: TextButton(
                        style: ButtonStyle(
                            overlayColor: MaterialStateProperty.all(
                                Color.fromARGB(29, 105, 105, 105))),
                        onPressed: () {
                          setState(() {
                            _controller!.value
                                    .isPlaying //check the statues of the controller (video) if playing then:
                                ? _controller!
                                    .pause() //if the video is playing the ction to preform will be pause
                                : _controller!
                                    .play(); //if it was pauseed the action will be playing
                          });
                        },
                        child: Container(
                          color: Colors.transparent,
                          alignment: Alignment.topCenter,
                          child: Text(
                            textAlign: TextAlign.center,
                            'pause/play'.tr,
                            style: const TextStyle(
                              color: Color.fromARGB(229, 255, 255, 255),
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ));
        },
      ),
    )
        .then(
      (value) {
        //This will help you to set previous Device orientations of screen so App will continue for portrait mode
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
            overlays: SystemUiOverlay.values);
        SystemChrome.setPreferredOrientations(
          [
            DeviceOrientation.portraitUp,
            DeviceOrientation.portraitDown,
          ],
        );
      },
    );
  }

//########################################################Build########################################
  @override
  Widget build(BuildContext context) {
    // this is to show the previously additional info on the interface
    // _EditAddInfoController.text = editAddInfoText;

    //thid is for the crouser to be at the end of the text
    _EditAddInfoController.selection = TextSelection.fromPosition(
        TextPosition(offset: _EditAddInfoController.text.length));
    final controller = _controller;
    return GestureDetector(
      //to allow the user to press in any part of the screen and remove the keyboard when it appears
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        // resizeToAvoidBottomInset: false,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios_rounded,
              size: 30,
            ),
            color: Colors.white,
            onPressed: () {
              //goes to pdf
              Navigator.pop(context); //will go back to the pdf file
            },
          ),
          title: Text('EditReportHead'.tr),
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: FractionalOffset(0.0, 0.4),
                  end: Alignment.topRight,
                  colors: <Color>[
                    GlobalColors.mainColorGreen,
                    GlobalColors.secondaryColorGreen
                  ]),
            ),
          ),
        ),
        body:
            //first container after the body
            Column(
          children: [
            SizedBox(
              height: 40,
            ),
            //big white space
            Expanded(
              child: Column(
                children: [
                  Flexible(
                    flex: 1,
                    child: Container(
                      child: Row(
                        children: [
                          //Calling the method that will genrtae the retrived video and show it in the interface
                          videoContet(),
                        ],
                      ),
                    ),
                  ),

                  //########################################################The Video Container########################################
                  //the controller is responsible for the video
                  if (controller != null &&
                      controller.value
                          .isInitialized) // if controller is not empty (null) and the value is intilized then go inside the container
                    videoControllers(false),
                  //########################################################The check Boxes and AdditionalInfo########################################
                  Expanded(
                    child: Container(
                      child: Scrollbar(
                        thickness: 10,
                        isAlwaysShown: true,
                        child: ListView(children: [
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Column(children: [
                              Stack(
                                children: [
                                  Container(
                                      padding:
                                          EdgeInsets.fromLTRB(28, 0, 28, 0),
                                      child: Column(
                                        children: [
                                          Material(
                                            elevation: 7.0,
                                            shadowColor:
                                                Colors.black.withOpacity(0.4),
                                            child: TextFormField(
                                              maxLines: 8,
                                              style: TextStyle(
                                                  color: GlobalColors
                                                      .mainColorGreen),
                                              showCursor: false,
                                              readOnly: true,
                                              cursorColor:
                                                  GlobalColors.mainColorGreen,
                                              expands: false,
                                              decoration: InputDecoration(
                                                floatingLabelBehavior:
                                                    FloatingLabelBehavior
                                                        .always,
                                                labelText:
                                                    'violationType'.tr + " * ",
                                                labelStyle: TextStyle(
                                                  fontSize: 20,
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                floatingLabelStyle: TextStyle(
                                                  fontSize: 20,
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                      style: BorderStyle.solid,
                                                      color: GlobalColors
                                                          .mainColorGreen),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                      style: BorderStyle.solid,
                                                      color: GlobalColors
                                                          .mainColorGreen),
                                                ),
                                              ),
                                            ),
                                          ),
                                          // SizedBox(
                                          //   height: MediaQuery.of(context)
                                          //       .viewInsets
                                          //       .bottom,
                                          // ),
                                        ],
                                      )),
                                  Container(
                                    child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                              padding: EdgeInsets.only(
                                            right: 15,
                                          )),
                                          Expanded(
                                              flex: arLnag ? 9 : 10,
                                              child: Column(
                                                //This coulmn will have the values of Map1(values1) of the violation types

                                                children: values1.keys
                                                    .map((String key) {
                                                  return Transform.scale(
                                                    scale: 0.8,
                                                    child: Container(
                                                      padding: EdgeInsets.only(
                                                        right: 0,
                                                        top: arLnag ? 8 : 7,
                                                      ),
                                                      child:

                                                          //########################################################CheckBoxes Starts Here########################################
                                                          CheckboxListTile(
                                                              contentPadding:
                                                                  EdgeInsets
                                                                      .only(
                                                                          right:
                                                                              0),
                                                              controlAffinity:
                                                                  ListTileControlAffinity
                                                                      .leading,
                                                              activeColor:
                                                                  GlobalColors
                                                                      .mainColorGreen,
                                                              title: arLnag
                                                                  ? Transform
                                                                      .translate(
                                                                      offset:
                                                                          const Offset(
                                                                              15,
                                                                              2),
                                                                      child:
                                                                          Text(
                                                                        key,
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              18.5,
                                                                          height:
                                                                              1.5,
                                                                        ),
                                                                      ),
                                                                    )
                                                                  : Transform
                                                                      .translate(
                                                                      offset: const Offset(
                                                                          -20,
                                                                          2.5),
                                                                      child:
                                                                          Text(
                                                                        key,
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              18.5,
                                                                          height:
                                                                              1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                              value: values1[
                                                                  key], //Values of the chike boxes will hold the first list's violation types
                                                              onChanged: (bool?
                                                                  value) {
                                                                //when one of the check boxes selcted

                                                                setState(() {
                                                                  values1[key] =
                                                                      value!;
                                                                  selectedV1 =
                                                                      "";
                                                                  values1.forEach(
                                                                      //for each one of the violation types in the list check if that violation type ws slected if so, call the method which will save it in string

                                                                      (key, value) {
                                                                    if (value) {
                                                                      typesV1(
                                                                          key); //if one of the checkboxes selcted take the value of that key and add it to the string that svaes the selcted values by calling the mthod typesV1
                                                                    }
                                                                  });
                                                                });
                                                              }),
                                                    ),
                                                  );
                                                }).toList(),
                                              )),
                                          Expanded(
                                              flex: 8,
                                              child: Column(
                                                //This coulmn will have the values of Map2(values2) of the violation types

                                                children: values2.keys
                                                    .map((String key) {
                                                  return Transform.scale(
                                                    scale: 0.8,
                                                    child: Container(
                                                      padding: EdgeInsets.only(
                                                        right: 0,
                                                        top: 8,
                                                      ),
                                                      child: CheckboxListTile(
                                                          contentPadding:
                                                              EdgeInsets.only(
                                                                  right: 0),
                                                          controlAffinity:
                                                              ListTileControlAffinity
                                                                  .leading,
                                                          activeColor:
                                                              GlobalColors
                                                                  .mainColorGreen,
                                                          title: arLnag
                                                              ? Transform
                                                                  .translate(
                                                                  offset:
                                                                      const Offset(
                                                                          15,
                                                                          0),
                                                                  child: Text(
                                                                    key,
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          18.5,
                                                                      height: 2,
                                                                    ),
                                                                  ),
                                                                )
                                                              : Transform
                                                                  .translate(
                                                                  offset:
                                                                      const Offset(
                                                                          -20,
                                                                          2.5),
                                                                  child: Text(
                                                                    key,
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          18.5,
                                                                      height: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                          value: values2[
                                                              key], //Values of the chike boxes will hold the second list's violation types
                                                          onChanged:
                                                              (bool? value) {
                                                            setState(() {
                                                              values2[key] =
                                                                  value!;
                                                              selectedV2 = "";
                                                              values2.forEach(
                                                                  (key, value) {
                                                                //for each one of the violation types in the list check if that violation type ws slected if so, call the method which will save it in string

                                                                if (value) {
                                                                  typesV2(
                                                                      key); //if one of the checkboxes selcted take the value of that key and add it to the string that svaes the selcted values by calling the mthod typesV2
                                                                }
                                                              });
                                                            });
                                                          }),
                                                    ),
                                                  );
                                                }).toList(),
                                              )),
                                        ]),
                                  ),
                                ],
                              ),

                              SizedBox(
                                height: 18,
                              ),

                              //########################################################The additional Information text field########################################
                              Container(
                                  padding: EdgeInsets.fromLTRB(28, 0, 28, 0),
                                  child: Column(
                                    children: [
                                      Material(
                                        elevation: 7.0,
                                        shadowColor:
                                            Colors.black.withOpacity(0.4),
                                        child: GestureDetector(
                                          onTap: () =>
                                              FocusScope.of(context).unfocus(),
                                          child: TextFormField(
                                            style: TextStyle(
                                                color: GlobalColors
                                                    .mainColorGreen),
                                            showCursor: true,
                                            cursorColor:
                                                GlobalColors.mainColorGreen,
                                            expands: false,
                                            maxLines: null,
                                            decoration: InputDecoration(
                                              floatingLabelBehavior:
                                                  FloatingLabelBehavior.always,
                                              labelText: 'addInfo'.tr,
                                              labelStyle: TextStyle(
                                                fontSize: 20,
                                                color:
                                                    GlobalColors.mainColorGreen,
                                                fontWeight: FontWeight.bold,
                                              ),
                                              floatingLabelStyle: TextStyle(
                                                fontSize: 20,
                                                color:
                                                    GlobalColors.mainColorGreen,
                                                fontWeight: FontWeight.bold,
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    style: BorderStyle.solid,
                                                    color: GlobalColors
                                                        .mainColorGreen),
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    style: BorderStyle.solid,
                                                    color: GlobalColors
                                                        .mainColorGreen),
                                              ),
                                            ),
                                            controller:
                                                _EditAddInfoController, //here will take whatever written in the text field (Edited additional information) and save it in the variable that will deal with the database
                                          ),
                                        ),
                                      ),
                                    ],
                                  )), //end of additional info textfield
                            ]),
                          )
                        ]),
                      ), //listview
                    ),
                  ),

                  //########################################################Edit of the violation video Button########################################
                  Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.only(
                        top: 20,
                        right: arLnag ? 140 : 30,
                        left: arLnag ? 10 : 50),
                    height: 75,
                    child: Row(
                      children: [
                        _value == 1
                            ? Container(
                                padding:
                                    const EdgeInsets.only(left: 80, right: 0),
                                child: Container(
                                  height: 40,
                                  width:
                                      MediaQuery.of(context).size.width * 0.35,
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                          colors: [
                                            GlobalColors.mainColorGreen,
                                            GlobalColors.secondaryColorGreen
                                          ]),
                                      borderRadius: BorderRadius.circular(18),
                                      boxShadow: [
                                        BoxShadow(
                                          color: GlobalColors.mainColorGreen
                                              .withOpacity(0.27),
                                          blurRadius: 10,
                                        ),
                                      ]),
                                  child: TextButton(
                                    style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStatePropertyAll<Color>(
                                              Colors.transparent),
                                      foregroundColor:
                                          MaterialStatePropertyAll<Color>(
                                              GlobalColors.secondaryColorGreen),
                                      shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(18.0),
                                      )),
                                    ),
                                    onPressed: () {
                                      selectedAllGetter();
                                      if (selectedAll.isEmpty) {
                                        _showSelectType();
                                      } else {
                                        setState(() {
                                          // to save the new value of additional information in varible
                                          editAddInfoText =
                                              _EditAddInfoController.text;
                                        });
                                        selectedAllGetter();
                                        _showMyDialog();
                                      }
                                    },

                                    //   setState(() {
                                    //     // to save the new value of additional information in varible
                                    //     editAddInfoText =
                                    //         _EditAddInfoController.text;
                                    //   });
                                    //   selectedAllGetter();
                                    //   _showMyDialog();
                                    // },
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Center(
                                          child: Row(
                                            children: [
                                              SizedBox(
                                                width: 3,
                                              ),
                                              Text(
                                                'editLink'.tr,
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 15,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                  //containers of buttons ende
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  //########################################################retrive information before editing########################################
  Future<void> retriveInfo() async {
    report r;
    final docReport = await FirebaseFirestore.instance
        .collection("drivers")
        .doc(widget.userDocid) // here we got the document of the driver
        .collection("reports")
        .doc(widget
            .reportDocid) // here we got the document of the specfied report
        .get() // this is used to get the fields
        .then((docReport) {
      // then means
      r = report.fromJsonD(docReport
          .data()!); // we convert the data from json to report object (to get access to the attrubites )
      editAddInfoText = r.addInfo; // addInfoBefore

      return editAddInfoText;
    });

    _EditAddInfoController.text = editAddInfoText;
  }

  //########################################################this is for rertreving Violation types########################################
  Future<void> retriveTypes() async {
    report r;
    final docReport = await FirebaseFirestore.instance
        .collection("drivers")
        .doc(widget.userDocid)
        .collection("reports")
        .doc(widget.reportDocid)
        .get()
        .then((docReport) {
      r = report.fromJsonD(docReport.data()!);

      String tmp = r.v_type; //store all violation types as string
      VolationTypesBeforeEditing =
          tmp.split(","); // store the violation types as list
      // make the checkboxes checked (Before editing)
      for (int i = 0; i < VolationTypesBeforeEditing.length; i++) {
        // check values
        (values1).forEach((key, value) {
          if (key == VolationTypesBeforeEditing[i]) {
            values1[key] = !value;
            typesV1(key);
          }
        });

        (values2).forEach((key, value) {
          if (key == VolationTypesBeforeEditing[i]) {
            values2[key] = !value;
            typesV2(key);
          }
        });
      }
    });
  }

  //########################################################The method of intilizing the Violation Video########################################
  Widget videoContet() {
    final controller = _controller;
    if (controller != null && controller.value.isInitialized) {
      //intilizing the video
      return Stack(alignment: Alignment.topRight, children: [
        Center(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.35,
            padding: EdgeInsets.only(left: 10, right: 10),
            child: controller.value.isInitialized
                ? VideoPlayer(controller)
                : Container(),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 0.0, right: 15),
          child: IconButton(
            icon: Icon(
              Icons.fullscreen_rounded, //show pause icon
              color: Colors.white,
              size: 35,
            ),
            onPressed: () {
              pushFullScreenVideo();
            },
          ),
        ),
      ]);
    } else {
      //if the video is not yet intilized then show a loading seen for the user
      return Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 0.35,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(alignment: Alignment.center, children: [
              Container(
                height: 50,
                child: Image.asset(
                  'assets/images/loadingLogoBlack.png', //Will show loading in the video area until the video is loaded
                  height: 105,
                  width: 105,
                ),
              ),
              Container(
                height: 35,
                width: 35,
                padding: EdgeInsets.only(left: 3),
                child: CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
            ]),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      );
    }
  }
}
