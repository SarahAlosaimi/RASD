import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:rasd/Splash.dart';
import 'package:rasd/pages/forgotPasswordPage.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/shared/widgets/textFormGlobal.dart';
import '../auth.dart';
import 'package:rasd/objects/driver.dart'; //change later
import 'package:crypto/crypto.dart';
import 'dart:convert';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  //##########################################################Variables Defention##################################################################

  final GlobalKey<FormState> _formKeylogIn = GlobalKey<
      FormState>(); // it is used to deal with the login page form (input fields)
  final GlobalKey<FormState> _formKeySignUp = GlobalKey<
      FormState>(); // it is used to deal with the Sign Up page form (input fields)

  //to hold the entered information i the logIn/SignUp pages
  final TextEditingController emilController = TextEditingController();
  final TextEditingController PhoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController passwordController2 = TextEditingController();
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();

  //this list will have the local languages of the application
  final List locale = [
    {'name': 'English', 'locale': Locale('en', 'US')},
    {'name': 'العربية', 'locale': Locale('ar', 'AE')},
  ];

  String? errorMessageData =
      ''; //a string which will hold the error messages that might appear to the user
  String? errorMessageValid = '';
  bool isDataBasEerrorMessage = true; //Error message from the databse
  bool isLogin = true; //will use it to check if we rae in the login page
  bool isArabic =
      false; //To check at which version we are in, the Arabic or the English and will display the interface accordignly
  bool arLnag = "lang".tr == 'English'
      ? false
      : true; //To check at which version we are in, the Arabic or the English and will display the interface accordignly
  bool showPassClicked =
      false; //fot the password wether it is shown to the user or not - in Sign Up page
  bool isVisible =
      true; //for the passwrod view option (the eye icon) - in Sign Up page
  bool showPassClickedConf =
      false; //fot the password wether it is shown to the user or not  - password confirmation field in Sign Up page
  bool isVisibleConf =
      true; //for the passwrod view option (the eye icon)- password confirmation field in Sign Up page
  bool showPassClickedLogin =
      false; //fot the password wether it is shown to the user or not  - in log In page
  bool isVisibleLogin =
      true; //for the passwrod view option (the eye icon) - log In page
  bool ppCheck = false; //to check if the privacy policy is clicked
  bool agremntClicked =
      false; // to heck if the checkbox of the agreemnt on privacy policy is clicked
  bool registerClicked = false; //if button register was clicked
  bool _signUpValid = false; //if the sign up entered info was valid
  String? phoenNum; //string to hold the enterd phone number

//##########################################################Methods Defention##################################################################

  //a method to update the language accroding to the list of local langauges previosly defined
  updateLanguage(Locale local) {
    Get.back();
    Get.updateLocale(local);
  }

  //a mthod to build the dialog that will be shown fo the user where they can select thier preferred interface langauge
  buildDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (builder) {
          return AlertDialog(
            title: Text("choosePr".tr),
            content: Container(
              width: 10,
              child: ListView.separated(
                  //list view that will hold every elemnt in the list of the offered languages (local)
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: GestureDetector(
                          onTap: () {
                            //based on the selction of the user for thier preferred langauge everything will be updated
                            updateLanguage(locale[index]['locale']);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Splash()));
                          },
                          child: Text(locale[index]['name'])),
                    );
                  },
                  separatorBuilder: (context, index) {
                    return Divider(
                      color: GlobalColors.mainColorGreen,
                    );
                  },
                  itemCount: locale.length),
            ),
          );
        });
  }

  //A method for the user signing in to the application
  Future<void> signInWithEmailAndPassword() async {
    try {
      await Auth().signInWithEmailAndPassword(
        //Auth to authinticate the user entered crdintials and check if the user previosly registered or not
        email: emilController
            .text, //will take the enetered text which is saved in the email controller
        password: passwordController
            .text, //will take the enetered text which is saved in the password controller
      );
    } on FirebaseAuthException catch (e) {
      //if an error occured when the user tries to sign in
      setState(() {
        String passIsNotCorrect =
            'The password is invalid or the user does not have a password.'; //this error will appear if the user enteres an invalid password
        String emailIsNotCorrect =
            'There is no user record corresponding to this identifier. The user may have been deleted.'; //this error will appear if the user enteres an invalid email
        String networkError =
            'A network error (such as timeout, interrupted connection or unreachable host) has occurred.'; //this error will appear if there is any general error regarding to netwrok while trying to sign in
        if (e.message == passIsNotCorrect) {
          //if the error was regarding to the password being incorrect
          errorMessageData = 'EmailPassError'.tr;
        } else if (e.message == emailIsNotCorrect) {
          //if the error was regarding to the email being incorrect
          errorMessageData = 'EmailPassError'.tr;
        } else if (e.message == networkError) {
          //if the error was regarding to the network which reject the sign in attemption
          errorMessageData = 'networkError'.tr;
        } else {
          print(e.message);
          errorMessageData = e.message;
        }
        _showError(
            errorMessageData!); //will show a dialog indicating the error based on the specific type of that error
      });
    }
  } //signInWithEmailAndPassword

  //A methd for the user when trying to register for the first time in the application
  Future<void> createUserWithEmailAndPassword() async {
    var data = utf8.encode(passwordController
        .text); // data being hashed to be saved hashed in the database
    var hashvalue = sha1.convert(data); //the type of used hashing
    try {
      await Auth().createUserWithEmailAndPassword(
          // to authinticate the creation of the user by his email and password
          email: emilController
              .text, //will take the enetered text which is saved in the email controller to creat the user credintials with it
          password: passwordController
              .text, //will take the enetered text which is saved in the password controller
          driver: Driver(
            //call class driver to creat a doc for the driver in the database with a specific attribuite
            Fname: firstNameController
                .text, //will take the enetered text which is saved in the first name controller and save it in the database
            Lname: lastNameController
                .text, //will take the enetered text which is saved in the last name controller and save it in the database

            //dashcam and any related filed to the dashcam will ne assigned later when the user link it through the application
            //initially it all will be null
            dashcam_id: 'null', //
            dashcam_username: 'null',
            dashcam_pass: 'null',
            rtsp_url: 'null',

            email: emilController
                .text, //will take the enetered text which is saved in the email controller and save it in the database
            hash_pass: hashvalue
                .toString(), //will take the hashed password and save it in the database
            phone_number:
                phoenNum!, //will take the phone number of the user and save it in the database
            phoneVerfied:
                false, //initially twhen registring the user will not have to verfiy his phone number, the verfication can be done after registring
          ));
    } on FirebaseAuthException catch (e) {
      //if any error appeared while siging up
      setState(() {
        String networkError =
            'A network error (such as timeout, interrupted connection or unreachable host) has occurred.';
        String emailUsed =
            'email-already-in-use'; //this error will appear if there is any general error regarding to netwrok while trying to sign in
        if (e.code == emailUsed) {
          //if the error was regarding to the password being incorrect
          errorMessageData = 'AccountExist'.tr;
        } else if (e.message == networkError) {
          //if the error was regarding to the network which reject the sign in attemption
          errorMessageData = 'networkError'.tr;
        } else {
          print(e.code);
          errorMessageData = e
              .message; //show the error message for the user // I think we need to translet this
        }
        _showError(
            errorMessageData!); //will show a dialog indicating the error based on the specific type of that error
      });
    }
  } //createUserWithEmailAndPassword

  //check the validatiy of the entered information by the user
  bool checkValidation(GlobalKey<FormState> _formKey) {
    bool Validity = true;
    if (_formKey.currentState!.validate()) {
      isDataBasEerrorMessage = true;
      Validity = true;
    } else {
      isDataBasEerrorMessage = false;
      Validity = false;
    }
    return Validity;
  }

  //will clear the controlleres (clearing the text input fields)
  void _clearControllers() {
    emilController.clear();
    passwordController.clear();
    firstNameController.clear();
    lastNameController.clear();
    passwordController2.clear();
    PhoneController.clear();
  }

  //to force the user to agree on RASD privacy policy, otherwise they will not have a chance to register
  //agreeing on the privacy policy is mandatory
  Widget _CompleteAgreemntMssg() {
    return Visibility(
      visible: !agremntClicked && _signUpValid,
      child: Text(
        "demandPolicy".tr,
        style: TextStyle(color: GlobalColors.mainColorRed, fontSize: 15),
      ),
    );
  }

  //##########################################################Privacy Policy Dialog##################################################################
  showPPAlert() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  20.0,
                ),
              ),
            ),
            contentPadding: EdgeInsets.only(
              top: 10.0,
            ),
            content: SingleChildScrollView(
              child: Column(
                //all of the items of the privacy policy will be listed inside this column
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    width: double.infinity,
                    height: 30,
                  ),
                  //Each item of the privacy policy will have a special heading for it, this heading will be in a container itself
                  //Each item of the privacy policy will be presented in a container, we have 6 itmes so 6 containers one for each item

                  //containers related to item1
                  Container(
                    alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it1".tr,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: GlobalColors.mainColorGreen),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it1text".tr,
                        style: TextStyle(
                            fontSize: 16, color: GlobalColors.textColor),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),

                  //containers related to item2
                  Container(
                    alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it2".tr,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: GlobalColors.mainColorGreen),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    // user info text
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it2text".tr,
                        style: TextStyle(
                            fontSize: 16, color: GlobalColors.textColor),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),

                  //containers related to item3

                  Container(
                    alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it3".tr,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: GlobalColors.mainColorGreen),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    // item three text
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it3text".tr,
                        style: TextStyle(
                            fontSize: 16, color: GlobalColors.textColor),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),

                  //containers related to item4

                  Container(
                    alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it4".tr,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: GlobalColors.mainColorGreen),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    // item three text
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it4text".tr,
                        style: TextStyle(
                            fontSize: 16, color: GlobalColors.textColor),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),

                  //containers related to item5

                  Container(
                    alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it5".tr,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: GlobalColors.mainColorGreen),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    // item three text
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it5text".tr,
                        style: TextStyle(
                            fontSize: 16, color: GlobalColors.textColor),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 25,
                  ),

                  //containers related to item6

                  Container(
                    alignment: arLnag ? Alignment.topRight : Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it6".tr,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: GlobalColors.mainColorGreen),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    // item three text
                    alignment: Alignment.topLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "it6text".tr,
                        style: TextStyle(
                            fontSize: 16, color: GlobalColors.textColor),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),

                  //container of the button "ok" in the dialog of the privacy policy to close it
                  Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(20.0),
                                bottomRight: Radius.circular(20.0)),
                          ),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  alignment: Alignment.center,
                                  height: 40,
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                          colors: [
                                            GlobalColors.mainColorGreen,
                                            GlobalColors.secondaryColorGreen
                                          ]),
                                      borderRadius: BorderRadius.circular(6),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color.fromARGB(225, 4, 99, 65)
                                              .withOpacity(0.27),
                                          blurRadius: 10,
                                        ),
                                      ]),
                                  child: TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text(
                                      "okButton".tr,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  //a diolag to show the error messages regarding to loggining in or signing up
  void _showError(String message) {
    if (message == '') return;
    AwesomeDialog(
            context: context,
            btnCancelColor: Colors.grey,
            btnOkColor: GlobalColors.secondaryColorGreen,
            dialogType: DialogType.error,
            animType: AnimType.scale,
            dismissOnTouchOutside: true,
            headerAnimationLoop: false,
            title: 'E'.tr,
            desc: message,
            btnOkText: 'Ok'.tr,
            btnOkOnPress: () {})
        .show();
  }

  //widget which will hold the button of changeing the language which will appear in both login and sign up pages
  Widget langButton() {
    return Row(
      children: [
        TextButton(
          onPressed: () {
            buildDialog(
                context); //when pressing on the button will call the method that is related to the local langauge
          },
          style: TextButton.styleFrom(
            primary: Colors.transparent,
          ),
          child: Container(
            child: isArabic
                ? Row(
                    children: [
                      Text(
                        "lang".tr,
                        style: TextStyle(
                          color: GlobalColors.textColor,
                          fontSize: 20,
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Icon(
                        Icons.language,
                        size: 20,
                        color: GlobalColors.textColor,
                      ),
                    ],
                  )
                : Row(
                    children: [
                      Icon(
                        Icons.language,
                        size: 15,
                        color: GlobalColors.textColor,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "lang".tr,
                        style: TextStyle(
                            color: GlobalColors.textColor, fontSize: 15),
                      ),
                    ],
                  ),
          ),
        ),
      ],
    );
  }

  //the submit button is two, one for login and one for sign up
  Widget submitButton() {
    return Container(
      alignment: Alignment.center,
      height: 47,
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: (!isLogin &&
                      (!_signUpValid ||
                          !agremntClicked)) // if the user is not in the log in interface and if the sign up action is vot valid or the user didn't click on the agreemnt of privacy policy
                  ? [
                      //the sign up button will be disabled
                      const Color.fromARGB(255, 4, 99, 65).withOpacity(0.4),
                      const Color.fromARGB(255, 4, 99, 65).withOpacity(0.4)
                    ]
                  : [
                      GlobalColors.mainColorGreen,
                      GlobalColors.secondaryColorGreen
                    ]),
          borderRadius: BorderRadius.circular(6),
          boxShadow: [
            BoxShadow(
              color: (!isLogin && (!_signUpValid || !agremntClicked))
                  ? Color.fromARGB(225, 4, 99, 65).withOpacity(0.1)
                  : Color.fromARGB(255, 4, 99, 65).withOpacity(0.27),
              blurRadius: 10,
            ),
          ]),
      child: TextButton(
        onPressed: (!isLogin && (!_signUpValid || !agremntClicked))
            ? null // if not, the button on pressed will do nothing and it's not clickable (disable)
            : () {
                //otherwise the usen will be validated and granted acess
                bool validated = false;
                if (isLogin) {
                  validated = checkValidation(_formKeylogIn);
                  if (validated) {
                    signInWithEmailAndPassword();
                  } else if (!validated) {
                    setState(() {});
                  }
                } else {
                  setState(() {
                    registerClicked = true;
                  });
                  if (_signUpValid) {
                    if (agremntClicked) {
                      _formKeySignUp.currentState?.save();
                      createUserWithEmailAndPassword();
                    }
                  }
                }
              },
        style: TextButton.styleFrom(
          primary: Colors.transparent,
        ),
        child: Container(
          //the text on the button that will be showmn according to the interface wether it was a log in or sign up
          //the text on the button will be changed accordignly
          alignment: Alignment.center,
          child: Text(
            isLogin ? 'logIn'.tr : 'signUp'.tr,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  } //submitButton

  //this widget is about clicking the button of logging in or registeration
  //the action of clicking will clear controlllerz and also will reset the variables to it's initial value
  Widget loginOrRegisterButton() {
    return TextButton(
      style: TextButton.styleFrom(
        primary: Colors.transparent,
      ),
      onPressed: () {
        setState(() {
          registerClicked = false;
          isLogin = !isLogin;
          _clearControllers();
          ppCheck = false;
          agremntClicked = false;
          showPassClicked = false;
          isVisible = true;
          showPassClickedConf = false;
          isVisibleConf = true;
          showPassClickedLogin = false;
          isVisibleLogin = true;
          errorMessageData = '';
          errorMessageValid = '';
        });
      },

      //this is alink where it will show Signup for the user if they eas in the log in page
      //and it will show log in if they were in the sign up page
      //to give the user the ability to navigate back and forth through these two pages
      child: Text(
        isLogin ? 'signUp'.tr : 'logIn2'.tr,
        style: TextStyle(
          color: GlobalColors.secondaryColorGreen,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  } //loginOrRegisterButton

  //a link in the log in page which will be clicked if the user was alrady logged in to the appication
  //if the user forgets thier password they click it and then they wil be redircted to the forget password
  //where they can send a link to the email they are registerd with to reset the password of thier account
  Widget ForgotPassword() {
    return GestureDetector(
      child: Text(
        'forogtPass'.tr,
        style: TextStyle(
          decoration: TextDecoration.underline,
          decorationThickness: 10,
          color: GlobalColors.secondaryColorGreen,
          fontSize: 15,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => ForgotPasswordPage(),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!isLogin) {
      //if the user is isn't in the log in page
      return GestureDetector(
        //to allow the user to press in any part of the screen and remove the keyboard when it appears
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          body: SingleChildScrollView(
            child: SafeArea(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 5),
                    langButton(), //here we are calling the method which shows the preferred langauge and when clicked allow to change it
                    Container(
                        //container to present RASD's logo in the pages
                        alignment: Alignment.center,
                        child: Image.asset('assets/images/logo.png',
                            height: 120, width: 120)),
                    const SizedBox(height: 13),
                    Text(
                      'creatAcc'
                          .tr, //it is the mean hidding which will be shown in the Sign up page for th user
                      style: TextStyle(
                        color: GlobalColors.textColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 15),

                    //##########################################################Will Satrt taking the Regesration Info##################################################################

                    //####################first name input field####################//
                    Form(
                        key: _formKeySignUp,
                        onChanged: () {
                          setState(() {
                            _signUpValid = checkValidation(
                                _formKeySignUp); //wiil check the validation of the enterd first name and accordignly will show the requirments of every field
                          });
                        },
                        child: Column(
                          children: [
                            Container(
                              width: 500,
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 15,
                                    child: TextFormGlobal(
                                      controller:
                                          firstNameController, //the controller which holds the first name will be used to pass whatever it saved to the controller of form gllobal
                                      text:
                                          'FN'.tr, //the hint text of the field
                                      obsecure:
                                          false, //obecure is false becuase we don't want the text to be invisable to the user
                                      textInputType: TextInputType
                                          .text, //the type of the input is simply text
                                      isLogin:
                                          false, //islog in false becuase we are in the sign up fields
                                    ),
                                  ),
                                  const SizedBox(width: 15),

                                  //####################last name input field####################//
                                  Expanded(
                                    flex: 15,
                                    child: TextFormGlobal(
                                      controller:
                                          lastNameController, //the controller which holds the last name will be used to pass whatever it saved to the controller of form gllobal
                                      text:
                                          'LN'.tr, //the hint text of the field
                                      obsecure:
                                          false, //obecure is false becuase we don't want the text to be invisable to the user
                                      textInputType: TextInputType
                                          .text, //the type of the input is simply text
                                      isLogin:
                                          false, //islog in false becuase we are in the sign up fields
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 15),

                            //####################Email input field####################//
                            TextFormGlobal(
                              controller:
                                  emilController, //the controller which holds the email will be used to pass whatever it saved to the controller of form gllobal
                              text: 'email'.tr,
                              obsecure: false,
                              textInputType: TextInputType.emailAddress,
                              isLogin: false,
                            ),

                            //####################Phone number ####################//
                            const SizedBox(height: 15),
                            Row(children: [
                              Flexible(
                                flex: 1,
                                child: Stack(
                                  children: [
                                    Stack(
                                      children: [
                                        Container(
                                            height: 50,
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black
                                                        .withOpacity(0.1),
                                                    blurRadius: 10,
                                                  ),
                                                ])),
                                        Positioned(
                                          left: 99,
                                          top: 8,
                                          bottom: 8,
                                          child: Container(
                                            height: 40,
                                            width: 1,
                                            color:
                                                Colors.black.withOpacity(0.13),
                                          ),
                                        )
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(
                                          left: arLnag ? 10 : 10, top: 0),
                                      child: Directionality(
                                        textDirection: arLnag
                                            ? TextDirection.ltr
                                            : TextDirection.ltr,
                                        child:
                                            //A simple and customizable flutter package for inputting phone number in international format
                                            InternationalPhoneNumberInput(
                                          spaceBetweenSelectorAndTextField:
                                              arLnag ? 30 : 12,
                                          selectorButtonOnErrorPadding: 40,

                                          countries: [
                                            'SA'
                                          ], //we want the international key of Saudi Arabia only to be shown countries is a lsit and we choose from it, the flag and +966 is the result
                                          locale: arLnag ? 'ar' : 'en',

                                          onInputChanged: (PhoneNumber number) {
                                            //when start typing on the field the input will be a number
                                          },
                                          onInputValidated: (bool value) {
                                            //check the validity of the entered phone number
                                          },
                                          ignoreBlank:
                                              false, //we don't want any blanks
                                          autoValidateMode: AutovalidateMode
                                              .onUserInteraction,
                                          selectorTextStyle: TextStyle(
                                              color: GlobalColors.textColor),
                                          textFieldController:
                                              PhoneController, //the controller which holds the phonenumber will be used to pass whatever it saved
                                          formatInput: false,
                                          maxLength: 9,
                                          keyboardType: const TextInputType
                                                  .numberWithOptions(
                                              signed: true, decimal: true),
                                          cursorColor:
                                              GlobalColors.mainColorGreen,
                                          inputDecoration: InputDecoration(
                                            //the actual phone number input space
                                            hintTextDirection: arLnag
                                                ? TextDirection.rtl
                                                : TextDirection.ltr,
                                            errorStyle: TextStyle(
                                                color:
                                                    GlobalColors.mainColorRed,
                                                fontSize: 15.0),
                                            contentPadding: EdgeInsets.only(
                                              right: arLnag ? 10 : 0,
                                              bottom: 13,
                                              left: 0,
                                            ),
                                            border: InputBorder.none,
                                            hintText: 'PhoneNum'
                                                .tr, //the hint text of the field
                                            hintStyle: TextStyle(fontSize: 16),
                                          ),
                                          onSaved: (PhoneNumber number) {
                                            setState(() {
                                              phoenNum = number.phoneNumber;
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ]),

                            const SizedBox(height: 15),

                            //####################Passsword input field####################//
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                showPassClicked //if it is true then the show password icon was clicked and the entered password in not obsecured
                                    ? TextFormGlobal(
                                        controller: passwordController,
                                        text: 'pass'.tr,
                                        obsecure:
                                            false, //obecure is true becuase we want the password to be invisable to the user
                                        textInputType: TextInputType.text,
                                        isLogin: false,
                                      )
                                    //other wise if the icon isn't clikecd then the password will be hidden from the user's seen, it will be as dots
                                    : TextFormGlobal(
                                        controller: passwordController,
                                        text: 'pass'.tr,
                                        obsecure:
                                            true, //obecure is false becuase we don't want the password to be invisable to the user
                                        textInputType: TextInputType.text,
                                        isLogin: false,
                                      ),
                                isVisible //it will check if the password is visiable to the user, if it was visiable and the eye icon clicked it will make it invisable
                                    ? Positioned(
                                        top: 2,
                                        child: Container(
                                          height: 47,
                                          width: 300,
                                          child: arLnag
                                              ? Padding(
                                                  //arLnag true?
                                                  padding: EdgeInsets.only(
                                                    right: 260,
                                                  ),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClicked = true;
                                                        isVisible = false;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility_off,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                )
                                              : Padding(
                                                  //arLnag false?
                                                  padding: EdgeInsets.only(
                                                    left: 260,
                                                  ),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClicked = true;
                                                        isVisible = false;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility_off,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                ),
                                        ),
                                      )
                                    :
                                    //otherwise if the eye icon clicked it will make it invisable
                                    Positioned(
                                        top: 2,
                                        child: Container(
                                          height: 47,
                                          width: 300,
                                          child: arLnag
                                              ? Padding(
                                                  padding: EdgeInsets.only(
                                                      right: 260),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClicked = false;
                                                        isVisible = true;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                )
                                              : Padding(
                                                  padding: EdgeInsets.only(
                                                      left: 260),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClicked = false;
                                                        isVisible = true;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                ),
                                        ),
                                      ),
                              ],
                            ),

                            const SizedBox(height: 15),
                            //####################Password confirmation input field####################//
                            //every thing is the same as the password except the variables of the visibility and showing the password, it will have it's own variables
                            Stack(
                              alignment: Alignment.center,
                              children: [
                                showPassClickedConf
                                    ? TextFormGlobal(
                                        controller: passwordController2,
                                        text: 'confPass'.tr,
                                        obsecure: false,
                                        textInputType: TextInputType.text,
                                        isLogin: false,
                                        passController: passwordController,
                                      )
                                    : TextFormGlobal(
                                        controller: passwordController2,
                                        text: 'confPass'.tr,
                                        obsecure: true,
                                        textInputType: TextInputType.text,
                                        isLogin: false,
                                        passController: passwordController,
                                      ),
                                isVisibleConf
                                    ? Positioned(
                                        top: 2,
                                        child: Container(
                                          height: 47,
                                          width: 300,
                                          child: arLnag
                                              ? Padding(
                                                  padding: EdgeInsets.only(
                                                    right: 260,
                                                  ),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClickedConf =
                                                            true;
                                                        isVisibleConf = false;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility_off,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                )
                                              : Padding(
                                                  padding: EdgeInsets.only(
                                                    left: 260,
                                                  ),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClickedConf =
                                                            true;
                                                        isVisibleConf = false;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility_off,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                ),
                                        ),
                                      )
                                    : Positioned(
                                        top: 2,
                                        child: Container(
                                          height: 47,
                                          width: 300,
                                          child: arLnag
                                              ? Padding(
                                                  padding: EdgeInsets.only(
                                                      right: 260),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClickedConf =
                                                            false;
                                                        isVisibleConf = true;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                )
                                              : Padding(
                                                  padding: EdgeInsets.only(
                                                      left: 260),
                                                  child: TextButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        showPassClickedConf =
                                                            false;
                                                        isVisibleConf = true;
                                                      });
                                                    },
                                                    child: Icon(
                                                      Icons.visibility,
                                                      size: 20,
                                                      color: GlobalColors
                                                          .mainColorGreen,
                                                    ),
                                                  ),
                                                ),
                                        ),
                                      ),
                              ],
                            ),

                            //##########################################################Privacy Policy agrremnt/chekboxes##################################################################

                            arLnag
                                ? Row(
                                    children: [
                                      //will show an icon as a check box to be clicked as an agreemnt on the privacy policy of RASD

                                      ppCheck //if is it true will set it back to false
                                          ? Container(
                                              padding:
                                                  const EdgeInsets.all(0.0),
                                              width: 15.0,
                                              child: IconButton(
                                                  padding: EdgeInsets.only(
                                                      right: 25),
                                                  onPressed: () {
                                                    setState(() {
                                                      ppCheck =
                                                          false; //initially the checkbox isn't clikecd
                                                      agremntClicked =
                                                          false; //and the user haven't agreed yet on the privacy policy
                                                    });
                                                  },

                                                  //the checkbox icon
                                                  icon: Icon(
                                                    Icons.check_box,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                    size: 17,
                                                  )),
                                            )
                                          :
                                          //if false will set it to true
                                          Container(
                                              padding:
                                                  const EdgeInsets.all(0.0),
                                              width: 15.0,
                                              child: IconButton(
                                                  padding: EdgeInsets.only(
                                                      right: 25),
                                                  onPressed: () {
                                                    setState(() {
                                                      ppCheck = true;
                                                      agremntClicked = true;
                                                    });
                                                  },
                                                  icon: Icon(
                                                    Icons
                                                        .check_box_outline_blank,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                    size: 17,
                                                  )),
                                            ),

                                      ///icons for checking the privacy policy ends here

                                      //the text button next to the check box of the privacy policy which will be as a link and trigger a pop up by calling the showPPAlert() method
                                      TextButton(
                                        onPressed: () {
                                          setState(() {
                                            showPPAlert();
                                          });
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              top: 5, right: 10),
                                          child: Stack(children: [
                                            Text(
                                              "Agreemnt1".tr,
                                              style: TextStyle(
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                  fontSize: 13),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  right: 0),
                                              child: Text(
                                                '\n' + "Agreemnt2".tr,
                                                style: TextStyle(
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                  fontSize: 13,
                                                  decoration:
                                                      TextDecoration.underline,
                                                  decorationThickness: 10,
                                                  fontStyle: FontStyle.italic,
                                                ),
                                              ),
                                            ),
                                          ]),
                                        ),
                                      ),
                                    ],
                                  )
                                : Row(
                                    //if arLnag was flase
                                    children: [
                                      //a repeatible parts for the english version of the page
                                      //icons for pp starts here
                                      ppCheck
                                          ? Container(
                                              padding:
                                                  const EdgeInsets.all(0.0),
                                              width: 15.0,
                                              child: IconButton(
                                                  padding: EdgeInsets.only(
                                                      right: 25),
                                                  onPressed: () {
                                                    setState(() {
                                                      ppCheck = false;
                                                      agremntClicked = false;
                                                    });
                                                  },
                                                  icon: Icon(
                                                    Icons.check_box,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                    size: 17,
                                                  )),
                                            )
                                          : Container(
                                              padding:
                                                  const EdgeInsets.all(0.0),
                                              width: 15.0,
                                              child: IconButton(
                                                  padding: EdgeInsets.only(
                                                      right: 25),
                                                  onPressed: () {
                                                    setState(() {
                                                      ppCheck = true;
                                                      agremntClicked = true;
                                                    });
                                                  },
                                                  icon: Icon(
                                                    Icons
                                                        .check_box_outline_blank,
                                                    color: GlobalColors
                                                        .mainColorGreen,
                                                    size: 17,
                                                  )),
                                            ),

                                      ///icons for checking the privacy policy ends here

                                      TextButton(
                                        onPressed: () {
                                          setState(() {
                                            showPPAlert();
                                          });
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              top: 5, left: 10),
                                          child: Stack(children: [
                                            Text(
                                              "Agreemnt1".tr,
                                              style: TextStyle(
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                  fontSize: 14),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 0),
                                              child: Text(
                                                '\n' + "Agreemnt2".tr,
                                                style: TextStyle(
                                                  color: GlobalColors
                                                      .mainColorGreen,
                                                  decoration:
                                                      TextDecoration.underline,
                                                  decorationThickness: 10,
                                                  fontStyle: FontStyle.italic,
                                                ),
                                              ),
                                            ),
                                          ]),
                                        ),
                                      )
                                    ],
                                  ),
                            _CompleteAgreemntMssg(), //will call the widget to make sure that the user have clicked on the agreemnt of the privacy policy
                          ],
                        )),
                    const SizedBox(height: 7),
                    const SizedBox(height: 5),
                    submitButton(),
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'alradyAcc'
                                .tr, //if the user does have an account and they way in the sign up page they can click this link to be redircted to the log in page
                            style: TextStyle(
                              color: GlobalColors.textColor,
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          loginOrRegisterButton()
                        ]),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    } else {
      //now if the user was in the log in page
      return GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          body: SingleChildScrollView(
            reverse: true,
            child: SafeArea(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(40.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    langButton(),
                    const SizedBox(height: 30),
                    Container(
                        alignment: Alignment.center,
                        child: Image.asset('assets/images/logo.png',
                            height: 130, width: 130)),
                    const SizedBox(height: 35),
                    Text(
                      'logToAcc'.tr, //heading to demand the user to log in
                      style: TextStyle(
                        color: GlobalColors.textColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 25),
                    Form(
                      key: _formKeylogIn,
                      child: Column(children: [
                        //####################Email input field ####################//
                        TextFormGlobal(
                          controller:
                              emilController, //the controller which holds the emal will be used to pass whatever it saved to the controller of form gllobal
                          text: 'email'.tr,
                          obsecure:
                              false, //obecure is false becuase we don't want the text to be invisable to the user
                          textInputType: TextInputType.emailAddress,
                          isLogin: true, //true because we are in the login page
                        ),
                        const SizedBox(height: 20),

                        //####################Password input field####################//
                        Stack(alignment: Alignment.center, children: [
                          showPassClickedLogin
                              ? TextFormGlobal(
                                  controller:
                                      passwordController, //the controller which holds the pssword will be used to pass whatever it saved to the controller of form gllobal
                                  text: 'pass'.tr,
                                  obsecure:
                                      false, //obecure is false since the show password icon was clicke and we want the password to be visiable to the user
                                  textInputType: TextInputType.text,
                                  isLogin: true,
                                )
                              : TextFormGlobal(
                                  controller: passwordController,
                                  text: 'pass'.tr,
                                  obsecure:
                                      true, //obecure is true since the show password icon wasn't cciked  and we don't want the password to be visiable to the user
                                  textInputType: TextInputType.text,
                                  isLogin: true,
                                ),
                          isVisibleLogin //for the eye(visiability icon) same settings as the one in the sign up page
                              ? Positioned(
                                  top: 2,
                                  child: Container(
                                    //color: Colors.amber,
                                    height: 47,
                                    width: 300,
                                    child: arLnag
                                        ? Padding(
                                            //arLnag true?
                                            padding: EdgeInsets.only(
                                              right: 260,
                                            ),
                                            child: TextButton(
                                              onPressed: () {
                                                setState(() {
                                                  showPassClickedLogin = true;
                                                  isVisibleLogin = false;
                                                });
                                              },
                                              child: Icon(
                                                Icons.visibility_off,
                                                size: 20,
                                                color:
                                                    GlobalColors.mainColorGreen,
                                              ),
                                            ),
                                          )
                                        : Padding(
                                            //arLnag false?
                                            padding: EdgeInsets.only(
                                              left: 260,
                                            ),
                                            child: TextButton(
                                              onPressed: () {
                                                setState(() {
                                                  showPassClickedLogin = true;
                                                  isVisibleLogin = false;
                                                });
                                              },
                                              child: Icon(
                                                Icons.visibility_off,
                                                size: 20,
                                                color:
                                                    GlobalColors.mainColorGreen,
                                              ),
                                            ),
                                          ),
                                  ),
                                )
                              : Positioned(
                                  top: 2,
                                  child: Container(
                                    height: 47,
                                    width: 300,
                                    child: arLnag
                                        ? Padding(
                                            padding:
                                                EdgeInsets.only(right: 260),
                                            child: TextButton(
                                              onPressed: () {
                                                setState(() {
                                                  showPassClickedLogin = false;
                                                  isVisibleLogin = true;
                                                });
                                              },
                                              child: Icon(
                                                Icons.visibility,
                                                size: 20,
                                                color:
                                                    GlobalColors.mainColorGreen,
                                              ),
                                            ),
                                          )
                                        : Padding(
                                            padding: EdgeInsets.only(left: 260),
                                            child: TextButton(
                                              onPressed: () {
                                                setState(() {
                                                  showPassClickedLogin = false;
                                                  isVisibleLogin = true;
                                                });
                                              },
                                              child: Icon(
                                                Icons.visibility,
                                                size: 20,
                                                color:
                                                    GlobalColors.mainColorGreen,
                                              ),
                                            ),
                                          ),
                                  ),
                                ),
                        ]),
                      ]),
                    ),
                    const SizedBox(height: 10),
                    const SizedBox(height: 10),
                    submitButton(),
                    const SizedBox(height: 15),
                    ForgotPassword(),
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'noAcc'.tr,
                            style: TextStyle(
                              color: GlobalColors.textColor,
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          loginOrRegisterButton(),
                        ]),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }
  } //build
}
