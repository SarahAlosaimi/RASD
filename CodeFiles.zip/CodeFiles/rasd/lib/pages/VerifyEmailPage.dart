import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rasd/appRoot.dart';
import '../shared/GlobalColors.dart';

class VerifyEmailPage extends StatefulWidget {
  @override
  _VerifyEmailPage createState() => _VerifyEmailPage();
}

class _VerifyEmailPage extends State<VerifyEmailPage> {
  bool isEmailVerified =
      false; // a boolean to shows if the email is verified or not
  Timer? timer;
  bool canResendEmail =
      false; // a boolean to shows if the user can resend the email or not
  bool arLnag = "resendE".tr == 'Resend Email'
      ? false
      : true; // determind which langanuage is displayed now , false -- > en , true ---> arabic

  @override
  void initState() {
    super.initState();

    //user needs to be created before
    isEmailVerified = FirebaseAuth.instance.currentUser!
        .emailVerified; // check whether the users email address has been verified

    if (!isEmailVerified) {
      // if not verified send a  verification email
      sendVerificationEmail();
      timer = Timer.periodic(
        Duration(seconds: 3),
        (_) => checkEmailVerified(),
      );
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future checkEmailVerified() async {
    // call after email verification
    await FirebaseAuth.instance.currentUser!.reload();
    setState(() {
      isEmailVerified = FirebaseAuth.instance.currentUser!.emailVerified;
    });

    if (isEmailVerified) // check if the email has been verified or not yet
      timer?.cancel();
  }

  // a method that Sends a verification email to a user.
  Future sendVerificationEmail() async {
    try {
      final user =
          FirebaseAuth.instance.currentUser!; // Returns the current user
      await user.sendEmailVerification();
      setState(() {
        canResendEmail = false;
      });
      await Future.delayed(Duration(
          seconds:
              30)); // wait 30 sec before the user be able to resend the email
      setState(() {
        canResendEmail = true;
      });
    } catch (e) {}
  }

// resend email button
  Widget resendButton() {
    return Container(
      alignment: Alignment.center,
      height: 47,
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: canResendEmail
                  ? [
                      GlobalColors.mainColorGreen,
                      GlobalColors.secondaryColorGreen
                    ]
                  : [
                      Color.fromARGB(225, 4, 99, 65).withOpacity(0.4),
                      Color.fromARGB(225, 4, 99, 65).withOpacity(0.4)
                    ]),
          borderRadius: BorderRadius.circular(6),
          boxShadow: [
            BoxShadow(
              color: canResendEmail
                  ? Color.fromARGB(225, 4, 99, 65).withOpacity(0.27)
                  : Color.fromARGB(225, 4, 99, 65).withOpacity(0.1),
              blurRadius: 10,
            ),
          ]),
      child: TextButton(
        onPressed: canResendEmail ? sendVerificationEmail : null,
        style: TextButton.styleFrom(
          primary: Colors.transparent,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: Text(
                'resendE'.tr,
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => isEmailVerified
      ?
      //if the email is verified return the application pages
      RootApp()
      :
      //if the email is not verified return the email verification page

      Scaffold(
          body: SingleChildScrollView(
            child: SafeArea(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(40.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 120),
                    Container(
                        alignment: Alignment.center,
                        child: Image.asset('assets/images/logo.png',
                            height: 130, width: 130)),
                    const SizedBox(height: 35),
                    Text(
                      'verfE'.tr,
                      style: TextStyle(
                        color: GlobalColors.textColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      'checkSpam'.tr,
                      style: TextStyle(
                        color: GlobalColors.textColor,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 25),
                    resendButton(),
                    const SizedBox(height: 10),
                    TextButton(
                        style: TextButton.styleFrom(
                          primary: Colors.transparent,
                          minimumSize: Size.fromHeight(50),
                        ),
                        onPressed: () {
                          FirebaseAuth.instance.signOut();
                        },
                        child: Text('cancel'.tr,
                            style: TextStyle(
                                color: GlobalColors.mainColorRed,
                                fontSize: 17))),
                  ],
                ),
              ),
            ),
          ),
        );
}
