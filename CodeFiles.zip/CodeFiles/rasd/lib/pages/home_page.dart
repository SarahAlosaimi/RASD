// This class is for the home page in the application
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:rasd/auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:rasd/appRoot.dart';
import 'package:rasd/shared/padding.dart';
import 'package:rasd/objects/report.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:rasd/pages/linkDashCam.dart';
import 'package:rasd/shared/Stream/streamVidHome.dart';
import 'package:url_launcher/url_launcher.dart';
import '../objects/driver.dart';

class HomePage extends StatefulWidget {
  HomePage({
    Key? key,
  }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  //Reterive the current user
  final User? user = Auth().currentUser;

  bool arLnag = "greeting".tr == 'Welcome To Rasd'
      ? false
      : true; // determind which langanuage is displayed now , false -- > en , true ---> arabic
  bool isLinked =
      false; // a boolean value indicates if the dashcam is linked or not
  List<report> vidListtest = []; // this is for pending reports list
  List<report> vidListtest2 = []; // this is for confirmed reports list
  String dashcamIP = ""; // dashcam IP

  @override
  // for loading the page  (CircularProgressIndicator)
  Widget _loading() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
      ),
      width: double.infinity,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Image.asset(
              'assets/images/loadingLogoBlack.png', //make it pop up
              height: 105,
              width: 105,
            ),
            Container(
              padding: EdgeInsets.only(left: 3),
              child: SizedBox(
                height: 43,
                width: 43,
                child: CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 140, right: 6),
              child: Image.asset(
                'assets/images/rasdTextBlack.png', //make it pop up
                height: 105,
                width: 105,
              ),
            )
          ],
        ),
        SizedBox(
          height: 10,
        ),
      ]),
    );
  }

// This method is to retrive the driver information from the database using his ID
  Future<Driver?> readUser(uid) async {
    final docUser = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(uid); // retrive the document
    final snapshot = await docUser.get();
    if (snapshot.exists) {
      return Driver.fromJsonD(snapshot.data()!); // return the information
    }
  }

//The bulid widget
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0.0,
          backgroundColor: const Color(0x00DE4B4B),
          brightness: Brightness.dark,
        ),
      ),
      body: FutureBuilder<Driver?>(
          future: readUser(user?.uid),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              // check if the user exists
              final user = snapshot.data;
              return user == null
                  ? Center(child: Text('no user'))
                  : buildUser(user); // bulid the interface if the user exists
            } else {
              return _loading(); //return loading if the user don't exists or there is an error/delay of reterive the info
            }
          }),
    );
  }

  ///############################retrive number of pending reports from the database###########################################################
  Future<void> retrivePending() async {
    // Get all the pending reports of the current user
    final QuerySnapshot<Map<String, dynamic>> PendingReportsQuery =
        await FirebaseFirestore.instance
            .collection("drivers")
            .doc(user?.uid)
            .collection("reports")
            .where('status', isEqualTo: 0) // 0 ---> pending report
            .get(); //get all documents in sub collections (get all reports)

    //convert the documents into list of pending reports
    final List<report> allPendingreports = PendingReportsQuery.docs
        .map((PendingReportsDoc) => report.fromSnapShot(PendingReportsDoc))
        .toList();
    if (mounted) {
      setState(() {
        vidListtest = allPendingreports;
      });
    }
  }

  ///############################retrive number of confirmed reports from the database###########################################################
  // Get all the confirmed reports of the current user
  Future<void> retriveConfirmed() async {
    final QuerySnapshot<Map<String, dynamic>> ConfirmedReportsQuery =
        await FirebaseFirestore.instance
            .collection("drivers")
            .doc(user?.uid)
            .collection("reports")
            .where('status', whereIn: [
      1,
      2 // status 1 , 2 ---> confirmed
    ]).get(); //get all documents in sub collections (get all reports)

    //convert the documents into list of confirmed reports
    final List<report> allConfrimedreports = ConfirmedReportsQuery.docs
        .map((ConfirmedReportsDoc) => report.fromSnapShot(ConfirmedReportsDoc))
        .toList();
    if (mounted) {
      setState(() {
        vidListtest2 = allConfrimedreports;
      });
    }
  }

  Widget buildUser(Driver driver) => getBody(driver);

  // the body of the page
  Widget getBody(Driver driver) {
    return Container(
      //the green background
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          GlobalColors.mainColorGreen,
          GlobalColors.secondaryColorGreen
        ], begin: const FractionalOffset(0.0, 0.4), end: Alignment.topRight),
      ),
      child: Column(
        children: [
          Container(
            //for elemnts on the top (Logo , greeting , driver's first name)
            padding: const EdgeInsets.only(top: 18, right: 10, left: 20),
            width: MediaQuery.of(context).size.width,
            height: 180,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Expanded(child: Container()),

                  ///******************Logo ***************************/
                  Flexible(
                    flex: 1,
                    child: Container(
                        padding: EdgeInsets.only(top: 15),
                        width: spacer,
                        child: Image.asset(
                          'assets/images/logoWhite.png',
                        )),
                  ),
                ]),
                SizedBox(
                  height: 0.2,
                ),
                Padding(
                  padding: arLnag
                      ? const EdgeInsets.only(right: 10.0)
                      : const EdgeInsets.all(0.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ///******************The driver first name ***************************/
                      Text(
                        arLnag
                            ? "أهلًا " + driver.Fname.capitalize! + "،"
                            : "Hi " + driver.Fname.capitalize! + ",",
                        style: TextStyle(
                            fontSize: 30,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),

                      ///******************Greeting ***************************/
                      Text(
                        "greeting".tr,
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
              child: Container(
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(70),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(
                      3.0,
                      8.0,
                    ), //Offset
                    blurRadius: 10.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                ]),
            child: Column(
              children: [
                const SizedBox(
                  height: 5,
                ),
                //the big white box is represented by this row
                Row(),

                Expanded(
                  // the list of cards
                  child: _listView(driver, driver.dashcam_id),
                ),
              ],
            ),
          ))
        ],
      ),
    );
  }

  Widget _listView(Driver driver, String dashID) {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: spacer),
      child: Column(children: [
        SizedBox(height: 15),
        buildLinkingCard(driver, dashID),
        //The pending reports card
        buildPendingCard(),
        //The confirmed reports card
        buildConfirmedCard(),

        Container(
          alignment: Alignment.center,
          width: arLnag ? 150 : 100,
          height: arLnag ? 33 : 30,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 227, 227, 227),
              ),
              BoxShadow(
                color: Colors.white70,
                spreadRadius: -1.0,
                blurRadius: 10.0,
              ),
            ],
          ),
          child: TextButton(
            onPressed: (() async {
              // if the driver clics on need hlep the app will navigate to RASD twitter account
              const url =
                  'https://twitter.com/messages/compose?recipient_id=1568325984218218496';
              if (await launch(url)) {
                await canLaunch(url);
              } else {
                throw 'Could not launch $url';
              }
            }),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Flexible(
                  child: Text(
                    "NeedHelp".tr,
                    style: TextStyle(
                      color: GlobalColors.textColor,
                      fontSize: 15,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }

//####################################Bulid pending Card#########################################################################
  Padding buildPendingCard() {
    //calling retrivePending() to check how many  pending reports the driver has.
    retrivePending();
    // Number of pending reports
    int numPending = vidListtest.length;
    //Buliding the card to show to the driver how many pending report he/she currently have
    return Padding(
      padding: const EdgeInsets.only(top: 0, right: 25, left: 25, bottom: 20),
      child: Container(
        width: double.infinity,
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(
                // left side padding is 40% of total width
                left:
                    arLnag ? 30 : MediaQuery.of(context).size.width * .35, // *
                top: 20,
                right:
                    arLnag ? MediaQuery.of(context).size.width * .35 : 30, //*
              ),
              height: 150,
              width: double.infinity,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.4),
                    spreadRadius: 2,
                    blurRadius: 15,
                    offset: Offset(0, 2), // changes position of shadow
                  ),
                ],
                gradient: LinearGradient(
                  colors: [Colors.white, Colors.white],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "pendVid".tr,
                      style: Theme.of(context).textTheme.headline6!.copyWith(
                          color: GlobalColors.textColor,
                          fontSize: arLnag ? 18 : 23),
                    ),
                    TextSpan(
                      text: numPending ==
                              0 // if the numPending --> the user have no pending reports
                          ? "noPending".tr
                          : numPending == 1
                              ? "pendVidNum1".tr +
                                  "$numPending" +
                                  "pendVidNum2singular".tr
                              : "pendVidNum1".tr +
                                  "$numPending" +
                                  "pendVidNum2".tr,
                      style: TextStyle(
                        fontSize: 14,
                        color: GlobalColors.mainColorRed,
                      ),
                    ),

                    // TextSpan(
                    //   text: numPending ==
                    //           0 // if the numPending --> the user have no pending reports
                    //       ? ""
                    //       : "NeedToBeConfirmed".tr, //*
                    //   style: TextStyle(
                    //     height: 3,
                    //     fontSize: 10,
                    //     color: GlobalColors.mainColorRed,
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(
                  bottom: arLnag ? 27 : 20,
                  top: arLnag ? 0 : 30,
                  left: arLnag ? 0 : 15), //*
              alignment:
                  arLnag ? Alignment.centerRight : Alignment.centerLeft, //*
              child: Stack(alignment: Alignment.center, children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      GlobalColors.mainColorGreen,
                      GlobalColors.secondaryColorGreen,
                    ],
                    tileMode: TileMode.clamp,
                  ).createShader(bounds),
                  child: Icon(
                    Icons.videocam_rounded,
                    size: 105,
                    color: Colors.white,
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(right: 15),
                  child: Icon(
                    Icons.watch_later_rounded,
                    size: 35,
                    color: Colors.white,
                  ),
                ),
              ]),
            ),
            // View pending report button
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Flexible(
                  flex: 1,
                  child: Container(
                    alignment:
                        arLnag ? Alignment.bottomLeft : Alignment.bottomRight,
                    padding: EdgeInsets.only(
                        left: arLnag ? 10 : 0,
                        right: 10,
                        bottom: arLnag ? 5 : 15),
                    child: Container(
                      height: 35,
                      width: 80,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                GlobalColors.mainColorGreen,
                                GlobalColors.secondaryColorGreen
                              ]),
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(225, 4, 99, 65)
                                  .withOpacity(0.27),
                              blurRadius: 10,
                            ),
                          ]),
                      child: TextButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStatePropertyAll<Color>(
                              Colors.transparent),
                          foregroundColor: MaterialStatePropertyAll<Color>(
                              GlobalColors.secondaryColorGreen),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                          )),
                        ),

// on pressed it will allows the driver to view the pending reports page
                        onPressed: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => RootApp(
                                        pageIndex: 1,
                                      )));
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 3.0),
                              child: Text(
                                'viewButton'.tr,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: arLnag ? 15 : 18,
                                    height: 1),
                              ),
                            ), // <-- Text
                            SizedBox(
                              width: 2,
                            ),
                            Icon(
                              // <-- Icon
                              Icons.arrow_forward_ios_rounded,
                              size: 15.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  //#############################################bulid confirmed card###############################################
  Padding buildConfirmedCard() {
    //calling  retriveConfirmed() to check how many  confirmed reports the driver has.
    retriveConfirmed();
    // Number of confirmed reports

    int numConfirmed = vidListtest2.length;

    //Buliding the card to show to the driver how many confirmed report he/she currently have

    return Padding(
      padding: const EdgeInsets.only(top: 0, right: 25, left: 25, bottom: 20),
      child: Container(
        width: double.infinity,
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(
                // left side padding is 40% of total width
                left:
                    arLnag ? 30 : MediaQuery.of(context).size.width * .35, // *
                top: 20,
                right:
                    arLnag ? MediaQuery.of(context).size.width * .35 : 30, //*
              ),
              height: 150,
              width: double.infinity,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.4),
                    spreadRadius: 2,
                    blurRadius: 15,
                    offset: Offset(0, 2), // changes position of shadow
                  ),
                ],
                gradient: LinearGradient(
                  colors: [Colors.white, Colors.white],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "ConfRep".tr,
                      style: Theme.of(context).textTheme.headline6!.copyWith(
                          color: GlobalColors.textColor,
                          fontSize: arLnag ? 18 : 22),
                    ),
                    TextSpan(
                      text: numConfirmed ==
                              0 // numConfirmed = 0 means that the driver has no confirmed report
                          ? "noConfirmed".tr
                          : "confRepNum1".tr + " $numConfirmed",
                      style: TextStyle(
                        fontSize: 14,
                        color: GlobalColors.textColor.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(
                  bottom: arLnag ? 30 : 30, top: 0, left: arLnag ? 0 : 15), //*
              alignment:
                  arLnag ? Alignment.centerRight : Alignment.centerLeft, //*
              child: Container(
                child: Stack(alignment: Alignment.center, children: [
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        GlobalColors.mainColorGreen,
                        GlobalColors.secondaryColorGreen,
                      ],
                      tileMode: TileMode.clamp,
                    ).createShader(bounds),
                    child: Icon(
                      Icons.file_copy,
                      size: 100,
                      color: Colors.white,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(right: 0, top: 40),
                    child: Icon(
                      Icons.check_sharp,
                      size: 55,
                      color: Colors.white,
                    ),
                  ),
                ]),
              ),
            ),
            //View confirmed page button
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Flexible(
                  flex: 1,
                  child: Container(
                    alignment: arLnag
                        ? Alignment.bottomLeft
                        : Alignment.bottomRight, // *
                    padding: EdgeInsets.only(
                        left: arLnag ? 10 : 0,
                        right: 10,
                        bottom: arLnag ? 5 : 15),
                    child: Container(
                      height: 35,
                      width: 80,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                GlobalColors.mainColorGreen,
                                GlobalColors.secondaryColorGreen
                              ]),
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(225, 4, 99, 65)
                                  .withOpacity(0.27),
                              blurRadius: 10,
                            ),
                          ]),
                      child: TextButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStatePropertyAll<Color>(
                              Colors.transparent),
                          foregroundColor: MaterialStatePropertyAll<Color>(
                              GlobalColors.secondaryColorGreen),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                          )),
                        ),
                        // on pressed it will allows the driver to view the confirmed reports page

                        onPressed: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => RootApp(
                                        pageIndex: 2,
                                      )));
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 3.0),
                              child: Text(
                                'viewButton'.tr,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: arLnag ? 15 : 18,
                                    height: 1),
                              ),
                            ), // <-- Text
                            SizedBox(
                              width: 2,
                            ),
                            Icon(
                              // <-- Icon
                              Icons.arrow_forward_ios_rounded,
                              size: 15.0,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showMyDialog(uid) {
    AwesomeDialog(
        context: context,
        btnCancelColor: Colors.grey,
        btnOkColor: GlobalColors.secondaryColorGreen,
        dialogType: DialogType.noHeader,
        animType: AnimType.scale,
        dismissOnTouchOutside: false,
        title: 'Sure'.tr,
        desc: 'confCancel'.tr,
        btnOkText: "yes".tr,
        btnCancelText: 'C'.tr,
        btnCancelOnPress: () {},
        btnOkOnPress: () {
          final docUser =
              FirebaseFirestore.instance.collection('drivers').doc(uid);
          //update specfic fields
          docUser.update({
            'dashcam_id': 'null',
            'rtsp_url': 'null',
          });
          _showSucess();
        }).show();
  }

  void _showSucess() {
    AwesomeDialog(
            context: context,
            btnCancelColor: Colors.grey,
            btnOkColor: GlobalColors.secondaryColorGreen,
            dialogType: DialogType.success,
            animType: AnimType.scale,
            headerAnimationLoop: false,
            dismissOnTouchOutside: false,
            title: 'success'.tr,
            desc: 'descrsuccess'.tr,
            btnOkText: 'Ok'.tr,
            btnOkOnPress: () {})
        .show();
  }

//##########################################bluid linking card ########################################################
  Container buildLinkingCard(Driver driver, String dashID) {
    var RTSPurl = driver.rtsp_url; //retrive the driver rtsp ling
    final uid1 = user!.uid.toString();
    return dashID !=
            'null' // dashID != 'null' : true -->  means that the driver already link his , dashID != 'null' : false -->  means that the driver has not link his dashcam yet
        ?
        //If true , display a card showing the dashcam IP along with the dashcam stream
        Container(
            child: Padding(
              padding: const EdgeInsets.only(
                  top: 0, right: 25, left: 25, bottom: 20),
              child: Container(
                width: double.infinity,
                child: Stack(
                  alignment: Alignment.bottomLeft,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(
                        // left side padding is 40% of total width
                        left: arLnag
                            ? 30
                            : MediaQuery.of(context).size.width * .35, // *
                        top: 20,
                        right: arLnag
                            ? MediaQuery.of(context).size.width * .35
                            : 30, //*
                      ),
                      height: 150,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.4),
                            spreadRadius: 2,
                            blurRadius: 20,
                            offset: Offset(0, 2), // changes position of shadow
                          ),
                        ],
                        gradient: LinearGradient(
                          colors: [Colors.white, Colors.white],
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        padding: EdgeInsets.only(top: 1),
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "DLS".tr,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline6!
                                    .copyWith(
                                        color: GlobalColors.textColor,
                                        fontSize: arLnag ? 18 : 20),
                              ),
                              //shows the current dashcam ip address
                              TextSpan(
                                text: "DLSA".tr + " " + dashID, // edit it
                                style: TextStyle(
                                  fontSize: 14,
                                  color:
                                      GlobalColors.textColor.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 5),
                      alignment:
                          arLnag ? Alignment.centerRight : Alignment.centerLeft,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          //This shows live stream of the dashcam at the moment
                          Stack(
                              alignment: AlignmentDirectional.centerStart,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(3),
                                      border: Border.all(
                                        width: 3,
                                        color: GlobalColors.secondaryColorGreen,
                                      )),
                                  height: 56.2,
                                  width: 100,
                                  child: LiveStreamScreen(
                                    url: RTSPurl,
                                    uid: uid1,
                                    recordStream: true,
                                  ),
                                ),
                              ]),
                          //button container
                          Container(
                            padding: EdgeInsets.only(
                                left: arLnag ? 0 : 10, right: arLnag ? 10 : 0),
                            child: Row(
                              children: [
                                //A button that will cancel the stream
                                Stack(
                                  alignment: AlignmentDirectional.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(left: 5),
                                      height: 25,
                                      width: 25,
                                      decoration: BoxDecoration(
                                          gradient: LinearGradient(
                                              begin: Alignment.centerLeft,
                                              end: Alignment.centerRight,
                                              colors: [
                                                GlobalColors.mainColorGreen,
                                                GlobalColors.secondaryColorGreen
                                              ]),
                                          borderRadius:
                                              BorderRadius.circular(100)),
                                    ),
                                    //button allows the driver to refresh the stream
                                    Container(
                                      width: 30,
                                      child: TextButton(
                                        onPressed: () {
                                          _showMyDialog(uid1);
                                        },
                                        child: Container(
                                          alignment: Alignment.centerLeft,
                                          padding: EdgeInsets.only(right: 10),
                                          child: Icon(
                                            Icons.close,
                                            size: 18,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Stack(
                                  alignment: AlignmentDirectional.center,
                                  children: [
                                    Container(
                                      height: 25,
                                      width: 25,
                                      decoration: BoxDecoration(
                                          gradient: LinearGradient(
                                              begin: Alignment.centerLeft,
                                              end: Alignment.centerRight,
                                              colors: [
                                                GlobalColors.mainColorGreen,
                                                GlobalColors.secondaryColorGreen
                                              ]),
                                          borderRadius:
                                              BorderRadius.circular(100)),
                                    ),
                                    //button allows the driver to refresh the stream
                                    TextButton(
                                      onPressed: () {
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) => RootApp(
                                                      pageIndex: 0,
                                                    )));
                                      },
                                      child: Icon(
                                        Icons.restart_alt_rounded,
                                        size: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      alignment: arLnag
                          ? Alignment.bottomLeft
                          : Alignment.bottomRight, // *
                      padding: EdgeInsets.only(
                          left: arLnag ? 5 : 0,
                          right: 10,
                          bottom: arLnag ? 5 : 15),
                      child: Container(
                        height: 35,
                        width: 80,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [
                                  GlobalColors.mainColorGreen,
                                  GlobalColors.secondaryColorGreen
                                ]),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(225, 4, 99, 65)
                                    .withOpacity(0.27),
                                blurRadius: 10,
                              ),
                            ]),
                        child: TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll<Color>(
                                Colors.transparent),
                            foregroundColor: MaterialStatePropertyAll<Color>(
                                GlobalColors.secondaryColorGreen),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                            )),
                          ),
                          //Button allows the driver to navigate to the edit dashcam page
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LinkPage(
                                          linked: true,
                                          uid: uid1,
                                        )));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 3.0),
                                child: Text(
                                  'editLink'.tr,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: arLnag ? 15 : 18,
                                      height: 1),
                                ),
                              ), // <-- Text
                              SizedBox(
                                width: 2,
                              ),
                              Icon(
                                // <-- Icon
                                Icons.arrow_forward_ios_rounded,
                                size: 15.0,
                                color: Colors.white,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        :
        //if false, then display a card that have a link button to allow the driver to link his/her dashcam
        Container(
            child: Padding(
              padding: const EdgeInsets.only(
                  top: 0, right: 25, left: 25, bottom: 20),
              child: Container(
                //height: 230,
                width: double.infinity,
                child: Stack(
                  alignment: Alignment.bottomLeft,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(
                        // left side padding is 40% of total width
                        left: arLnag
                            ? 30
                            : MediaQuery.of(context).size.width * .35, // *
                        top: 20,
                        right: arLnag
                            ? MediaQuery.of(context).size.width * .35
                            : 30, //*
                      ),
                      height: 150,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.4),
                            spreadRadius: 2,
                            blurRadius: 20,
                            offset: Offset(0, 2), // changes position of shadow
                          ),
                        ],
                        gradient: LinearGradient(
                          colors: [Colors.white, Colors.white],
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        padding: EdgeInsets.only(top: 10),
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "LD".tr,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline6!
                                    .copyWith(
                                        color: GlobalColors.textColor,
                                        fontSize: arLnag ? 20 : 25),
                              ),
                              TextSpan(
                                text: "LTOAPP".tr,
                                style: TextStyle(
                                  fontSize: 15,
                                  color:
                                      GlobalColors.textColor.withOpacity(0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 30),
                      alignment:
                          arLnag ? Alignment.centerRight : Alignment.centerLeft,
                      child: Stack(
                        alignment: AlignmentDirectional.center,
                        children: [
                          Container(
                            child: ShaderMask(
                              shaderCallback: (bounds) => LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  GlobalColors.mainColorGreen,
                                  GlobalColors.secondaryColorGreen,
                                ],
                                tileMode: TileMode.clamp,
                              ).createShader(bounds),
                              child: Icon(
                                Icons.linked_camera_outlined,
                                size: 90,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      alignment: arLnag
                          ? Alignment.bottomLeft
                          : Alignment.bottomRight, // *
                      padding: EdgeInsets.only(
                          left: arLnag ? 10 : 0,
                          right: 10,
                          bottom: arLnag ? 5 : 15),
                      child: Container(
                        height: 35,
                        width: 80,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [
                                  GlobalColors.mainColorGreen,
                                  GlobalColors.secondaryColorGreen
                                ]),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(225, 4, 99, 65)
                                    .withOpacity(0.27),
                                blurRadius: 10,
                              ),
                            ]),
                        //Button allows the driver to navigate to the link dashcam page
                        child: TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll<Color>(
                                Colors.transparent),
                            foregroundColor: MaterialStatePropertyAll<Color>(
                                GlobalColors.secondaryColorGreen),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                            )),
                          ),
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LinkPage(
                                          linked: false,
                                          uid: uid1,
                                        )));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 3.0),
                                child: Text(
                                  'L'.tr,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: arLnag ? 15 : 18,
                                      height: 1),
                                ),
                              ), // <-- Text
                              SizedBox(
                                width: 2,
                              ),
                              Icon(
                                // <-- Icon
                                Icons.arrow_forward_ios_rounded,
                                size: 15.0,
                                color: Colors.white,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }
}
