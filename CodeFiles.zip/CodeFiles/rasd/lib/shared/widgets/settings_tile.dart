import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rasd/shared/GlobalColors.dart';
//  a class to define a structure for the setting class
class SettingsTile extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String title;
  final bool phoneVerfied;
  SettingsTile({ // each tile will have a color, icon, title
    Key? key,
    required this.color,
    required this.icon,
    required this.title,
    required this.phoneVerfied,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) { 

    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(
            icon,
            color: GlobalColors.mainColorGreen,
          ),
        ),
        const SizedBox(width: 10),
        (!phoneVerfied) // if the number was not verified then display the verify icon in red
            ? ((icon.toString() == "IconData(U+0EDA3)")
                ? Wrap(
                    direction: Axis.vertical, //default
                    alignment: WrapAlignment.end,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                            fontSize: 18, color: GlobalColors.mainColorGreen),
                      ),
                      Text(
                        "PhoneVerfiy".tr,
                        style: TextStyle(
                            fontSize: 10, color: GlobalColors.mainColorRed),
                      )
                    ],
                  )
                : Text(
                    title,
                    style: TextStyle(
                        fontSize: 18, color: GlobalColors.mainColorGreen),
                  ))
            : Text(
                title,
                style:
                    TextStyle(fontSize: 18, color: GlobalColors.mainColorGreen),
              ),
        const Spacer(),
        InkWell(
          child: Container(
              width: 50,
              height: 50,
              child: Icon(Icons.arrow_forward_ios_rounded, // a foroowrd arrow to navigate to the other pages
                  color: GlobalColors.mainColorGreen)),
        ),
      ],
    );
  }
}
