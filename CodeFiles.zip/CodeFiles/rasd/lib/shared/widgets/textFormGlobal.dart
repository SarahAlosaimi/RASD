import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rasd/shared/GlobalColors.dart';
import 'package:regexed_validator/regexed_validator.dart';

//this is a widget for text input
class TextFormGlobal extends StatelessWidget {
  const TextFormGlobal({
    Key? key,
    required this.controller,
    required this.text,
    required this.textInputType,
    required this.obsecure,
    required this.isLogin,
    this.passController,
    this.linkFontText = 16,
  }) : super(key: key);
  final TextEditingController controller; //the text controller
  final TextEditingController? passController; //the password controller
  final String text; //the hint text
  final TextInputType
      textInputType; //The type of information for which to optimize the text input control.
  final bool obsecure; //if the input is a password, hide it
  final bool isLogin; //if the text input coming from the logIn form
  final double?
      linkFontText; //the font size of the inputs coming from the [linkDashCam] page

  //this method is to validate email, returns true if the email is valid
  bool validateEmail(value) {
    bool emailValid = RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$")
        .hasMatch(value); //emails reguler expression
    if (emailValid == true) {
      return true;
    } else {
      return false;
    }
  }

  //this method is to validate password, returns true if the password is valid
  bool validatePassword(value) {
    bool passwordValid = RegExp(
            r"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[.!@#\$&**~_|\\/-]).{8,}$")
        //The password must include at least one Capital One capital letter, one small letter, a number and a special character, and must be at least of 8 characters.
        .hasMatch(value);
    if (passwordValid == true) {
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool arLnag = "enterDIP".tr == 'Enter your dashcam IP'
        ? false
        : true; // determind which langanuage is displayed now , false -- > en , true ---> arabic
    final bool arLnag2 = "email".tr == 'Email'
        ? false
        : true; // determind which langanuage is displayed now , false -- > en , true ---> arabic
    return Stack(
      children: [
        Container(
            height: 50,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                  ),
                ])),
        Container(
          //this container containt the TextFormField widget
          padding: const EdgeInsets.only(top: 3, left: 15),
          child: TextFormField(
            autovalidateMode: AutovalidateMode.onUserInteraction,
            validator: (val) {
              if (text == 'email'.tr) {
                //if the input is email
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterE'.tr; //return the error message
                } else if (!validateEmail(val)) {
                  //if input does is not vaild
                  return 'invalidE'.tr; //return the error message
                }
              } else if (text == 'pass'.tr && isLogin) {
                //if the input is password and in log in page
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterPass'.tr; //return the error message
                }
              } else if (text == 'FN'.tr) {
                //if the input is first name
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterFN0'.tr; //return the error message
                } else {
                  if (!RegExp(r"^[\u0621-\u064A ]+$").hasMatch(val) &&
                      (!RegExp(r"^[a-zA-Z ]+$").hasMatch(val))) {
                    //if input does is not vaild
                    if (arLnag2 == true) {
                      //If the page is currently displayed in Arabic
                      return 'FLValidation'.tr + ""; //return the error message
                    } else {
                      return 'FLValidation'.tr; //return the error message
                    }
                  }
                }
              } //fname

              else if (text == 'LN'.tr) {
                //if the input is last name
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterLN0'.tr; //return the error message
                } else {
                  if (!RegExp(r"^[\u0621-\u064A ]+$").hasMatch(val) &&
                      (!RegExp(r"^[a-zA-Z ]+$").hasMatch(val))) {
                    //if input does is not vaild
                    if (arLnag2 == true) {
                      //If the page is currently displayed in Arabic
                      return 'FLValidation'.tr; //return the error message
                    } else {
                      return 'FLValidation'.tr; //return the error message
                    }
                  }
                }
              } else if (text == 'pass'.tr && !isLogin) {
                //if the input is password and in sign up page
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterPass'.tr; //return the error message
                } else if (!validatePassword(val)) {
                  //if input does is not vaild
                  return '8charactersValidation'.tr; //return the error message
                }
              } else if (text == 'confPass'.tr && !isLogin) {
                //if the input is confirm password and in sign up page
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterPass'.tr; //return the error message
                } else if (val != passController!.text) {
                  //if input does is not vaild
                  return 'noMatchPass'.tr; //return the error message
                }
              } else if (text == 'enterDIP'.tr) {
                //if the input is IP
                if (val!.isEmpty) {
                  //if input is empty
                  return 'enterDIP'.tr; //return the error message
                } else if (!validator.ip(val)) {
                  //if input does is not vaild
                  return 'ipForm'.tr; //return the error message
                }
              } else if (text == 'PassDCEntrence'.tr) {
                //if input is Dashcam password
                if (val!.isEmpty) {
                  //if input is empty
                  return 'PassDCEntrence'.tr; //return the error message
                }
              } else if (text == 'UserNameDCEntrence'.tr) {
                //if input is Dashcam username
                if (val!.isEmpty) {
                  //if input is empty
                  return 'UserNameDCEntrence'.tr; //return the error message
                }
              }
            },
            controller: controller,
            keyboardType: textInputType,
            obscureText: obsecure,
            cursorColor: GlobalColors.mainColorGreen,
            decoration: InputDecoration(
                errorStyle: TextStyle(
                    color: GlobalColors.mainColorRed,
                    fontSize: isLogin ? 15.0 : 15.0),
                hintText: text,
                border: InputBorder.none,
                contentPadding: arLnag || arLnag2
                    ? const EdgeInsets.only(right: 10)
                    : const EdgeInsets.all(0),
                hintStyle: TextStyle(
                  fontSize: linkFontText,
                  height: 1,
                )),
          ),
        ),
      ],
    );
  }
}
