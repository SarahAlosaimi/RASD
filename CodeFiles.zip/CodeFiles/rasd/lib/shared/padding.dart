//###################################################Padding Defention###################################################//
//Here we defined some of the general spacing paddings we need and it has been used in some other class ehere they were needed

const double appPadding = 25.0;
const double spacer = 50.0;
const double smallSpacer = 30.0;
const double miniSpacer = 10.0;
