import 'package:get/get.dart';

//###################################################The local String is a class where all of the translated tesxt that appears in the interface is defined here###################################################//

class LocalString extends Translations {
  //Transloation is used for internationalizing the application pages.

  // a map of Strings keys and values
  //the key can hold the English text and the Arabic text (2 values for each Text)
  //This class is needed to be imported in every other class
  @override
  Map<String, Map<String, String>> get keys => {
        'en_US': {
          //global
          'signout': 'Sign Out',
          'Sure': 'Are you sure?',

          //Homepgae
          'greeting': 'Welcome To Rasd',
          'LD': 'Link Dashcam\n',
          'LDA': 'Link your dashcam to our application',
          'L': 'Link',
          'pendVid': 'Violation Videos\n',
          'noPending': 'Currently there are no pending videos\n',
          'pendVidNum1': 'You have ',
          'pendVidNum2singular': ' pending video\nthat needs to be confirmed',
          'pendVidNum2': ' pending videos\nthat needs to be confirmed',
          'viewButton': 'View',
          'DLS': 'Dashcam Linked Successfully\n',
          'DLSA': 'The IP address of the linked dashcam:\n',
          'ConfRep': 'Confirmed Reports\n',
          'noConfirmed': 'Currently there are no confirmed reports',
          'confRepNum1': 'Number of confirmed reports:',
          'editLink': 'Edit',
          'Insufficientstorage': 'Insufficient storage',
          'InsufficientstorageMessage':
              'This device doesn\'t have enough space to upload video streams coming from the dashcam.',
          'NeedHelp': 'Need Help?',
          'NeedToBeConfirmed': 'These videos needs to be confirmed',
          'confCancel':
              'Are you sure you want to disconnect the daschcem?\nthis action will force disconnecting and you will have to re link the dashcam all over again',
          'descrsuccess': 'Your dashcam have been disconnected successfully',

          //settings_screen page
          'sitt': 'Settings',
          'acc': 'My Account',
          'PP': 'Privacy Policy',
          'RASDPP': 'RASD Privacy Policy',
          'contact': 'Contact Us',
          'Plang': 'Preferred Language',
          'change': 'Change',
          'choosePr': 'Choose your language preferences',
          'lang': 'English',
          'AreUSure': "Are you sure you want to sign out?",
          'PhoneVerfiy': "Verify your phone number",
          'UpdateInfoInstruction':
              'These are your information,\nTap on the field to edit.',

          //phone verfication
          'VerifyButtom': 'Verify',
          'ResendOTP': 'Resend OTP',
          'PhoneVerification': 'Phone Verification',
          'EnterOTP': 'Enter OTP sent to ',
          'noOTP?': 'Didn\'t receive the OTP?',
          'OTPInccorent': 'The OTP is incorrect',
          'credential-already-in-use': 'This phone number has been used before',
          'VerfiedeMess': 'Your phone number has been verified',
          'ResendSec': " in ",

          //showVideo page
          'showVideoHead': 'Violation Video',
          // 'viloation1': 'Tailgating',
          'viloation2': 'Overtaking',
          'viloation3': 'Drifting',
          'viloation1': 'Driving in the opposite direction',
          'confViolation':
              'Are you sure you want to confirm the detected violation?',
          'yes': 'Yes',
          'no': 'No',
          'conf': 'The violation has been confirmed!',
          'delViolation':
              'Are you sure you want to delete the detected violation?\nThis action cannot be undone',
          'delReasonTitle': 'Why?',
          'delReasonQ': 'Why you want to delete this violation?',
          'delReason1': 'Misclassified\nViolation',
          'delReason2': 'Not intrested\nin reporting',
          'delConfirmation': 'The violation has been deleted successfully!',
          '  confButton  ': 'Confirm',
          '  delButton  ': 'Delete',
          'isViolation':
              'Potential violation/s were detected in the video above, Do you agree?',
          'violationType': 'Violation Type',
          'Other': 'Other',
          'addInfo': 'Additional Information',
          'optinalAddInfo': '(Optional)',
          'SelecVTypeTitle': 'Select The Violation Type',
          'SelectVTypeDis':
              'You must select a violation type, if the violation type is not provided you can select \"other\".',
          'pause/play': 'Tap on the screen to play and pause the video',

          // pending videos
          'moreText': 'more space for text',
          'PVV': 'Pending Violation Videos',
          'Watch': 'Watch each video to confirm the violation',
          'Select': '\nand select the violation type',
          'VV': 'Violation Video',
          'NPV': 'No Pending Videos',
          'NPVA':
              'Looks like you don\'t have any pending videos at this moment',
          'celCountV': 'The video will be deleted after ',
          'days': 'days',
          'day': 'day',

          //confirmed reports
          'CVR': 'Confirmed Violation Reports',
          'Send': 'Share your confirmed report\nwith the authorities via email',
          'VR': 'Violation Report',
          'NVR': 'No Violation Reports',
          'NVRA':
              'Looks like you don\'t have any violation reports at this moment',
          'NotSelected': 'No violation type selected',
          'celCountR': 'The report will be deleted after ',
          'verfPhoneNumberDialog': 'Verify Your Phone Number',
          'verfPhoneNumbertoShare':
              'To be able to share the violation with the authorities you have to verify your phone number first.',
          'Violationdate': 'Violation date: ',

          //editFile page
          'successEditing': 'Your report information has been updated!',
          'confEdit': 'Are you sure you want to update the report information?',
          'EditReportHead': 'Edit confirmed report',

          //link page
          'LTOAPP': 'Link your dashcam to our application',
          'IP': 'Enter your dashcam IP',
          'Link': 'Link',
          'How': 'How do I get my IP address?',
          'How2': 'How do I get these information?',
          'Undo': 'Once you link your dashcam, you cannot edit the IP.',
          'Sure': 'Are you sure?',
          'C': 'Cancel',
          'descSucess': 'Your dashcam has been linked successfully!',
          'descS': 'Your dashcam has been linked successfully!',
          'errorLink': 'Please complete your information',
          'S': 'Success',
          'Ok': 'Ok',
          'E': 'Error',
          'DashCamtoolTip':
              'You can find your dashcam IP in your dashcam settings.',
          'editDashCam': 'Edit your dashcam IP ',
          'linkDashCamTitle': 'Link your Dashcam',
          'editMess': 'Are you sure you want to update the IP?',
          'linkMess': 'Are you sure you want to link the entered IP?',
          'IPonly': 'IP only',
          'UPIPReq': 'IP, username, and \npassword required',
          'RTSPques':
              'What type of information is associated with your dashcam?',

          'FindIP': 'To Find your dashcam IP address:\n',

          'FirstIPInstruction':
              '1. Trun on your Cellurar Data from your phone\'s settings and keep it on while you are using RASD application.',

          'SecondIPInstruction':
              '2. You need to turn on your dashcam\'s Wi-Fi hotspot and connect to it, you can find the default password of the Wi-Fi in your dashcam user manual.',

          'ThirdIPInstruction':
              '3. Click on the the name of your dashcam Wi-Fi.\nA dialog with the Wi-Fi network information will appear, the shown link in the Manage Router section containes your dashcam\'s IP address. ',
          'StreamShowingConf': 'Can you see the stream?',
          'UserNameDCEntrence': 'Enter your dashcam Username',
          'PassDCEntrence': 'Enter your dashcam Password',
          'linkError':
              'An error occurred while retrieving dashcam streams. \nMake sure your internet connection is stable and your information is correct.',
          'whatInfo': 'What information do you want to get?',
          'U/P': 'username,\npassword',
          'IPadd': 'IP address',
          'firstInst':
              '1. Open your dashcam application, then click on your profile, then go to settings',
          'secInst':
              '2. Before clicking on \'start scanning\', make sure that your mobile phone and device are connected to the same network',
          'thirdInst':
              '3.You will see a list of cameras and their IPs. choose the IP of the camera that you want to link to RASD',
          'Exit': 'Exit',
          'Return': 'Return',
          'findU/P': 'To find your username and password:',
          'DCusername': '1. The default user name is ‘admin’',
          'DCpass':
              '2. The password is the Verification Code printed on the device label',
          'allowbackground':
              'To ensure that the videos are being recorded\nin the background, make sure to click on allow on the next dialog',
          'perfectView':
              'Note that this is the perfect view in order to detect the violations,\n A cntred dashcam on the windscreen.',

          //app root
          'Home': '\nHome',
          'PV': "Pending\n Videos",
          'CR': "\nConfirmed\n   Reports",
          'More': '\n Settings',

          //log in register //changes//
          'passIsNotCorrect':
              'The password is invalid, or the user does not have am account.',
          'EmailPassError': 'The email or password you entered is incorrect',
          'infoCompletionError': 'Please complete your information',
          'logIn': 'Log in',
          'logIn2': 'Log in',
          'signUp': 'Sign Up',
          'forogtPass': 'Forget Password?',
          'creatAcc': 'Create Your Account',
          'FN': 'First Name',
          'LN': 'Last Name',
          'email': 'Email',
          'pass': 'Password',
          'confPass': 'Confirm Password',
          'noAcc': 'Don\'t have an account?',
          'alradyAcc': 'Already have an account?',
          'logToAcc': 'Log in to your Account',
          'noAccountError':
              'There is no user record corresponding to this identifier. The user may have been deleted.',
          'Agreemnt1': 'I have read and agree to ',
          'Agreemnt2': 'RASD Privacy Policy.',
          'okButton': 'OK',
          'demandPolicy': "You have to agree on RASD privacy policy",
          'AccountExist':
              'The email address is already in use by another account.',
          'networkError':
              'A network error has occurred!\nPlease check your internet connection',
          'InvalidPhone': 'Number must begin with 5\nand consist of 9 digits',

          //textFormGlobal    //* changes//*
          'enterE': 'Enter your Email',
          'invalidE':
              'Invalid email address, please follow this\nformat: example@example.com',
          'invalidE3':
              'Invalid email address, please follow\nthis format: example@example.com',
          'enterPass': 'Enter your Password',
          'enterFN': 'Enter your First Name',
          'enterLN': 'Enter your Last Name',
          'enterFN0': 'Enter your First\nName',
          'enterLN0': 'Enter your Last\nName',
          'noMatchPass': 'The passwords you entered does not match',
          'enterDIP': 'Enter your dashcam IP',
          'ipForm':
              'The IP must be in form of\n(000.000.000.000) \nwhere 0 is any digit from 0 to 9\nand 000 should not exceeds 255',
          '8charactersValidation':
              'Passowrd must be more than 8 characters\n and contain at least: one upper letter, \none lower letter, one number, and \none symbol',
          'FLValidation': 'Digits and symbols\nare not allowed',

          //verfiyEmail
          'resendE': 'Resend Email',
          'verfE': 'A verification email has been sent to your email',
          'checkSpam':
              'Make sure to check your spam folder if you did not find it in your inbox',
          'cancel': 'Cancel',

          //forgotpass
          'resetPass': 'Reset Password',
          'resetPassE':
              'Password reset email has been sent to your email\nMake sure to check your spam folder if you did not find it in your inbox',
          'assocE':
              'Enter the email associated with your account, and we will send you a password reset link',

          // pdf report
          'vr': '  Violation Report',
          'ViolationRep': 'Violation Report',
          'des':
              '  This report was issued by RASD system, which uses \n  Artifical Intellgence to detect violations in \n  Saudi Arabia and generate reports.',
          'name': 'Name',
          'email': 'Email',
          'phoneVer': '\n   Not Verified',

          'link': 'Violation Video Link',
          'viotype': 'Violation Type',
          'Preview': 'Preview',
          'delConfreport':
              'Are you sure you want to delete the violation report?\nThis action cannot be undone',
          'Rdelete': 'The report has been deleted successfully!',
          'VTime': 'Violation Time',

          //email
          'subject': 'Traffic Violation Report',
          'body':
              'Hello,\nThis email was sent by a driver in Saudi Arabia through RASD application. A detailed report of the detected violation is attached to this email.\n\n\nBest regards,\nRASD team.',
          'filename': 'Traffic Violation Report Issued By RASD',

          // privacy page
          'RPP': 'RASD PRIVACY POLICY',
          'it1': 'ITEM ONE: INTRODUCTION',
          'it1text':
              'From the principle of the importance and confidentiality of users\' data, RASD administration is committed to maintaining the confidentiality and privacy of user information, and the materials entered by them as a basis for the privacy policy, \nRASD administration will not disclose that information except in accordance with the specific and stipulated controls in this policy, and in accordance with the regulatory provisions issued in this regard.',
          'it2': 'ITEM TWO: USER INFORMATION',
          'it2text':
              'User Data and Information indicates all User’s Data contained in the application such as:\n\n- The personal data used for registration.\n- The dashcam information to detect traffic violations.\n- The violation reports.',
          'it3': 'ITEM THREE: COLLECTING AND STORING INFORMATION',
          'it3text':
              'Collecting information in RASD is done by the informations entered from the user and the dashcam to detect traffic violations and then store it in the server specified by the application. ',
          'it4': 'ITEM FOUR:  DATA SHARING',
          'it4text':
              'The user data used, such as traffic violation video links to enhance the model in detecting traffic violations and share the reports with the authorities. ',
          'it5': 'ITEM FIVE: DISCLAIMER',
          'it5text':
              'RASD disclaim the responsibility for sharing or using the violation video, violation report, and any other informatin provided by the application except sharing it with the authorities. \nThe user is responsible for all the validity of the data entered, and bears the responsibility in case of violation of this.',
          'it6': 'ITEM SIX: APPLICATION ADMINSTRATION',
          'it6text':
              'Name of the entity supervising the application: King Saud University,\nCollege of Computer and Information Sciences,\nInformation Technology Department.',

          // account
          'acc': 'My Account',
          'fname': 'First Name',
          'lname': 'Last Name',
          'em': 'Email',
          'PhoneNum': 'Phone Number',
          'NotVer': 'Verifiy',
          'Ver': 'Verified',
          'DuplicateNumErrMessage': 'You can\'t enter the same phone number',
          'oldE': 'Old Email',
          'enterEOld': 'Enter your old Email',
          'update': 'Update',
          'changeE': 'To update your email enter your old email and password:',
          'FLValidation1': 'Digits and symbols are not allowed',
          'save': 'Save',
          'updateMess': 'Your information has been updated!',
          'AreUSureToSave':
              'Are you sure you want to update and save your information? ',
          'empty': 'This field is empty, it will not be updated',
        },
        //Arabic
        'ar_AE': {
          //global
          'signout': 'تسجيل الخروج',
          'Sure': "هل انت متأكد ؟ ",

          //Homepgae
          'greeting': 'مرحبًا بك في رصد',
          'LD': 'ربط الداش كام\n',
          'LDA': 'قم بربط وتوصيل كاميرتك الداش كام بتطبيقنا',
          'L': 'اربط',
          'pendVid': 'مقاطع المخالفات\n',
          'noPending': 'لا يوجد لديك اي مقاطع مخالفات تحت المراجعة',
          'pendVidNum1': 'لديك ',
          'pendVidNum2singular': 'مقطع مخالفة قيد المراجعة\n',
          'pendVidNum2': 'مقاطع مخالفات قيد المراجعة\n',
          'viewButton': 'معاينة',
          'DLS': 'تم ربط كاميرا الداش كام بنجاح\n',
          'DLSA': 'الـIP الخاص بالداش كام :',
          'ConfRep': 'تقارير مؤكدة\n',
          'noConfirmed': 'لا يوجد لديك تقارير مؤكده',
          'confRepNum1': 'عدد التقارير المؤكده: ',
          'editLink': 'تعديل',
          'Insufficientstorage': 'مساحة تخزين غير كافية',
          'InsufficientstorageMessage':
              'لا يحتوي الجهاز على مساحة تخزين كافية لتحميل المقاطع القادمة من الداش كام.',
          'NeedHelp': 'تحتاج إلى مساعدة؟',
          'NeedToBeConfirmed': 'هذه المقاطع تحتاج إلى تأكيد',
          'confCancel':
              'هل أنت متأكد من رغبتك في فصل الداش كام؟\nسيؤدي هذا الإجراء إلى فصل الداش كام، وسيتعين عليك إعادة ربط الداش كام من جديد',
          'descrsuccess': 'تم فصل الداش كام بنجاح',

          //settings_screen page
          'sitt': 'الإعدادات',
          'acc': 'حسابي',
          'PP': 'سياسة الخصوصية',
          'RASDPP': 'سياسة الخصوصية لرصد',
          'contact': 'تواصل معنا',
          'Plang': 'اللغة المفضلة',
          'change': 'تغيير',
          'choosePr': 'اختر لغتك المفضلة ',
          'lang': 'العربية',
          'AreUSure': 'هل أنت متأكد من تسجيل الخروج ؟ ',
          'PhoneVerfiy': 'وثّق رقم هاتفك ',
          'UpdateInfoInstruction':
              'هذه هي معلوماتك،\nاضغط على الخانات لتحديثها',

          //phone verfication
          'VerifyButtom': 'توثيق',
          'ResendOTP': 'اعادة إرسال الرمز السري',
          'ResendSec': ' خلال ',
          'PhoneVerification': 'توثيق رقم الجوال',
          'EnterOTP': '  ادخل الرقم السري المُرسل إلى  ',
          'noOTP?': 'لم يصلك الرمز؟',
          'OTPInccorent': 'الرمز المدخل غير صحيح',
          'credential-already-in-use': 'رقم الجوال المدخل قيد الاستخدام من قبل',
          'VerfiedeMess': 'تم توثيق رقم الجوال بنجاح',

          //showVideo page
          'showVideoHead': 'مقطع المخالفة',
          // 'viloation1': 'عدم ترك مسافة آمنة',
          'viloation2': 'التجاوز',
          'viloation3': 'التفحيط',
          'viloation1': 'عكس الطريق',
          'confViolation': 'هل أنت متأكد من رغبتك في تأكيد المخالفة المضبوطة؟',
          'yes': 'نعم',
          'no': 'لا',
          'conf': 'تم تأكيد المخالفة!',
          'delViolation':
              'هذه العملية غير قابلة للتراجع\nهل أنت متأكد من رغبتك في حذف المخالفة المرصودة؟',
          'delReasonTitle': 'لماذا؟',
          'delReasonQ': 'لماذا تريد حذف هذه المخالفة؟',
          'delReason1': 'مخالفة مصنفة تصنيف خاطئ',
          'delReason2': 'لست مهتمًا بالتبليغ',
          'delConfirmation': '!تم حذف المقطع بنجاح',
          '  confButton  ': 'تأكيد',
          '  delButton  ': 'حذف',
          'success': 'عملية ناجحة',
          'isViolation': 'تم رصد مخالفات في المقطع أعلاه، هل تراها صحيحة؟',
          'violationType': 'نوع المخالفة',
          'Other': 'غير ذلك',
          'addInfo': 'معلومات إضافية',
          'optinalAddInfo': '(إختياري)',
          'EditReportHead': 'تعديل التقرير',
          'SelecVTypeTitle': 'اختر نوع المخالفة',
          'SelectVTypeDis':
              'يجب عليك اختيار نوع المخالفة و إن كنت لا تعلم ماهو نوعها اختر "غير ذلك"',
          'pause/play': 'إضغط على الشاشة لتشغيل الفيديو و إيقافه',

          //   pending videos
          'moreText': 'مساحة إضافية لكتابة نص',
          'PVV': 'مقاطع قيد المراجعة',
          'Watch': 'شاهد كل مقطع لتأكيده',
          'Select': ' واختر نوع المخالفة',
          'VV': 'مقطع مخالفة ',
          'NPV': 'لا يوجد مقاطع مخالفات',
          'NPVA': 'يبدو أنه لا يوجد لديك مقاطع مخالفات حاليًا',
          'celCountV': 'هذا المقطع ستتم إزالته بعد  ',
          'days': 'يوم',
          'day': 'يوم',

          // //confirmed reports
          'CVR': 'تقارير مخالفات مؤكده',
          'Send':
              ' شارك تقاريرك المؤكدة مع الجهات المعنية عن طريق البريد الإلكتروني',
          'VR': 'تقرير المخالفة ',
          'NVR': 'لا يوجد تقارير مخالفات',
          'NVRA': 'يبدو أنه ليس لديك تقارير مخالفات حاليًا',
          'NotSelected': 'لم يتم تحديد نوع المخالفة',
          'celCountR': 'هذا التقرير ستتم إزالته بعد  ',
          'Violationdate': 'تاريخ المخالفة: ',

          // Edit file
          'successEditing': 'تم تحديث معلومات التقرير بنجاح',
          'confEdit': 'هل انت متأكد من حفظ التغييرات المدخلة',
          'EditReportHead': 'تعديل معلومات التقرير',
          'verfPhoneNumberDialog': 'وثّق رقم هاتفك',
          'verfPhoneNumbertoShare':
              "لمشاركة تقرير المخالفة مع الجهات المختصة عليك بتوثيق رقم هاتفك.",
          // //link page
          'LTOAPP': 'اربط الداش الخاصة بك بتطبيقنا ',
          'IP': 'أدخل رمز الـ IP الخاص بكاميرا الداش كام', //
          'Link': 'ربط',
          'How': 'كيف أحصل على IP ؟',
          'How2': 'كيف أحصل على هذه المعلومات؟',
          'editMess':
              'هل أنت متأكد من حفظ التغييرات المدخله الخاصة بالـIP ؟ ', //*
          'linkMess': 'هل أنت متأكد من الـ IP المدخل ؟ ', // *
          'C': 'إلغاء',
          'S': 'تمت العملية بنجاح',
          'descSucess': 'تمت عملية ربط كاميراتك الداش كام بتطبيقنا بنجاح ',
          'descS': 'تمت عملية ربط كاميراتك الداش كام بتطبيقنا بنجاح ',
          'Ok': 'حسنًا',
          'E': 'خطأ',
          'DashCamtoolTip': 'يمكنك إيجاد الـ IP في إعدادات الداش كام الخاصة بك',
          'editDashCam': 'حدّث معلومات الداش كام',
          'linkDashCamTitle': 'اربط الداش كام',
          'RTSPques': 'ما نوع المعلومات المرتبطة بكاميرا الداش كام الخاصة بك؟',

          'IPonly': 'الـ IP فقط',
          'UPIPReq': 'الـ IP و اسم المستخدم\n وكلمة المرور مطلوبة',

          'FindIP': 'للحصول على عنوان الـ IP الخاص بكاميرتك. ',

          'FirstIPInstruction':
              '1. قم بتشغيل البيانات الخلوية من إعدادات هاتفك ولا تُطفئها خلال استعمالك لتطبيق رَصْد. ',

          'SecondIPInstruction':
              '2. يجب عليك تشغيل الـ Wi-Fi الخاص بكاميرتك والإتصال بها ، باستطاعتك إيجاد كلمة المرور الإفتراضية في دليل المستخدم الخاص بكاميرتك.',

          'ThirdIPInstruction':
              '3. إضغط على اسم الشبكة الخاصة بالداش كام، سيظهر لك مربع حوار بالمعلومات الخاصة بالشبكة\n الرابط الظاهر في تحت خانة إدارة الموجّه يحتوي على عنوان الـ IP الخاص بكاميرتك',
          'StreamShowingConf': 'هل تستطيع مشاهدة بث الكاميرا؟',
          'UserNameDCEntrence': 'ادخل اسم المستخدم الخاص بالداش كام',
          'PassDCEntrence': 'ادخل كلمة المرور الخاصة بالداش كام',
          'linkError':
              'حدث خطأ أثناء استرداد بث الفيديو من الداش كام، يرجى التحقق من اتصالك بالانترنت وصحة المعلومات المدخلة',
          'whatInfo': 'ما هي المعلومات التي تريد الحصول عليها؟',
          'U/P': 'اسم المستخدم\nكلمة المرور',
          'IPadd': 'عنوان الـ IP',
          'firstInst':
              '1. في تطبيق الكاميرا الخاص بك، ادخل على حسابك الشخصي، ثم اذهب إلى الإعدادات',
          'secInst':
              '2. قبل الضغط على ‘بدء المسح‘، تأكد من أن هاتفك المحمول وجهازك متصلان بنفس الشبكة',
          'thirdInst':
              '3. من قائمة الكاميرات والـ IPs المرتبطة بها، اختر الـ IP المصاحب لكاميرا الداش الكام التي تريد ربطها برَصْد',
          'Exit': 'خروج',
          'Return': 'رجوع',
          'findU/P':
              'للحصول على اسم المستخدم وكلمة المرور الخاصة بكاميرتك الداش كام:',
          'DCusername': '1. اسم المستخدم الافتراضي هو  ‘admin’',
          'DCpass': '2. كلمة المرور هي رمز التحقق المطبوع على ملصق الجهاز',
          'allowbackground':
              "لاستمرار عملية تسجيل مقاطع الداش كام في الخلفية، تأكد من الضغط على زر السماح في النافذة التالية",
          'LetAppRunBackgrnd': 'السماح لتطبيق رَصْد بالعمل في الخلفية ',
          'perfectView':
              'ننوّه على أنه هذه هي الرؤية المثالية لرصد المخالفات،\n يجب أن تتوسط كاميرة الداش كام الزجاج الأمامي.',

          //log in register
          'passIsNotCorrect':
              'كلمة المرور غير صالحة أو ليس لهذا المستخدم كلمة مرور ',
          'EmailPassError':
              'البريد الإلكتروني المدخل أو كلمة المرور المدخلة غير صحيحة',
          'infoCompletionError': 'رجاءً، أكمل إدخال معلوماتك',
          'logIn': 'تسجيل الدخول',
          'register': 'التسجيل',
          'logIn2': 'تسجيل الدخول',
          'signUp': 'إنشاء حساب',
          'forogtPass': 'نسيت كلمة المرور؟',
          'creatAcc': 'أنشئ حسابك',
          'FN': 'الاسم الأول',
          'LN': 'الاسم الأخير',
          'email': 'البريد الإلكتروني',
          'pass': 'كلمة المرور',
          'confPass': 'تأكيد كلمة المرور',
          'noAcc': 'ليس لديك حساب؟',
          'logToAcc': 'سجل الدخول لحسابك',
          'noAccountError':
              'لا يوجد حساب مسجل للعنوان الإلكتروني البريدي المدخل',
          'Agreemnt1': 'لقد قرأت و أوافق على ',
          'Agreemnt2': 'سياسة الخصوصية الخاصة برَصْد',
          'okButton': 'حسنًا',
          'alradyAcc': 'لديك حساب من قبل؟',
          'demandPolicy': "يجب عليك الموافقة على سياسة خصوصية رصد",
          'AccountExist':
              'عنوان البريد الإلكتروني قيد الاستخدام بالفعل من قبل حساب آخر.',
          'networkError':
              'حدث خطأ في الشبكة!\nالرجاء التحقق من اتصال الانترنت الخاص بك',

          'InvalidPhone':
              'يجب أن يبدأ رقم الهاتف بـ 5\n      وأن يكون من تسع أرقام',

          //textFormGlobal    //* changes //*
          'ipForm':
              'رمز الـ IP لا بد أن يكون بالصيغة التالية\n (000.000.000.000)\n حيث ان 0 يمثل أي عدد من 0 الى 9\n و الـ 000 يجب ان لاتتجاوز 255',
          'enterDIP': 'أدخل رمز الـ IP الخاص بكاميرا الداش كام',
          'noMatchPass': 'كلمتا المرور التي أدخلتهما لا تتطابقان ',
          'enterLN': 'أدخل اسمك الأخير',
          'enterFN': 'أدخل اسمك الأول',
          'enterFN0': 'ادخل اسمك\nالأول',
          'enterLN0': 'ادخل اسمك\nالأخير ',
          'enterPass': 'أدخل كلمة المرور',
          'invalidE':
              ' عنوان البريد الإلكتروني غير صالح،\n رجاءً اتبع الصيغة التالية : \nexample@example.com',
          'enterE': 'أدخل بريدك الإلكتروني',
          '8charactersValidation':
              'يجب أن تحتوي كلمة المرور على ٨ خانات\n تتضمن أحرف كبيرة وأحرف صغيرة و أرقام\n ورموز',
          'FLValidation': 'يسمح لك بإدخال\n أحرف فقط ',

          //verfiyEmail
          'cancel': 'إلغاء',
          'checkSpam':
              'في حال لم تصلك الرسالة في البريد الالكتروني، تأكد من مراجعة مجلد الرسائل غير المرغوب فيها',
          'verfE': 'تم إرسال رسالة التأكيد إلى عنوان بريدك الإلكتروني',
          'resendE': 'إعادة إرسال البريد الإلكتروني',

          //forgotpass
          'assocE':
              'أدخل البريد الإلكتروني المرتبط بحسابك و سيتم إرسال رابط إعادة ضبط كلمة المرور',
          'resetPassE':
              'تم إرسال رسالة إعادة ضبط كلمة المرور\nفي حال لم تصلك الرسالة في البريد الالكتروني، تأكد من مراجعة مجلد الرسائل غير المرغوب فيها',
          'resetPass': 'إعادة ضبط كلمة المرور',

          //app root
          'Home': '\nالرئيسية',
          'PV': "مقاطع قيد المراجعة",
          'CR': "\nتقارير المخالفات المؤكدة",
          'More': '\nالإعدادات',

          // pdf report
          'vr': 'تقرير المخالفة',
          'ViolationRep': 'تقرير المخالفة',
          'des':
              'هذه المخالفة تم اصدارها من قبل  تطبيق رصد اللذي يستخدم الذكاء الإصطناعي لرصد المخالفات المرورية في المملكة العربية السعودية.',
          'name': 'الإسم',
          'email': 'البريد الإلكتروني',
          'phoneVer': '\nغير موثّق',
          'link': 'رابط المخالفة',
          'viotype': ' نوع المخالفة',
          'VTime': 'وقت المخالفة',
          'Preview': 'عرض',
          'delConfreport':
              'هل أنت متأكد من رغبتك بحذف تقرير المخالفة ؟ \n هذه العملية غير قابلة للتراجع ',
          'Rdelete': 'تم حذف التقرير بنجاح!',

          //email
          'subject': 'تقرير مخالفة مرورية',
          'body':
              'مرحبًا,\nهذا الايميل مرسل عن طريق سائق في المملكة العربية السعودية من خلال تطبيق رَصْد. مرفق لكم تقرير مفصل للمخالفة مرورية المرصودة.\n\n\nشكرًا لكم،\nفريق رَصْد ',
          'filename': 'تقرير مخالفة مرورية مصدر من رَصْد',

          // privacy page
          'RPP': 'سياسية خصوصيةرصد',
          'it1': 'البند الأول: مقدمة',
          'it1text':
              ' من مبدأ أهمية البيانات وسريتها ، وحرصًا من رصد على الالتزام بسرية وخصوصية معلومات المستخدم ، فإن إدارة رصد ملتزمة بالحفاظ على سرية وخصوصية معلومات المستخدم ، والمواد المدخلة من قبله كأساس لسياسة الخصوصية، ولن تقوم إدارة رصد بالإفصاح عن تلك المعلومات إلا وفقًا للضوابط المحددة ، والمنصوص عليها في هذه السياسية ،ووفق الأحكام النظامية الصادرة بهذا الشأن.',
          'it2': ' البند الثاني: معلومات المستخدم',
          'it2text':
              'يقصد ببيانات ومعلومات المستخدم كافة بيانات المستخدم الموجودة في التطبيق ومن ذلك:\n\n- البيانات الشخصية المستخدمة في التسجيل.\n- البيانات المتعلقة بالداش كام لاكتشاف المخالفات المرورية.\n- تقارير المخالفات المرورية.',
          'it3': 'البند الثالث: جمع المعلومات وتخزينها',
          'it3text':
              'يتم جمع المعلومات في رصد عن طريق البيانات المدخلة من المستخدم وكاميرا لرصد المخالفات المرورية وتخزينها في الخوادم الخاصة بالتطبيق.',
          'it4': 'البند الرابع: مشاركة البيانات',
          'it4text':
              'يجوز استخدام بيانات المستخدم كروابط المخالفات المرورية لتحسين خدمة رصد المخالفات ومشاركة تقارير المخالفات المرورية مع الجهات المختصة.',
          'it5': 'البند الخامس: إخلاء المسؤولية ',
          'it5text':
              'رَصْد يخلي مسؤوليته من نشر او استخدام المقاطع وتقرير المخالفات وأي معلومات مقدمة من التطبيق لغير الجهات المختصة . \n يتحمل المستخدم المسؤولية عن جميع صحة البيانات المدخلة، ويتحمل المسؤولية حال مخالفة ذلك. ',
          'it6': 'البند السادس: إدارة التطبيق',
          'it6text':
              'اسم الجهة المشرفة على التطبيق: جامعة الملك سعود كلية علوم الحاسب والمعلومات ،قسم تقنية المعلومات. ',

          // account
          'acc': 'حسابي',
          'fname': 'الإسم الأول',
          'lname': 'الإسم الأخير',
          'em': 'البريد الإلكتروني',
          'PhoneNum': 'رقم الهاتف',
          'NotVer': 'توثيق',
          'Ver': 'موثّق',
          'DuplicateNumErrMessage': 'لا يسمح بإدخال رقم الهاتف نفسه',
          'save': 'حفظ',
          'FLValidation1': 'يسمح لك بإدخال أحرف فقط ',
          'updateMess': 'تم تحديث معلوماتك بنجاح',
          'AreUSureToSave': 'هل أنت متأكد من تحديث معلوماتك وحفظها؟',
          'oldE': 'عنوان البريد الإلكتروني السابق',
          'enterEOld': 'أدخل عنوان بريدك الإلكتروني السابق',
          'update': 'تحديث',
          'changeE':
              'لتحديث البريد الإلكتروني الرجاء ادخال عنوان البريد الإلكتروني السابق وكلمة المرور:',
          'invalidE2':
              ' عنوان البريد الإلكتروني غير صالح، رجاءً اتبع الصيغة \nالتالية : example@example.com',
          'empty': 'هذا الحقل فارغ ، لن يتم تحديثه',
        }
      };
}
