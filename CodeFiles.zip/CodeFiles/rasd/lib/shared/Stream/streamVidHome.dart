import 'dart:io';
import 'dart:async';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vlc_player/flutter_vlc_player.dart';
import 'package:path_provider/path_provider.dart';
import 'package:rasd/shared/Stream/streamStatucCheck.dart';

//This class is to show the stream of videos coming from the dashcam and recorded it in the [homePage]
class LiveStreamScreen extends StatefulWidget {
  final String
      url; //The RTSP URL, used to retrieve the streaming coming from the dashcam
  final String
      uid; //The user ID, used as the name of the folder that the videos will be stored in
  final bool recordStream; //This indicate whether to record the stream or not
  const LiveStreamScreen(
      {super.key,
      required this.url,
      required this.uid,
      required this.recordStream});

  @override
  _liveStreamScreen createState() => _liveStreamScreen();
}

class _liveStreamScreen extends State<LiveStreamScreen> {
  Timer? timer; //timer for start timer method
  Timer? countDown; //timer for minute count down
  Timer?
      _streamUpdate; //timer to check the status of the recording in the application
  int vidLength = 55; //length of a single video
  bool?
      isLive; // true if it is live, false if it is not, indicatethe status of the stream
  VlcPlayerController
      _videoPlayerController = //initilze video controller, Controls a platform vlc player,
      VlcPlayerController.network(
          ''); //and provides updates when the state is changing

  var _externalDocumentsDirectory;

  //The initial state of the class, This code will run each time a [LiveStreamScreen] object is initiated
  @override
  void initState() {
    super.initState();

    _streamUpdate
        ?.cancel(); //Cancel the previous [_streamUpdate] timer it's not cancelled before

    _videoPlayerController = VlcPlayerController.network(
      //Set the value of  [_videoPlayerController]
      widget
          .url, //The RTSP link that's going to be used to obtain the video stream
      hwAcc: HwAcc
          .full, //Set hardware acceleration for player -use GPU Instead of CPU-.
      autoPlay: true, //The video should be played automatically.
      options: VlcPlayerOptions(
          video: VlcVideoOptions([
        '--drop-late-frames'
      ])), //This drops frames that are late (arrive to the video output after their intended display date).
    );

    //After initializing the video player controller call the isStreamLive method to check if the stream is playing
    _streamUpdate = Timer.periodic(Duration(seconds: 1), (_) => isStreamLive());

    if (widget.recordStream) {
      // if ture this mean that the stream will be recorded



      //repete recording every minute
      timer = Timer.periodic(
        Duration(seconds: 60),
        (_) => recordingLoop(),
      );




    }
  }

  //Called when [LiveStreamScreen] object is removed from the tree permanently.
  @override
  void dispose() {
    //Canceling all the timers, because once a [Timer] has been canceled, the callback function will not be called by the timer
    countDown?.cancel();
    timer?.cancel();
    _streamUpdate?.cancel();
    super.dispose();
  }

  //check the status of the stream
  void isStreamLive() {
    setState(() {
      isLive = _videoPlayerController
          .value.isPlaying; //Returns true if the video is playing
    });
    streamCheck.statCheckHome.value =
        isLive!; // setting [streamCheck.statCheckHome.value] so that It will be updated in the [streamStatusCheck] class, therefore reflected In the [homePage] class
  }

  List<String?> _directory = [];

  Future<String?> _requestExternalStorageDirectory() async {
    _externalDocumentsDirectory = await getExternalStorageDirectory();
    _directory = _externalDocumentsDirectory.toString().split('\'');
    print(' $_directory');
    return _directory[1];
  }

  //This methods is to start recording the video
  void startRec() async {
    //the path of driver's mobile internal storage, which we will store the recordings in
    var _directoryPath = await _requestExternalStorageDirectory(); 
    if (_videoPlayerController.value.recordPath != '') {
      //Tha [_videoPlayerController.value.recordPath] is where videos will be saved in,
      // If it's empty then the video is not saved yet
      uploadFile(_videoPlayerController.value
          .recordPath); //call [uploadFile] method to upload the video to storage
    }
    _videoPlayerController
        .startRecording(_directoryPath.toString()); //start recording the video
  }

  //This methods is to stop the recording of the video
  void stopRec() async {
    _videoPlayerController.stopRecording(); //stop recording the video
  }

  //This methods is to upload the recording of the video to the firebase storage
  Future uploadFile(String _path) async {
    print('_path in phone: $_path');
    var pathSplit = _path.substring(_path.lastIndexOf('/') + 1);
    print(
        "after split"); //Split the the received path, and store it in an array.
    // a typical path would look like 'folder/folder/folder/filename'
    //after splitting it would be like ['folder', 'folder', 'folder', 'filename']
    final path = widget.uid +
        '/$pathSplit'; //this is the path the video will be stored in at Firebase Storage, 
        //it consist of the user id and the video file name
    print('path to storage: $path');
    //  print("DONE PATH");
    final file = File(_path); //Creates a [File] object.
    final ref = FirebaseStorage.instance.ref().child(
        path); //Returns a reference to a relative path from this reference.
    ref.putFile(file); //Upload a [File] at FirebaseStorage.
  }

  //This method collect all the recording and saving process. (start->stop->upload recording)
  void recordingLoop() {
    if (isLive!) {
      print('rec loop');
      //Record if the video is playing
      vidLength = 55; //set the video length to be 55 seconds
      startRec(); //call start recording method
      const oneSec = Duration(seconds: 1); //decrement vidLength each second
      countDown = Timer.periodic(
        oneSec,
        (Timer timer) {
          if (vidLength == 0) {
            //if the recording reached the end stop recording
            stopRec(); //call stop recording method
            setState(() {
              timer.cancel(); //stop timer
            });
          } else {
            setState(() {
              vidLength--; //decrement by one second
            });
          }
        },
      );
    }
  }

  //this method is to delete the files in the internal storage of the user's phone
  void deleteInternalFiles() {
    var filesCounter =
        7; //This will be decremented to three so that one video file will remain and not be deleted So it could be uploaded to fire storage
    final directory = Directory(
        '/storage/emulated/0/Movies/'); //Get the directory the videos will be saved in
    List contents = directory.listSync(); //Get all directory content
    if (contents.length >= 7) {
      //If the length of the content is 7 meaning that there is two original files and 5 vlc video files so start deleting
      for (var fileOrDir in contents) {
        //Loop through the entire contents and check whether it's a vlc video in order to delete them
        if (fileOrDir is File && fileOrDir.path.contains('vlc')) {
          fileOrDir.delete();
          filesCounter--;
        }
        if (filesCounter == 3) {
          //If the length of content is 3 meaning that there is one VLC video left keep itand break the loop
          break;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    //deleteInternalFiles(); //[deleteInternalFiles] will be called every time there is a build
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          VlcPlayer(
            //a [VlcPlayer] widget that displays the video.
            controller:
                _videoPlayerController, //responsible for the video being rendered in the widget.
            aspectRatio: 15 / 8, //The aspect ratio used to display the video.
            placeholder: const Center(
              //Before the platform view has initialized, this placeholder [CircularProgressIndicator] will be rendered instead of the video player.
              child: CircularProgressIndicator(),
            ),
          ),
        ],
      ),
    );
  }
}
