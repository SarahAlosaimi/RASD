import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_vlc_player/flutter_vlc_player.dart';
import 'package:rasd/shared/Stream/streamStatucCheck.dart';

//This class is to show the stream of videos coming from the dashcam in the [linkDashCam]
class LiveStreamScreenLink extends StatefulWidget {
  final String
      url; //The RTSP URL, used to retrieve the streaming coming from the dashcam
  final String
      uid; //The user ID, used as the name of the folder that the videos will be stored in
  final bool recordStream; //This indicate whether to record the stream or not
  const LiveStreamScreenLink(
      {super.key,
      required this.url,
      required this.uid,
      required this.recordStream});

  @override
  _liveStreamScreenLink createState() => _liveStreamScreenLink();
}

class _liveStreamScreenLink extends State<LiveStreamScreenLink> {
  Timer?
      _streamUpdate; //timer to check the status of the recording in the application
  bool?
      isLive; // true if it is live, false if it is not, indicatethe status of the stream
  VlcPlayerController
      _videoPlayerController = //initilze video controller, Controls a platform vlc player,
      VlcPlayerController.network(
          ''); //and provides updates when the state is changing

  //The initial state of the class, This code will run each time a [LiveStreamScreen] object is initiated
  @override
  void initState() {
    super.initState();

    _videoPlayerController = VlcPlayerController.network(
      //Set the value of  [_videoPlayerController]
      widget
          .url, //The RTSP link that's going to be used to obtain the video stream
      hwAcc: HwAcc
          .full, //Set hardware acceleration for player -use GPU Instead of CPU-.
      autoPlay: true, //The video should be played automatically.
      options: VlcPlayerOptions(
          video: VlcVideoOptions([
        '--drop-late-frames'
      ])), //This drops frames that are late (arrive to the video output after their intended display date).
    );

    //After initializing the video player controller call the isStreamLive method to check if the stream is playing
    _streamUpdate = Timer.periodic(Duration(seconds: 1), (_) => isStreamLive());
  }

  //Called when [LiveStreamScreen] object is removed from the tree permanently.
  @override
  void dispose() {
    //Canceling all the timers, because once a [Timer] has been canceled, the callback function will not be called by the timer
    _streamUpdate?.cancel();
    super.dispose();
  }

  //check the status of the stream
  void isStreamLive() {
    setState(() {
      isLive = _videoPlayerController
          .value.isPlaying; //Returns true if the video is playing
    });
    streamCheck.statCheckLink.value =
        isLive!; // setting [streamCheck.statCheckHome.value] so that It will be updated in the [streamStatusCheck] class, therefore reflected In the [linkDashCamPage] class
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          VlcPlayer(
            //a [VlcPlayer] widget that displays the video.
            controller:
                _videoPlayerController, //responsible for the video being rendered in the widget.
            aspectRatio: 15 / 8, //The aspect ratio used to display the video.
            placeholder: const Center(
              //Before the platform view has initialized, this placeholder [CircularProgressIndicator] will be rendered instead of the video player.
              child: CircularProgressIndicator(),
            ),
          ),
        ],
      ),
    );
  }
}
