package com.example.rasd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
